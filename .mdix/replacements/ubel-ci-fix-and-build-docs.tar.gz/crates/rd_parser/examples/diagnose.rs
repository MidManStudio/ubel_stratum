// Stage-by-stage pipeline diagnostic tool.
//
// Runs ONE .ubl file through tokenize -> rd_parser -> sema -> interpret and
// prints a clearly section-delimited report of what happened at each stage.
// Designed to be both directly readable (as Action log output) and easy for
// a downstream script to parse (split on the "=== NAME ===" markers).
//
// Usage: cargo run -p ubel_stratum_rd --example diagnose -- <path/to/file.ubl>
//
// Exit code is always 0 — this tool reports, it never fails the build.
// (ci-check.yml's own `cargo test` step is what should fail the build on
// a real regression; this tool is purely diagnostic.)

use std::env;
use std::fmt;
use std::fs;
use std::process;
use ubel_stratum::ast::arena::AstArena;
use ubel_stratum::ast::{Item, Program};

// rd_parser::parse() injects the prelude (Ubel source for Ordering, the
// comparison traits, Hasher and Hash) in front of every program's items.
// Dumping it with `{:#?}` repeats roughly 100 KB of identical AST in the
// PARSE section of every fixture report, which is what pushed the combined
// report.json past Cloudflare Pages' 25 MiB per-file limit. This view prints
// the program exactly as `{:#?}` does, minus the items the prelude added.
struct UserProgram<'a, 'ast>(&'a Program<'ast>);

impl<'a, 'ast> UserProgram<'a, 'ast> {
    fn user_items(&self) -> Vec<&'a Item<'ast>> {
        self.0.items.iter().filter(|i| !i.span().is_prelude()).collect()
    }
}

impl fmt::Debug for UserProgram<'_, '_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Program")
            .field("package", &self.0.package)
            .field("imports", &self.0.imports)
            .field("items", &self.user_items())
            .field("span", &self.0.span)
            .finish()
    }
}

fn section(name: &str) {
    println!("\n=== {name} ===");
}

// The most a single `{:#?}` dump may write. `{:#?}` indents every nesting
// level further, so its output for a deeply nested tree grows with the square
// of the depth: ok_nesting_long_chain_isolated.ubl (a 900-operand `a + a + ...`
// chain, the deepest tree the parser accepts) produced hundreds of megabytes
// and ran past the 30 s `timeout` that pipeline-dashboard.yml puts on every
// fixture, which failed the whole deploy. The largest dump of any other
// fixture is about 600 KB, so this limit changes none of their reports; it
// only cuts a dump that is not readable anyway.
const DUMP_LIMIT_BYTES: usize = 1024 * 1024;

// `format!("{:#?}", value)`, but stops formatting once `limit` bytes have been
// produced (the Debug impls propagate the writer's error, so the work stops
// too, not just the output) and says so at the end of what it kept.
fn pretty_capped<T: fmt::Debug>(value: &T, limit: usize) -> String {
    use fmt::Write;
    struct Capped {
        out: String,
        limit: usize,
        hit: bool,
    }
    impl Write for Capped {
        fn write_str(&mut self, s: &str) -> fmt::Result {
            let room = self.limit - self.out.len();
            if s.len() > room {
                let mut cut = room;
                while !s.is_char_boundary(cut) {
                    cut -= 1;
                }
                self.out.push_str(&s[..cut]);
                self.hit = true;
                return Err(fmt::Error);
            }
            self.out.push_str(s);
            Ok(())
        }
    }
    let mut w = Capped { out: String::new(), limit, hit: false };
    let _ = write!(w, "{:#?}", value);
    if w.hit {
        w.out.push_str(&format!(
            "\n... [dump truncated after {} KiB: too deeply nested to print in full]",
            limit / 1024
        ));
    }
    w.out
}

// The same large stack the `ubel` command and the language server run the
// pipeline on (see `ubel_stratum::stack`). On the 8 MB stack of a main thread a
// deeply nested but legal file (ok_nesting_long_chain_isolated.ubl, 900
// operands, within the parser's nesting limit) overflowed the stack in sema
// and aborted this tool, which is not what the fixture sweep is meant to test.
fn main() {
    ubel_stratum::stack::with_big_stack(run);
}

fn run() {
    let path = match env::args().nth(1) {
        Some(p) => p,
        None => {
            eprintln!("usage: diagnose <path/to/file.ubl>");
            process::exit(2);
        }
    };

    let source = match fs::read_to_string(&path) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("cannot read {path}: {e}");
            process::exit(2);
        }
    };

    println!("=== FILE: {path} ===");

    section("SOURCE");
    println!("{source}");

    // ── Stage 1: lex ────────────────────────────────────────────────────
    section("TOKENS");
    let tokens = match ubel_stratum::lexer::tokenize(&source) {
        Ok(t) => {
            println!("status: OK ({} tokens)", t.len());
            for tok in &t {
                println!(
                    "  [{}:{}] {:?}  {:?}",
                    tok.span.line, tok.span.column, tok.kind, tok.lexeme
                );
            }
            t
        }
        Err(mut errs) => {
            println!("status: LEX ERROR");
            use ubel_stratum::error_management::Diagnosable;
            let diags: Vec<_> = errs.take_lexical_errors()
                .iter()
                .map(|e| e.to_diagnostic())
                .collect();
            print!("{}", ubel_stratum::error_management::render_all(&diags, &source));
            print_summary(true, false, None, None, None);
            return;
        }
    };

    // ── Stage 2: parse (rd_parser) ────────────────────────────────────────
    section("PARSE");
    let arena = AstArena::new();
    let program = match ubel_stratum_rd::parse(&arena, &tokens, source.clone()) {
        Ok(p) => {
            let view = UserProgram(&p);
            println!("status: OK ({} top-level items)", view.user_items().len());
            println!("{}", pretty_capped(&view, DUMP_LIMIT_BYTES));
            p
        }
        Err(mut errs) => {
            println!("status: PARSE ERROR");
            use ubel_stratum::error_management::Diagnosable;
            let diags: Vec<_> = errs.take_parse_errors()
                .iter()
                .map(|e| e.to_diagnostic())
                .collect();
            print!("{}", ubel_stratum::error_management::render_all(&diags, &source));
            print_summary(false, true, None, None, None);
            return;
        }
    };

    // ── Stage 3: sema ───────────────────────────────────────────────────
    section("SEMA");
    let sema_result = ubel_stratum::sema::analyse(&program, &arena, source.clone());
    let mut int_literal_types = std::collections::HashMap::new();
    let mut trait_call_sites  = std::collections::HashMap::new();
    let sema_ok = match &sema_result {
        Ok(ctx) => {
            println!("status: OK");
            println!("{}", pretty_capped(ctx, DUMP_LIMIT_BYTES));
            int_literal_types = ctx.int_literal_types.clone();
            trait_call_sites  = ctx.trait_call_sites.clone();
            true
        }
        Err(_) => false,
    };
    if let Err(mut errs) = sema_result {
        println!("status: SEMA ERROR");
        use ubel_stratum::error_management::Diagnosable;
        let mut diags: Vec<_> = errs.take_name_errors()
            .iter()
            .map(|e| e.to_diagnostic())
            .collect();
        diags.extend(errs.take_type_errors().iter().map(|e| e.to_diagnostic()));
        diags.extend(errs.take_tier_errors().iter().map(|e| e.to_diagnostic()));
        // BorrowError (Phase D, BORROW-0xx) was added to sema::analyse as
        // its own error category without a matching update here — this
        // stage silently printed nothing beyond "status: SEMA ERROR" for
        // any borrow-checker failure (e.g. ConflictingAccessWhileBorrowed)
        // even though BorrowError has always had a complete Diagnosable
        // impl (code/message/suggestion/secondary_spans) ready to render;
        // it just was never collected here. Same recurring pattern as
        // every other "new error family needs wiring into every consumer"
        // gap this project has hit before.
        diags.extend(errs.take_borrow_errors().iter().map(|e| e.to_diagnostic()));
        // MoveError (move_check.rs, MOVE-0xx) added alongside BorrowError
        // in the same delivery that wires this stage up correctly from
        // the start -- BorrowError's own comment just above documents
        // the exact "new error family, forgot to collect it here" gap
        // this project has already hit once; not repeating it this time.
        diags.extend(errs.take_move_errors().iter().map(|e| e.to_diagnostic()));
        // LifetimeError (lifetime_check.rs's LIFETIME-001/002/003, and
        // outlives_check.rs's LIFETIME-004/005/006 added on top of those
        // later) hit the exact gap the two comments just above already
        // warned about, for real: found by testing `diagnose.rs` against
        // a real err_outlives_*.ubl fixture and getting nothing but the
        // bare "status: SEMA ERROR" line, no rendered diagnostic at all
        // -- LifetimeError has had a complete Diagnosable impl this
        // whole time, same as BorrowError did; it just was never
        // collected here, for every one of its error codes, not only
        // the newest ones. `pipeline.rs`'s own debug-only `{:?}` dump
        // (a different, lower-fidelity example) did show *something*
        // for lifetime errors throughout, which is exactly why this sat
        // unnoticed -- checking only one of the two example tools
        // hid it.
        diags.extend(errs.take_lifetime_errors().iter().map(|e| e.to_diagnostic()));
        print!("{}", ubel_stratum::error_management::render_all(&diags, &source));
    }
    if !sema_ok {
        print_summary(false, false, Some(false), None, None);
        return;
    }

    // ── Stage 4: interpret ────────────────────────────────────────────────
    section("INTERPRET");
    if !source.contains("fn main(") {
        println!("status: SKIPPED (no `fn main`)");
        print_summary(false, false, Some(true), None, None);
        return;
    }

    println!("--- program stdout ---");
    let mut interp = ubel_stratum::interpreter::Interpreter::new(&arena);
    interp.set_int_literal_types(int_literal_types);
    interp.set_trait_call_sites(trait_call_sites);
    let run_result = interp.run_program(&program);
    println!("--- end program stdout ---");

    let interp_ok = run_result.is_ok();
    match run_result {
        Ok(()) => println!("status: OK"),
        Err(e) => println!("status: RUNTIME ERROR: {e}"),
    }

    print_summary(false, false, Some(true), Some(interp_ok), None);
}

fn print_summary(
    lex_failed: bool,
    parse_failed: bool,
    sema_ok: Option<bool>,
    interp_ok: Option<bool>,
    _reserved: Option<()>,
) {
    section("SUMMARY");
    println!("lex:       {}", if lex_failed { "FAIL" } else { "ok" });
    println!(
        "parse:     {}",
        if lex_failed {
            "skipped"
        } else if parse_failed {
            "FAIL"
        } else {
            "ok"
        }
    );
    println!(
        "sema:      {}",
        match sema_ok {
            None => "skipped",
            Some(true) => "ok",
            Some(false) => "FAIL",
        }
    );
    println!(
        "interpret: {}",
        match interp_ok {
            None => "skipped",
            Some(true) => "ok",
            Some(false) => "FAIL",
        }
    );
  }
