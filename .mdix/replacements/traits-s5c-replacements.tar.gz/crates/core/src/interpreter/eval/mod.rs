// ============================================================================
// NOTICE: Full documentation, design decisions, and fix history for this file
// live in docs/ubel_stratum.md, section "interpreter/eval/mod.rs"
// ============================================================================
// src/interpreter/eval/mod.rs
//! Interpreter struct, function table, and call dispatch.

#![allow(dead_code)]

pub mod expr;
pub mod stmt;
pub mod pattern;
pub mod user_ops;
pub mod display;

#[cfg(test)]
mod tests;

use std::collections::{HashMap, HashSet};
use std::rc::Rc;

use crate::ast::arena::AstArena;
use crate::ast::common::{Span, TierAnnotation};
use crate::error_management::errors::{OPERATOR_TRAITS, operator_method_of, operator_trait_arity};
use crate::ast::literals::IntSuffix;
use crate::ast::declarations::{FunctionDecl, MethodDecl, ParamKind, StructMember};
use crate::ast::expressions::Expr;
use crate::ast::root::{Item, Program};
use crate::ast::statements::Block;
use crate::ast::types::{Type, TypeKind};
use crate::builtins::BuiltinFn;
use crate::interpreter::env::Environment;
use crate::interpreter::value::{EvalResult, FunctionId, Signal, Value};

// ── FunctionBody ──────────────────────────────────────────────────

pub enum FunctionBody<'ast> {
    /// User-defined function with a block body.
    Ast { block: Block<'ast> },
    /// Lambda with an expression body: `fn(x) x * 2`
    /// Stored as a reference into the arena so no allocation is needed.
    ExprBody { expr: &'ast Expr<'ast> },
    /// Native Rust built-in.
    Builtin(BuiltinFn),
}

// ── FunctionDef ───────────────────────────────────────────────────

pub struct FunctionDef<'ast> {
    pub name:     Option<String>,
    /// Parameter names in declaration order.
    /// `self` / `&self` / `mut self` params are excluded — they are bound
    /// by `call_method` directly.
    pub params:   Vec<String>,
    pub body:     FunctionBody<'ast>,
    /// Environment captured at definition time (closure snapshot).
    pub closure:  Environment,
    pub tier:     TierAnnotation,
    pub is_async: bool,
}

// ── Interpreter ───────────────────────────────────────────────────

/// Tree-walking interpreter.
///
/// The `'ast` lifetime is needed because `FunctionDef` stores arena-allocated
/// `Block<'ast>` and `&'ast Expr<'ast>` references.  `Value` and `Environment`
/// are both lifetime-free, so closures and runtime values can be passed around
/// freely without the compiler tracking AST provenance through them.
/// A variant's payload shape, as far as the interpreter needs to know to
/// construct it — no element/field types, since sema has already
/// validated those; see `Interpreter::enum_table`.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum VariantKind {
    /// Fieldless or Discriminant — both construct `EnumPayload::None`;
    /// the interpreter doesn't track a discriminant's chosen ordinal
    /// (see MEMORY_MODEL.md's enum-section "Known gap").
    Fieldless,
    Tuple,
    Struct,
}

pub struct Interpreter<'ast> {
    pub(crate) env:          Environment,
    pub(crate) functions:    Vec<FunctionDef<'ast>>,
    /// struct_type_name → method_name → FunctionId.
    /// Static and instance methods both live here; the call site determines
    /// whether a receiver is passed.
    pub(crate) method_table: HashMap<String, HashMap<String, FunctionId>>,
    /// enum_type_name → variant_name → its payload kind. Consulted by
    /// `EnumName.Variant` construction (bare field access for
    /// fieldless/discriminant, call syntax for tuple, struct-literal
    /// syntax for struct — ENUM_RULES.md) to tell "construct an enum
    /// value" apart from an ordinary field/method lookup. Sema has
    /// already validated arity/types by the time any of these run, so
    /// construction here doesn't re-check either.
    pub(crate) enum_table:   HashMap<String, HashMap<String, VariantKind>>,
    /// struct_type_name → set of that type's `@derive`d trait names.
    /// Only `"PartialEq"` is ever inserted today (sema's already
    /// rejected anything else by the time `run_program` runs — see
    /// `TYPE-116` — so this doesn't re-validate, just re-derives the
    /// same fact sema already established, the same relationship
    /// `method_table`/`enum_table` have with their own sema passes).
    /// Consulted once, at `ExprKind::StructLit` construction, to set
    /// `Value::Struct::derives_partial_eq` — not re-checked per
    /// comparison.
    pub(crate) struct_derives: HashMap<String, HashSet<String>>,
    /// struct_type_name → field names in declaration order. Built in the
    /// same pre-declare pass as `struct_derives`, from the same `s:
    /// StructDecl` walk (`StructMember::Field` members, in encounter
    /// order) — re-derives an already-available fact rather than reading
    /// back through sema's own `struct_fields` (def_id-keyed, not
    /// type-name-keyed, and not something the interpreter otherwise
    /// shares with sema). Consulted once, at `ExprKind::StructLit`
    /// construction, to set `Value::Struct::field_order` — see that
    /// field's own doc comment in `interpreter/value.rs` for why a
    /// declaration-derived order matters for `partial_cmp`/`compute_hash`
    /// and not just `HashMap`'s own (unstable, unordered) iteration.
    pub(crate) struct_field_order: HashMap<String, Rc<Vec<String>>>,
    /// The arena used to parse the program.  Kept here so interpolated-string
    /// expression holes (`$"Hello {expr}"`) can be parsed at runtime via
    /// `crate::parser::parse_expr`.
    pub(crate) arena:        &'ast AstArena,
    /// Ambient capacity for the innermost enclosing `with pool<T>(count)
    /// { }` block, pushed/popped by `StmtKind::With`'s execution
    /// (MEMORY_MODEL.md §11). `Pool.new()` has no generic argument of
    /// its own to construct from — unlike `List.new()` etc. — so it
    /// reads capacity from here rather than from its own call args.
    pub(crate) pool_capacity_stack: Vec<usize>,
    /// The width sema gave each unsuffixed integer literal, keyed by the
    /// literal's span (`SemaContext::int_literal_types`). The interpreter
    /// has no static types, so this is how `5` in `let x: u8 = 5` becomes
    /// a `u8` value instead of a plain `int`. Empty by default, which
    /// leaves every literal a plain `int` -- exactly the behavior of a
    /// program run without sema, as the interpreter's own unit tests do.
    pub(crate) int_literal_types: HashMap<Span, IntSuffix>,
    /// Module-level `static` globals, by name. They live here and not in
    /// `env` on purpose: `call_function` replaces `env` with a clone of the
    /// function's closure for the duration of every call, so a global kept
    /// in a scope would be copied in, assigned to, and thrown away again on
    /// return. This table is the single shared store every function reads
    /// and writes. Locals still shadow a static, because `lookup` and
    /// `write_lvalue` consult `env` first.
    pub(crate) statics: HashMap<String, Value>,
    /// `type` alias name -> the struct or enum name it stands for, for the
    /// aliases whose target is a named type. A `type` alias is just another
    /// name for a type, so a struct literal, a static call, an enum variant
    /// and a struct pattern written with the alias must behave exactly as
    /// the real name does, and the values they build carry the REAL type
    /// name (never the alias). Empty for a program with no such alias.
    pub(crate) type_aliases: HashMap<String, String>,
    /// Every declared trait's name. A call written `Trait.method(value)` is
    /// recognised by the first path segment being one of these.
    pub(crate) trait_names: std::collections::HashSet<String>,
    /// `(implementing type, trait)` -> method name -> function. Each trait
    /// impl's methods (and the trait's default methods it did not override)
    /// are kept here as well as in the flat `method_table`, because the flat
    /// table holds one function per name and two traits can supply the same
    /// name to one type. `Trait.method(value)` reads this table; sema has
    /// already rejected an unqualified call of an ambiguous name.
    pub(crate) trait_method_table: HashMap<(String, String), HashMap<String, FunctionId>>,
    /// Calls sema resolved through a trait bound, by callee span, with the
    /// trait's name (`SemaContext::trait_call_sites`). They dispatch through
    /// `trait_method_table`, so a trait's method runs even when the concrete
    /// type has an inherent method of the same name. Empty by default.
    pub(crate) trait_call_sites: HashMap<Span, String>,
    /// `type` alias name -> the built-in key (`ast::types::builtin_impl_key`)
    /// of an alias whose target is a primitive, a tuple or an array, so an
    /// `extend` or `impl` written for the alias registers under the key of
    /// the type it stands for.
    pub(crate) alias_builtin_keys: HashMap<String, String>,
    /// Set once a prelude trait is implemented by hand for a built-in type
    /// (`impl Hash for double`). Only then do comparisons, hashing and
    /// cloning of primitives, tuples and arrays look for a user's impl, so a
    /// program without one keeps the fast path (`user_ops`).
    pub(crate) builtin_prelude_impls: bool,
    /// Whether any `impl Display for Type` was registered. While it is `false`
    /// the runtime formats values exactly as before and does no extra work.
    pub(crate) has_user_display: bool,
    /// The operator traits the prelude declares in this program (a program
    /// that shadows `Add` with its own trait has no operator `Add`).
    pub(crate) operator_traits: HashSet<&'static str>,
    /// `(left type, operator trait, right operand's kind)` -> the impl's
    /// method, for `impl Mul<float, Vec2> for Vec2` and its siblings. A unary
    /// operator's right kind is empty. Empty for a program with no operator
    /// impl, which keeps the arithmetic fast path untouched (`user_ops`).
    pub(crate) operator_impls: HashMap<(String, &'static str, String), FunctionId>,
}

impl<'ast> Interpreter<'ast> {
    pub fn new(arena: &'ast AstArena) -> Self {
        let mut interp = Interpreter {
            env:          Environment::new(),
            functions:    Vec::new(),
            method_table: HashMap::new(),
            enum_table:   HashMap::new(),
            struct_derives: HashMap::new(),
            struct_field_order: HashMap::new(),
            arena,
            pool_capacity_stack: Vec::new(),
            int_literal_types: HashMap::new(),
            statics: HashMap::new(),
            type_aliases: HashMap::new(),
            trait_names: std::collections::HashSet::new(),
            trait_method_table: HashMap::new(),
            trait_call_sites: HashMap::new(),
            alias_builtin_keys: HashMap::new(),
            builtin_prelude_impls: false,
            has_user_display: false,
            operator_traits: HashSet::new(),
            operator_impls: HashMap::new(),
        };
        interp.register_builtins();
        interp
    }

    /// Hand the interpreter the literal widths sema resolved
    /// (`SemaContext::int_literal_types`). Call this before `run_program`
    /// for any program that went through `sema::analyse`; without it a
    /// literal such as the `5` in `let x: u8 = 5` stays a plain `int` and a
    /// later `x + y` with a real `u8` panics with a type mismatch.
    pub fn set_int_literal_types(&mut self, types: HashMap<Span, IntSuffix>) {
        self.int_literal_types = types;
    }

    /// Hand the interpreter the calls sema resolved through a trait
    /// (`SemaContext::trait_call_sites`). Call this before `run_program`
    /// for any program that went through `sema::analyse`. Without it a
    /// call through a trait bound runs the flat method table's entry, which
    /// is an inherent method when the type has one of that name.
    pub fn set_trait_call_sites(&mut self, sites: HashMap<Span, String>) {
        self.trait_call_sites = sites;
    }

    // ── Registration ─────────────────────────────────────────────

    fn register_builtins(&mut self) {
        for sig in crate::builtins::global::GLOBAL_BUILTINS {
            let id = self.functions.len();
            self.functions.push(FunctionDef {
                name:     Some(sig.name.to_string()),
                params:   vec![],
                body:     FunctionBody::Builtin(sig.run),
                closure:  Environment::new(),
                tier:     TierAnnotation::High,
                is_async: false,
            });
            self.env.define(sig.name, Value::Function(id));
        }
    }

    pub fn alloc_function(&mut self, def: FunctionDef<'ast>) -> FunctionId {
        let id = self.functions.len();
        self.functions.push(def);
        id
    }

    /// Register a top-level function declaration.
    /// Takes `FunctionDecl<'ast>` by value — it is `Copy` so fields
    /// (`body: Block<'ast>`, etc.) are copied off the stack while the
    /// underlying arena data they point to lives as long as `'ast`.
    pub fn register_fn(&mut self, f: FunctionDecl<'ast>) -> FunctionId {
        // enumerate() + a synthesized name for Discard, not filter_map
        // dropping it: param_names gets zipped positionally against real
        // call arguments at call sites (see e.g. line ~314 below) --
        // dropping a slot here would shift every later argument onto the
        // wrong name. `$`-prefixed: identifiers can't start with `$`
        // (Letter (Letter|Digit|_)*), so this can never collide with a
        // real binding a user could write or read.
        let params: Vec<String> = f.params.iter().enumerate()
            .filter_map(|(i, p)| match p.kind {
                ParamKind::Named { name, .. } => Some(name.to_string()),
                ParamKind::Discard { .. } => Some(format!("$discard{i}")),
                _ => None,
            })
            .collect();
        let block    = f.body;  // Block<'ast> is Copy
        let closure  = self.env.snapshot();
        let name_str = f.name.to_string();
        let tier     = f.tier;
        let is_async = f.is_async;
        self.alloc_function(FunctionDef {
            name:    Some(name_str),
            params,
            body:    FunctionBody::Ast { block },
            closure,
            tier,
            is_async,
        })
    }

    /// Register a struct method. The FunctionId is stored in `method_table`.
    pub fn register_method(&mut self, struct_name: &str, m: MethodDecl<'ast>) -> FunctionId {
        // Only Named/Discard params contribute a slot -- `self` variants
        // are handled at call sites. Same arity-preserving reasoning as
        // register_fn just above: Discard gets a synthesized `$`-prefixed
        // name (never a real, writable/readable identifier) instead of
        // being dropped, so later params don't shift onto the wrong
        // argument at call time.
        let params: Vec<String> = m.params.iter().enumerate()
            .filter_map(|(i, p)| match p.kind {
                ParamKind::Named { name, .. } => Some(name.to_string()),
                ParamKind::Discard { .. } => Some(format!("$discard{i}")),
                _ => None,
            })
            .collect();
        let block    = m.body;
        let closure  = self.env.snapshot();
        let name_str = format!("{}::{}", struct_name, m.name);
        let tier     = m.tier;
        let is_async = m.is_async;
        self.alloc_function(FunctionDef {
            name:    Some(name_str),
            params,
            body:    FunctionBody::Ast { block },
            closure,
            tier,
            is_async,
        })
    }

    /// The `extend`/inherent-`impl` twin of the `Item::Struct` arm's own
    /// method registration a few lines down in `run_program` — same
    /// The key an `extend` or `impl` block registers its methods under, and
    /// whether the target is a built-in type. A struct or an enum is its own
    /// name (an alias resolved to the real one); a primitive, a tuple or an
    /// array, written directly or through an alias, is its run-time key
    /// (`ast::types::builtin_impl_key`). `None` for anything else.
    fn impl_target_key(&self, target: &'ast Type<'ast>) -> Option<(String, bool)> {
        match target.kind {
            TypeKind::Named { path, .. } => {
                let written = path.first().copied()?;
                let canon = self.canonical_type(written);
                match self.alias_builtin_keys.get(canon) {
                    Some(key) => Some((key.clone(), true)),
                    None      => Some((canon.to_string(), false)),
                }
            }
            ref kind => crate::ast::types::builtin_impl_key(kind).map(|k| (k, true)),
        }
    }

    /// `register_method` + `method_table` insert per method, just reached
    /// from a `target_type` instead of a struct's own member list. `None`
    /// for anything that isn't a plain named path (nothing else is a
    /// sensible `extend`/`impl` target) silently registers nothing, same
    /// lenient handling sema's own `target_type_def_id` gives it.
    fn register_extend_or_impl_methods(
        &mut self,
        target_type: &'ast Type<'ast>,
        methods:     &'ast [MethodDecl<'ast>],
        top_level_fns: &mut Vec<FunctionId>,
    ) {
        // `extend P { .. }` with `type P = Point` extends `Point`; one written
        // for a primitive, a tuple or an array registers under its key.
        let Some((struct_name, _)) = self.impl_target_key(target_type) else { return; };
        for m in methods.iter().copied() {
            let id = self.register_method(&struct_name, m);
            self.method_table
                .entry(struct_name.clone())
                .or_default()
                .insert(m.name.to_string(), id);
            top_level_fns.push(id);
        }
    }

    /// `impl Trait for Type { .. }`: register the impl's methods, then the
    /// trait's default methods the impl does not override. Each goes in the
    /// per-trait table (`trait_method_table`) and, unless the type already
    /// has a method of that name, in the flat `method_table`. An inherent
    /// method registered LATER overwrites the flat entry, so an inherent
    /// method wins whichever order they were declared in, matching sema.
    fn register_trait_impl_methods(
        &mut self,
        imp:           crate::ast::declarations::ImplBlock<'ast>,
        trait_defaults: &HashMap<&'ast str, Vec<MethodDecl<'ast>>>,
        top_level_fns: &mut Vec<FunctionId>,
    ) {
        let Some(trait_name) = imp.trait_path.and_then(|p| p.last().copied()) else { return; };
        let Some((type_name, is_builtin)) = self.impl_target_key(imp.target_type) else { return; };
        if is_builtin && expr::is_prelude_trait(trait_name) {
            self.builtin_prelude_impls = true;
        }
        if trait_name == "Display" {
            self.has_user_display = true;
        }

        let defaults: &[MethodDecl<'ast>] = trait_defaults
            .get(trait_name).map(|v| v.as_slice()).unwrap_or(&[]);
        let inherited = defaults.iter().copied()
            .filter(|d| !imp.methods.iter().any(|m| m.name == d.name));

        // An impl of an operator trait is also filed by the right operand's
        // kind, because a type may have several (`Mul<float, V>` and
        // `Mul<V, V>`) and `trait_method_table` holds one per trait.
        let operator: Option<(&'static str, String)> = match self.operator_traits.get(trait_name).copied() {
            Some(op) => {
                let rhs = if operator_trait_arity(op) == 2 {
                    imp.trait_args.first().copied().and_then(|t| self.impl_target_key(t)).map(|(k, _)| k)
                } else {
                    Some(String::new())
                };
                rhs.map(|k| (op, k))
            }
            None => None,
        };

        for m in imp.methods.iter().copied().chain(inherited) {
            let id = self.register_method(&type_name, m);
            if let Some((op, rhs_key)) = &operator {
                if m.name == operator_method_of(op) {
                    self.operator_impls.insert((type_name.clone(), *op, rhs_key.clone()), id);
                }
            }
            self.trait_method_table
                .entry((type_name.clone(), trait_name.to_string()))
                .or_default()
                .insert(m.name.to_string(), id);
            self.method_table
                .entry(type_name.clone())
                .or_default()
                .entry(m.name.to_string())
                .or_insert(id);
            top_level_fns.push(id);
        }
    }

    // ── Program entry point ───────────────────────────────────────

    pub fn run_program(&mut self, program: &'ast Program<'ast>) -> Result<(), String> {
        // Pre-declare pass: register everything before running any body so
        // forward references and mutual recursion work.
        let mut top_level_fns: Vec<FunctionId> = Vec::new();

        // Aliases and traits first. A `type` alias must be known before an
        // `extend`/`impl` that targets it is registered, and a trait's
        // default methods must be at hand when an `impl` of it is reached,
        // whatever order the items appear in the file.
        let mut trait_defaults: HashMap<&'ast str, Vec<MethodDecl<'ast>>> = HashMap::new();
        for item in program.items.iter().copied() {
            match item {
                Item::TypeAlias(a) => {
                    if let TypeKind::Named { path, .. } = a.ty.kind {
                        if let Some(target) = path.last() {
                            self.type_aliases.insert(a.name.to_string(), target.to_string());
                        }
                    } else if let Some(key) = crate::ast::types::builtin_impl_key(&a.ty.kind) {
                        self.alias_builtin_keys.insert(a.name.to_string(), key);
                    }
                }
                Item::Trait(t) => {
                    self.trait_names.insert(t.name.to_string());
                    if t.span.is_prelude() {
                        if let Some(op) = OPERATOR_TRAITS.iter().find(|o| o.0 == t.name) {
                            self.operator_traits.insert(op.0);
                        }
                    }
                    let defaults: Vec<MethodDecl<'ast>> = t.items.iter().filter_map(|it| match it {
                        crate::ast::declarations::TraitItem::DefaultMethod(m) => Some(*m),
                        _ => None,
                    }).collect();
                    trait_defaults.insert(t.name, defaults);
                }
                _ => {}
            }
        }

        for item in program.items.iter().copied() {
            match item {
                Item::Function(f) => {
                    // f: FunctionDecl<'ast> — Copy value whose fields point into 'ast arena
                    let id = self.register_fn(f);
                    self.env.define(f.name, Value::Function(id));
                    top_level_fns.push(id);
                }
                Item::TypeAlias(a) => {
                    // Only an alias whose target is a named type can be
                    // constructed or called through; `type Score = int`
                    // has nothing to canonicalize to, and is known by its
                    // built-in key instead (the pre-declare pass above).
                    if let TypeKind::Named { path, .. } = a.ty.kind {
                        if let Some(target) = path.last() {
                            self.type_aliases.insert(a.name.to_string(), target.to_string());
                        }
                    }
                }
                Item::Struct(s) => {
                    // Sema (TYPE-116) already rejected anything but
                    // `PartialEq` here -- this just re-derives the same
                    // already-validated fact, same relationship
                    // method_table/enum_table have with their own passes.
                    let derived: HashSet<String> =
                        crate::ast::common::derive_trait_names(s.attributes)
                            .into_iter()
                            .map(|name| name.to_string())
                            .collect();
                    if !derived.is_empty() {
                        self.struct_derives.insert(s.name.to_string(), derived);
                    }
                    let field_names: Vec<String> = s.members.iter()
                        .filter_map(|m| match m {
                            StructMember::Field(f) => Some(f.name.to_string()),
                            _ => None,
                        })
                        .collect();
                    self.struct_field_order.insert(s.name.to_string(), Rc::new(field_names));
                    for member in s.members.iter().copied() {
                        if let StructMember::Method(m) = member {
                            let id = self.register_method(s.name, m);
                            self.method_table
                                .entry(s.name.to_string())
                                .or_default()
                                .insert(m.name.to_string(), id);
                            top_level_fns.push(id);
                        }
                    }
                }
                Item::Enum(e) => {
                    use crate::ast::declarations::EnumVariantPayload as P;
                    let variants: HashMap<String, VariantKind> = e.variants.iter()
                        .map(|v| {
                            let kind = match v.payload {
                                P::None | P::Discriminant(_) => VariantKind::Fieldless,
                                P::Tuple(_)                  => VariantKind::Tuple,
                                P::Struct(_)                 => VariantKind::Struct,
                            };
                            (v.name.to_string(), kind)
                        })
                        .collect();
                    self.enum_table.insert(e.name.to_string(), variants);
                }
                // Interpreter-side twin of sema's own
                // `register_extend_impl_methods` (`type_infer.rs`) — same
                // root cause, same fix shape: nothing here ever looked at
                // `target_type` before, so `method_table` (what
                // `receiver.method()` dispatch actually looks up, just
                // below) never got an entry for an `extend`/`impl`-block
                // method, even once sema was taught to accept the call.
                // Trait `impl`s are skipped for the same reason sema
                // skips them: traits aren't dispatched through yet.
                Item::Extend(x)                                => {
                    self.register_extend_or_impl_methods(x.target_type, x.methods, &mut top_level_fns);
                }
                Item::Impl(i) if i.trait_path.is_none() => {
                    self.register_extend_or_impl_methods(i.target_type, i.methods, &mut top_level_fns);
                }
                Item::Impl(i) => {
                    self.register_trait_impl_methods(i, &trait_defaults, &mut top_level_fns);
                }
                _ => {}
            }
        }

        // `register_fn`/`register_method` snapshot `self.env` for the
        // closure at the moment each item is registered — which, mid-loop,
        // is *before* later top-level items have been declared. A function
        // declared early in the file (e.g. `main`) would otherwise end up
        // with a closure that can't see a function declared later in the
        // same file (e.g. `greet`), even though both are top-level and
        // should share one module scope. Backfill every top-level
        // fn/method's closure with a single snapshot taken now, after the
        // whole pre-declare pass has finished.
        let module_scope = self.env.snapshot();
        for id in top_level_fns.iter().copied() {
            self.functions[id].closure = module_scope.clone();
        }

        // Global `const` items. Sema type-checks and name-resolves them
        // (`collect_const_sig`, `resolve_const`) but nothing here ever
        // evaluated one, so reading a constant from any function body
        // panicked with `undefined name`. Run after the closure backfill
        // above so an initializer can call a top-level function, then
        // backfill a second time so every function's snapshot also sees
        // the constants. Sema accepts a constant that refers to one
        // declared later in the file (top-level names are all declared
        // up front), so evaluation retries constants whose initializer hit
        // an undefined name until a whole pass makes no progress; that is
        // also what reports a constant cycle, at startup rather than at
        // sema. Initializers are expected to be pure, since one that
        // deferred is evaluated again.
        //
        // `static` items go through the same loop, so a static may refer to
        // a constant or to another static declared later in the file, and a
        // cycle among them is reported the same way. A constant is defined
        // in `env`; a static goes to `self.statics` (see its field doc).
        // The `bool` is `true` for a static.
        let mut pending: Vec<(&'ast str, &'ast Expr<'ast>, bool)> = program.items.iter().copied()
            .filter_map(|item| match item {
                Item::Const(c)  => Some((c.name, c.value, false)),
                Item::Static(s) => Some((s.name, s.value, true)),
                _ => None,
            })
            .collect();
        if !pending.is_empty() {
            let mut last_undefined = String::new();
            while !pending.is_empty() {
                let mut deferred: Vec<(&'ast str, &'ast Expr<'ast>, bool)> =
                    Vec::with_capacity(pending.len());
                for (name, value, is_static) in pending.iter().copied() {
                    let what = if is_static { "static" } else { "constant" };
                    match expr::eval_expr(self, value) {
                        Ok(v) if is_static => { self.statics.insert(name.to_string(), v); }
                        Ok(v)              => self.env.define(name, v),
                        Err(Signal::Panic(msg)) if msg.starts_with("undefined name '") => {
                            last_undefined = msg;
                            deferred.push((name, value, is_static));
                        }
                        Err(Signal::Panic(msg)) => {
                            return Err(format!("panic: {} (initializing {} `{}`)", msg, what, name));
                        }
                        Err(Signal::Fail(v)) => {
                            return Err(format!("unhandled fail: {} (initializing {} `{}`)", v, what, name));
                        }
                        Err(_) => {
                            return Err(format!("invalid control flow initializing {} `{}`", what, name));
                        }
                    }
                }
                if deferred.len() == pending.len() {
                    let what = if deferred[0].2 { "static" } else { "constant" };
                    return Err(format!(
                        "panic: {} (initializing {} `{}`; the constants and statics involved refer to each other or to a name that is never defined)",
                        last_undefined, what, deferred[0].0
                    ));
                }
                pending = deferred;
            }
            let module_scope = self.env.snapshot();
            for id in top_level_fns.iter().copied() {
                self.functions[id].closure = module_scope.clone();
            }
        }

        let main_val = self.env.get("main").cloned()
            .ok_or_else(|| "no `main` function found".to_string())?;

        match main_val {
            Value::Function(id) => match self.call_function(id, &[]) {
                Ok(_) | Err(Signal::Return(_)) => Ok(()),
                Err(Signal::Panic(msg)) => Err(format!("panic: {}", msg)),
                Err(Signal::Fail(v))    => Err(format!("unhandled fail: {}", v)),
                Err(Signal::Break(_))   => Err("break outside loop".to_string()),
                Err(Signal::Continue)   => Err("continue outside loop".to_string()),
            },
            _ => Err("`main` is not a function".to_string()),
        }
    }

    // ── Call dispatch ─────────────────────────────────────────────

    /// Call a function by FunctionId with already-evaluated arguments.
    ///
    /// Uses a local enum to carry extracted body data so the immutable borrow
    /// on `self.functions` is fully released before any mutation of `self.env`.
    pub fn call_function(&mut self, id: FunctionId, args: &[Value]) -> EvalResult {
        // Phase 1: extract body data — immutable borrow on self.functions.
        enum BodyData<'a> {
            Builtin(BuiltinFn),
            Block(Block<'a>),
            Expr(&'a Expr<'a>),
        }

        let display_builtin = matches!(
            self.functions[id].name.as_deref(),
            Some("println" | "print" | "log" | "to_string" | "assert" | "panic")
        );
        let (body, param_names, closure) = {
            let def = &self.functions[id];
            let body = match &def.body {
                FunctionBody::Builtin(f)        => BodyData::Builtin(*f),
                FunctionBody::Ast { block }     => BodyData::Block(*block),
                FunctionBody::ExprBody { expr } => BodyData::Expr(expr),
            };
            (body, def.params.clone(), def.closure.clone())
        }; // ← immutable borrow released here

        // Phase 2: run the body — may mutate self freely.
        match body {
            BodyData::Builtin(f) => {
                // A value with a user-written `Display` is turned into its text
                // before the output builtins see it (traits slice S5a).
                if self.has_user_display && display_builtin {
                    let shown = self.display_args(args)?;
                    f(&shown)
                } else {
                    f(args)
                }
            }

            BodyData::Block(block) => {
                let caller_env = std::mem::replace(&mut self.env, closure);
                self.env.push();
                for (name, val) in param_names.iter().zip(args.iter()) {
                    self.env.define(name, val.clone());
                }
                let result = stmt::eval_block(self, &block);
                self.env = caller_env;
                match result {
                    Ok(v) | Err(Signal::Return(v)) => Ok(v),
                    Err(other)                     => Err(other),
                }
            }

            BodyData::Expr(e) => {
                let caller_env = std::mem::replace(&mut self.env, closure);
                self.env.push();
                for (name, val) in param_names.iter().zip(args.iter()) {
                    self.env.define(name, val.clone());
                }
                let result = expr::eval_expr(self, e);
                self.env = caller_env;
                match result {
                    Ok(v) | Err(Signal::Return(v)) => Ok(v),
                    Err(other)                     => Err(other),
                }
            }
        }
    }

    /// Call a struct method with an explicit `self` receiver.
    pub fn call_method(
        &mut self,
        id:       FunctionId,
        receiver: Value,
        args:     &[Value],
    ) -> EvalResult {
        enum BodyData<'a> {
            Builtin(BuiltinFn),
            Block(Block<'a>),
            Expr(&'a Expr<'a>),
        }

        let (body, param_names, closure) = {
            let def = &self.functions[id];
            let body = match &def.body {
                FunctionBody::Builtin(f)        => BodyData::Builtin(*f),
                FunctionBody::Ast { block }     => BodyData::Block(*block),
                FunctionBody::ExprBody { expr } => BodyData::Expr(expr),
            };
            (body, def.params.clone(), def.closure.clone())
        };

        match body {
            BodyData::Builtin(f) => {
                let mut all = vec![receiver];
                all.extend_from_slice(args);
                f(&all)
            }
            BodyData::Block(block) => {
                let caller_env = std::mem::replace(&mut self.env, closure);
                self.env.push();
                self.env.define("self", receiver);
                for (name, val) in param_names.iter().zip(args.iter()) {
                    self.env.define(name, val.clone());
                }
                let result = stmt::eval_block(self, &block);
                self.env = caller_env;
                match result {
                    Ok(v) | Err(Signal::Return(v)) => Ok(v),
                    Err(other)                     => Err(other),
                }
            }
            BodyData::Expr(e) => {
                let caller_env = std::mem::replace(&mut self.env, closure);
                self.env.push();
                self.env.define("self", receiver);
                for (name, val) in param_names.iter().zip(args.iter()) {
                    self.env.define(name, val.clone());
                }
                let result = expr::eval_expr(self, e);
                self.env = caller_env;
                match result {
                    Ok(v) | Err(Signal::Return(v)) => Ok(v),
                    Err(other)                     => Err(other),
                }
            }
        }
    }

    /// The real type name behind `name`: follows `type` aliases to a
    /// struct or enum, and returns `name` itself when it is not an alias.
    /// The hop limit is only a guard for the interpreter's own unit tests,
    /// which run without sema (sema rejects an alias cycle).
    pub(crate) fn canonical_type<'a>(&'a self, name: &'a str) -> &'a str {
        if self.type_aliases.is_empty() { return name; }
        let mut cur = name;
        for _ in 0..64 {
            match self.type_aliases.get(cur) {
                Some(next) => cur = next.as_str(),
                None       => break,
            }
        }
        cur
    }

    /// Whether comparing, hashing or cloning this value could involve a
    /// user's impl: always for a struct, an enum, a tuple or an ownership
    /// wrapper, and for the other built-in values only once a prelude trait
    /// has been implemented by hand for a built-in type.
    #[inline]
    pub(crate) fn may_have_user_ops(&self, v: &Value) -> bool {
        user_ops::may_have_user_ops(v)
            || (self.builtin_prelude_impls && v.impl_key().is_some())
    }

    pub fn lookup(&self, name: &str) -> EvalResult {
        self.env.get(name)
            .or_else(|| self.statics.get(name))
            .cloned()
            .ok_or_else(|| Signal::Panic(format!("undefined name '{}'", name)))
    }
    }
