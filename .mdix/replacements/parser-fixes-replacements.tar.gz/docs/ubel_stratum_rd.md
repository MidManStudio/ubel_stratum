# ubel_stratum_rd

## Overview

Recursive descent parser crate for Ubel Stratum. Lexes and parses
source text into the AST types defined in `ubel_stratum`. See
`PARSER_RULES.md` for the architecture (recursive descent for
declarations and statements, Pratt parsing for expressions, targeted
memoization for the few genuinely ambiguous cases).

## Modules

### `parsers/parse_pattern.rs`

**What it does:** Parses match arm patterns and struct/array destructure
patterns.

**Tests:** see `tests/fixtures/ok_wildcard_and_discard_isolated.ubl`,
`tests/fixtures/ok_callback_registry_combined.ubl`, and
`tests/fixtures/err_underscore_in_expression_position.ubl`.

### `parsers/parse_decl.rs`

**What it does:** Parses top-level and member declarations: functions,
methods, parameters, structs, enums, traits, impls.

**Decisions:**
- Added a `TokenType::Underscore` arm to `parse_param` for `_: Type`
  parameters, producing `ParamKind::Discard`.
- `parse_static_decl` parses `[pub] static NAME: Type = expr` into
  `Item::Static`. The type annotation is required, and every failure
  path emits its diagnostic and then calls `recover_to_decl()` so the
  rest of the declaration is not parsed a second time as a stray item.
  `apply_block_attrs` merges only the generic attributes into a static,
  never a tier. See `docs/PARSER_RULES.md`, section 5.7a.
- `parse_item_or_block` checks the item's OWN `@tier(...)` attribute
  (found by name in the attributes parsed directly in front of it, not the
  block-merged list): on a `const` it is `PARSE-004`; on a `static`,
  `@tier(mid)` and `@tier(low)` are `PARSE-004` and `@tier(high)` is
  accepted. A tier block around either is not reported.
- `TokenType::Static` joined the three declaration sync sets.
- `parse_trait_decl` reads an optional supertrait list through
  `parse_supertraits`, and a type parameter's bounds and the supertrait list both
  go through `parse_trait_bound_list` (in `parse_type.rs`): `A + B<int>` after
  the name and any generic parameters, or after a parameter's `:`, stored as
  `TraitBound { name, args, span }` per entry. A `<` after a bound's name always
  opens its arguments, which are read with `try_parse_generic_args`. A colon or a
  `+` with no name after it is one parse error (`expected supertrait name`, or
  `expected trait bound name`) and the parse goes on. The list is sized with
  `cap::BOUNDS`.
- `parse_generic_params` closes the list with `at_generic_close` and
  `eat_generic_close`, not a plain `>`: a bound with arguments that ends the list
  (`T: Convert<int>>`) closes with one `>>` token, which is two closes.
- `parse_impl_block` keeps the type arguments written after the trait when `for`
  follows (`impl Convert<int> for X`, stored as `trait_args`) and drops them for an
  inherent impl (`impl Box<int> { .. }`), where they are part of the type.
- The tier of a method is resolved here, in this order: its own `@tier`, the `@tier` of
  the `impl`, `extend` or struct around it, a tier block around that, then `HIGH`
  (`PARSER_RULES.md` 5.11). `has_own_tier` in `parse_attr.rs` decides by the attribute's
  name whether a method writes a tier, so an unrelated attribute such as `@inline` keeps
  the block's tier. `parse_struct_decl` hands the struct's own `@tier` to
  `parse_struct_member`, `parse_trait_decl` hands the trait's to `parse_trait_item` (which
  gives a signature `MethodSig.tier` and a default method `MethodDecl.tier`), and
  `apply_block_attrs` moves the methods of a struct, an `impl`, an `extend` or a trait that
  write none to the block's tier (`retier_methods`, `retier_members`, `retier_trait_items`).
  `MethodSig` gained `attributes` and `tier`; nothing else was added to the AST. An impl
  method that writes no tier is decided in sema (`PARSER_RULES.md` 5.11).

**Tests:** see `tests/fixtures/ok_wildcard_and_discard_isolated.ubl` and
`tests/fixtures/ok_callback_registry_combined.ubl`; for `static`, the
five `ok_static_*` and seven `err_*static*`/`err_const_tier_*` fixtures
and `tests/statics.rs` below.

### `tests/type_aliases.rs`, `tests/member_calls.rs`, `tests/diagnostic_spans.rs`

**What it does:** Integration tests for the four confirmed bugs taken
down together (`docs/PARKED_IDEAS.md`, "Taking down the confirmed bugs").
Each goes through `check_source` for the stage and codes, and through the
interpreter (sema, then `set_int_literal_types`, then `run_program`) where
a test needs runtime values.

**Decisions:**
- `type_aliases.rs` (20): transparency in type position for every alias
  shape, `TYPE-121` once per alias in a cycle and not for an unrelated
  alias beside it, no cascade from a cyclic alias, `TYPE-108` for a wrong
  generic count, and the expression and pattern positions (struct literal,
  associated call, every enum variant shape, struct and enum patterns), with
  values asserted to carry the real type name.
- `member_calls.rs` (17): an unknown method on a plain enum and on an enum
  with an `extend` block, one `UnknownVariant` per typo (not two), enum
  methods running on unit and payload variants, associated functions on an
  enum, and function-typed fields (called, closures, generic holders, a
  method winning over a field, wrong argument type, wrong return type, a
  non-function field, an unknown name).
- `diagnostic_spans.rs` (3): asserts the LINE of a nested generic mismatch,
  which a count-only test cannot see.
- Mutation-checked: reverting the span fix fails exactly the three span
  tests; removing enum dispatch fails exactly the four enum-runtime tests;
  making aliases nominal again fails 15 of the 20 alias tests (the other 5
  exercise the separate `type_def_of` construction path).

### `tests/traits.rs`

**What it does:** Integration tests for nominal traits, slice S1a (42
tests). Source goes through `check_source` for the stage and codes, and
through the interpreter (sema, then both setters, then `run_program`) where a
test needs runtime values.

**Decisions:**
- Pins exact codes and counts for `TYPE-122` to `TYPE-129`, the exact text
  of the signature-mismatch and ambiguity messages, declaration-order
  independence, inherent-before-trait in both block orders, and the runtime
  contract that a call made through a trait runs the trait's method. One
  test runs without `set_trait_call_sites` to document why that table exists.
- Mutation-checked: removing the call-site recording fails the one test that
  expects the trait's method (18, not 14); removing the signature comparison
  fails the three `TYPE-125` tests; the original inherent-versus-two-traits
  bug fails two tests.

### `tests/supertraits.rs`

**What it does:** Integration tests for supertraits, slice S3a (65 tests).
Source goes through `check_source` for the stage, codes, messages, suggestions
and positions, through the parser for the recorded shape and spans, and through
the interpreter (sema, then both setters, then `run_program`) where a test needs
runtime values.

**Decisions:**
- Pins the parsed shape (none, one, several in the written order, after generic
  parameters, on a bodiless or public trait, the span of each name, and one
  parse error for a colon or a `+` with no name), the prelude's own declared
  supertraits, the exact text and count of `TYPE-132` (first missing link,
  transitive links, source order, derive versus impl suggestion), what a bound
  implies in a body and at a call (and that the implication runs one way), the
  default body's view of its supertraits, names (`TYPE-122`), cycles (`TYPE-133`:
  direct, two, three, two separate, a trait that only leads into one, a diamond,
  a repeated name, the path text, the span, the suggestion), shadowing, and the
  runtime contract that a call through a bound runs the supertrait's method and
  not an inherent method of the same name.
- Four fixtures sit beside it: `ok_trait_supertrait_isolated`,
  `ok_trait_supertrait_combined`, `err_trait_supertrait_missing_impl_isolated`
  and `err_trait_supertrait_names_combined`.
- Mutation-checked: 34 mutations of the parser, the prelude, the supertrait
  registry, the cycle walk, the closure, the impl check and the error enum; 32
  are caught. The first pass left three alive. One exposed a weak test (a
  repeated supertrait only matters in a self-cycle) and is now killed; the cycle
  walk's visited check is a performance guard that changes no diagnostic; and the
  `Self` bound that `collect_trait_info` inserts is never consulted there
  (removing it entirely changes nothing), so that line was left as it was.

### `tests/generic_traits.rs`

**What it does:** Integration tests for generic traits, bounds with arguments and
generic supertraits, slice S3b (79 tests). Source goes through `check_source` for
the stage, codes, messages, suggestions and positions, through the parser for the
recorded shape, and through the interpreter where a test needs runtime values.

**Decisions:**
- Pins the parsed shape (an impl's arguments, none for an inherent impl, nested
  arguments and the `>>` that closes a bound and the parameter list at once,
  several bounds and parameters in order, a bound naming another parameter, a
  supertrait's arguments), declaring and implementing a generic trait (two
  parameters, different arguments for different types, the argument count at an
  impl, a method that must fit the arguments, a second impl as `TYPE-128`
  whatever its arguments, a trait parameter's own bound), calling through a
  concrete type (the impl's types, defaults, a method taking the parameter, the
  qualified form), bounds with arguments (concrete, naming another parameter,
  decided by the impl, a mismatch after the impl decided, wrong counts including
  inside a trait's own scope, conflicts as `TYPE-134`, struct parameters, aliases,
  a function declared before its trait), generic supertraits (the argument carried
  through one and two levels, a fixed argument, `Self` in an argument, a bound on
  the sub-trait meeting a requirement on the supertrait only with the same
  argument, `TYPE-132` naming the argument, cycles), the prelude traits taking no
  arguments, and the runtime contract that each type runs its own impl, through a
  bound whose argument is a parameter too.
- Four fixtures sit beside it: `ok_trait_generic_isolated`,
  `ok_trait_generic_combined`, `err_trait_generic_impls_isolated` and
  `err_trait_generic_bounds_combined`.
- The old test asserting that a generic trait is reported (`TYPE-129`) became one
  asserting it is accepted.
- Mutation-checked: 41 mutations of the parser, bound registration, the argument
  conversion pass, the supertrait closure, obligations, impl registration, the
  qualified call and the error enum. 39 are caught. One pointed at a dedupe the
  closure already does and was removed as dead code, and the last, the `Self` bound
  that `collect_trait_info` inserts, is never read there (removing the line
  entirely changes nothing), so it is left as it was. The first pass left five
  alive; three needed tests (a bound with too few or too many arguments only
  reaches the scopes built from a trait's own parameters; a conflicting bound
  must not also fail every call).

### `tests/method_generics.rs`

**What it does:** Integration tests for a method's own generic parameters and for
bounds on a type alias parameter, slice S3c (66 tests). Source goes through
`check_source` for the stage, codes, messages and positions, and through the
interpreter where a test needs runtime values.

**Decisions:**
- Alias bounds: declared without error, met and unmet at a use (one `TYPE-126`, at
  the use, once for an annotation), a bound with a trait argument, a name that is
  not a trait, a wrong argument count, conflicting bounds, the same bound twice,
  a use through another alias, a use inside a generic function with and without
  the bound, a two-parameter alias where only one is bounded, an unbounded alias of
  a bounded struct, and the value behaving as the aliased type at run time.
- Own parameters: each call chooses its own types, a wrong result type, a wrong
  argument count, a bound met and unmet (reported at the argument for that
  parameter, once for two arguments of the same parameter), a bound with a trait
  argument, a bound argument the impl decides, a bound naming an earlier own
  parameter, an associated function, `extend` and inherent `impl` methods, a
  generic struct (the own parameter after the struct's, a bounded one asked at its
  own index, a receiver with too few or too many type arguments not shifting it),
  a method taking a function, bounds that build on a supertrait, the body
  (`TYPE-101` naming the parameter, `TYPE-130`, `TYPE-131`, an operator bound), and
  the checks at the declaration (`TYPE-122`, `TYPE-108`, `TYPE-134`, a repeated
  bound, a bad name beside a real bound reported once per declaration).
- Generic methods in traits: an impl that repeats the method (with renamed
  parameters) and runs, one that drops the parameters, drops a bound, adds a bound,
  adds a parameter or has other trait arguments in a bound (`TYPE-125` with the
  exact text), the order of bounds not mattering, a generic trait with a generic
  method, a bound that names the trait's parameter, `Self` beside an own parameter,
  a default body with its own bounds, calls through a bounded parameter and in the
  qualified form (types chosen per call, bound checked), an enum implementor, and
  an impl body checked against its own parameters.
- Six fixtures sit beside it: `ok_alias_bound_isolated`, `err_alias_bound_isolated`,
  `ok_method_generic_isolated`, `err_method_generic_isolated`,
  `ok_method_generic_combined` and `err_method_generic_combined`. The two tests in
  `tests/bounds.rs` that pinned the two limits as `TYPE-129` now assert that a
  bound there is declared without error. `err_bound_unsupported_combined` no longer
  has anything to show and is removed by the patch that comes with the delivery.
- Mutation-checked: 45 mutations of the alias bound registration and use, the own
  parameter scope, the bound checks, the instantiation per call, the renumbering of
  a trait method's parameters, the impl comparison, the signature text, the call
  sites and the display of parameter names. The first pass left nine alive and one
  did not build. Six needed tests (a bad name beside a real bound must not be
  reported twice; a receiver with too few or too many type arguments must not shift
  the method's own parameters; a bounded own parameter on a generic struct is asked
  at its own index; a bound that names the trait's parameter; a signature that names
  `Self` beside an own parameter). Three changed nothing a program can observe and
  were removed: an early `continue` for a parameter without bounds, and two guards
  in `instantiate_trait_shape`, whose argument list always has the trait's arity
  (now a debug assertion). All 42 that remain are caught.

### `tests/generic_impls.rs`

**What it does:** Integration tests for impls and `extend` blocks for generic types,
slice S3e (82 tests), plus the extended unit test in `interpreter/value.rs` that pins
`Value::impl_key` against `ast::types::builtin_impl_key` for the five generic
collections. Programs go through `check_source` for stage, codes, messages,
suggestions and positions and through the interpreter for run-time values.

**Decisions:**
- Parameters and scope: a parameter bound in the bodies, numbered by the place it
  occupies (`Pair<Y, X>`), an enum head, an inherent `impl<T>`, `extend<T>`, a
  method's own parameters inside a generic block, an associated function, `Self`.
- Conditions: a conditional impl through a bound, a qualified call and a method
  call; the argument that lacks the bound named at the call; a struct's own bound
  restated, checked on a concrete argument and in force in the body; a bound with
  arguments naming another parameter; a dictionary key needing `Hash`.
- Supertraits and prelude traits on a generic impl, including a conditional
  `PartialEq` and `PartialOrd` driving the operators and not there for an argument
  that lacks them, and a derive that overlaps a hand-written impl.
- Concrete positions: an impl and an `extend` for one instance apply to that
  instance only (`TYPE-104` for another, `TYPE-126` through a bound), also mixed with
  a parameter.
- The five built-in heads each through a direct call, the generic ones through a
  bound and a qualified call; an alias of a collection; a native method winning;
  bare `extend List` and `extend Box` keeping their meaning.
- Overlap and duplicates: one impl per head whatever the arguments, an array and a
  `List`, one inherent definition per name for a generic head and for a run-time kind
  (`int` and `long`).
- Every unsupported target, with its exact text and position, and the count
  mistakes (`TYPE-108`).

**Mutation pass:** 74 mutations over `sema/type_infer/impl_patterns.rs`,
`sema/type_infer.rs`, `ast/types.rs` and `interpreter/value.rs`, 70 caught. Three survivors are equivalent mutants (the run-time key text sema gives `Dictionary`, which is only compared with itself, and the undecided answer of an impl guard, which every consumer treats like a satisfied one because an obligation fails only on a definite no); one more showed an arity entry for a built-in head's definition that no reader reaches, and was removed as dead code. Every other mutant was caught, after tests were added for the first survivors.

### `tests/method_tiers.rs`

**What it does:** Integration tests for the tier of a method and the tier check on a call
on a receiver, slice S4a (43 tests). Programs go through `check_source` for stage, codes,
messages and positions and through the interpreter for run-time values.

**Decisions:**
- The call rule: every caller and callee tier pair generated into a program; the message
  naming both tiers and the method; the error placed at the call; one diagnostic per
  offending call; every route to a method (an `extend`, an `impl`, a struct member, a
  trait impl, an associated function, a method of a built-in type, a generic struct, a
  generic impl for one instance, a sibling method), and a built-in method carrying no tier.
- Where a tier comes from: an unrelated attribute never changes it; a method's own `@tier`
  wins over the `impl`, `extend`, struct and tier block around it; a tier block moves only
  the methods that write none; an item's own tier survives a block; the innermost block
  wins; an `async` method that inherits `LOW` is `TIER-003`, one that writes `@tier(high)`
  is fine.
- The cases that first sat here as "not checked yet" (a call through a bound, a default
  method call, a `@tier` on a trait default method) became checks in S4b and moved to
  `tests/trait_tiers.rs`.
- Run time unchanged: `LOW` methods called from `LOW` code run.

**Mutation pass:** 31 mutations over `parsers/parse_attr.rs`, `parsers/parse_decl.rs`,
`prelude.rs`, `sema/type_infer.rs` and `sema/tier_check.rs`, 30 caught. Two were caught only
after three tests were added (a tier block around an `impl`, an `extend` or a struct whose
methods are partly tiered); the survivor is an equivalent mutant (the copy of a trait
shape's tier, `None` for every trait shape until S4b). The mutant that removes the
prelude's `Hasher` tier is caught by `tests/prelude_traits.rs`.

### `tests/trait_tiers.rs`

**What it does:** Integration tests for tiers on traits, slice S4b (47 tests). Programs go
through `check_source` for stage, codes, messages, suggestions and positions and through the
interpreter for run-time values.

**Decisions:**
- Where a trait method's tier comes from: a trait with none is `HIGH`; a `@tier` on a
  signature or a default method is applied (and a default method's body is checked at it);
  the trait's `@tier` is the default; a method's own tier wins; an unrelated attribute
  changes nothing; a tier block moves only the signatures and default methods that write
  none; an item's own tier survives a block; the innermost block wins.
- Calls: every caller and declared tier pair, generated into a program, through a bound
  and through a qualified call; the message and the position; the abstract `Self` in a
  default body; a supertrait bound; a bounded struct's method; a default method on a
  concrete receiver.
- Conformance: every trait and impl tier pair under exact match (equal accepted, higher and
  lower `TIER-016`); the message, the suggestion and the position; one report per method; an
  unrelated attribute is not a written tier; an impl method that writes none takes the
  trait's (its body is checked at that tier and a call to it uses it); a tier written on the
  method, the `impl` (even `@tier(high)`) or a tier block around it is a written tier; an
  override of a default method; an impl for a built-in type and a generic impl; a mismatched
  method is still called at its own tier.
- The prelude traits are `LOW`: every tier can call their methods through a bound; a
  hand-written impl has to be `LOW`, and its body may not call a `HIGH` function (`TIER-005`),
  read a `static` (`TIER-015`) or build a collection (`TIER-009`); derived and native
  methods carry no tier.
- `async` keeps its rule, and the run-time results are unchanged.

**Mutation pass:** 33 mutations over `parsers/parse_decl.rs`, `prelude.rs`, `sema/type_infer.rs`,
`sema/tier_check.rs`, `sema/sema_context.rs` and `errors/tier/mod.rs`, 30 caught. Two were
caught only after tests were added (a default method that writes its own tier inside a tier
block around a trait, and a mismatched impl method that is still called at its own tier). One
condition was redundant and was removed instead of tested (a tier block merges its own
`@tier` into the impl's attributes, so checking the impl's tier field as well added nothing).
Two are equivalent mutants: the fallback tier of a trait method shape (every trait method
shape carries a tier), and the tier on `Eq`, which has no methods.

### `tests/display.rs`

**What it does:** Integration tests for `Display` and the order a struct prints in, slice
S5a (39 tests). Programs go through `check_source` for stage, codes and messages and through
the interpreter for the printed output.

**Decisions:**
- Order: a struct prints its fields in declaration order, in `Display` and in `Debug`; an
  anonymous object in the order written; an enum's struct variant sorted by name. Each of
  these runs thirty values in one program, because every value owns a hash map with its own
  seed and a single value could be in the right order by chance. The declared order is
  chosen so that sorting would show.
- Use of an impl: `println`, `print`, interpolation with width and alignment, `to_string` as
  a method, as a function and qualified, several arguments, `assert` and `panic` messages;
  `{x:?}` stays structural; a type with no impl, and every other type, prints as before.
- Depth: a field of a struct with no impl, an enum's tuple and struct payload, a tuple, a
  list, a dictionary key and value, a queue, a stack, an inline list, and the three ownership
  wrappers. Two tests compare the same containers around a value with an impl and around the
  text the impl returns and require identical output, which is what keeps the substitution
  from changing any output shape.
- The scalars satisfy `Display` natively (every scalar, sized integers included); a type with
  no impl, a collection and a tuple do not satisfy the bound; a type with no impl has no
  `to_string`.
- Impl rules: an impl for a scalar is `TYPE-128`, for a collection or an array `TYPE-129`
  (and a list prints as before); the method has to match the trait; `Display` is not a derive;
  a program's own `Display` trait takes the name; the trait is `LOW` (a written higher tier is
  `TIER-016`, the body is checked at `LOW`, every tier can call it through a bound).

**Mutation pass:** 47 mutations over `interpreter/value.rs`, `interpreter/eval/expr.rs`,
`interpreter/eval/mod.rs`, `interpreter/eval/display.rs`, `sema/type_infer.rs` and
`prelude.rs`, 46 caught. Two were caught only after tests were added (the order of a struct's
`Debug` form, and a qualified call on a scalar, which also found that call panicking at run
time and led to the runtime fix). The survivor is an equivalent mutant (returning a copy of a
value where nothing changed instead of nothing).

### `tests/iterator.rs`

**What it does:** Integration tests for `Iterator<T>` and for what a `for` loop can walk, slice
S5b (53 tests). Programs go through `check_source` for stage, codes, messages, suggestions and
spans, and through the interpreter for the printed output.

**Decisions:**
- A user iterator: the loop runs until `next` returns `null`; it advances the struct itself
  (the field read after the loop, and a second loop that resumes after a `break`); an empty
  iterator never runs the body; `continue`, `break` and a `return` from inside the loop;
  nested loops over separate iterators; an endless iterator stopped by `break` (which only
  works because the loop is lazy); string and struct items; a generic struct
  (`impl<T> Iterator<T> for Once<T>`); an enum; a bound (`I: Iterator<int>`), whose item type
  is the loop variable's type; a `Unique` or `Shared` wrapper and a borrowed value; the trait's
  `next` winning over an inherent one of the same name; a loop in a `HIGH`, `MID` and `LOW`
  function.
- Built-in loops: a `Queue` front to back, a `Stack` bottom to top with its printed form and
  `peek` beside it, a `Dictionary` as pairs in insertion order (destructured, and as one
  variable typed as a pair), the element types of a queue and a stack, a snapshot (the
  collection changed inside the loop), the other iterables unchanged, and a `T?` or `T!`
  collection.
- `TYPE-135`: a scalar of each kind, an integer literal, an optional scalar, a struct and an
  enum with no impl (with the message and the suggestion), a `Linqerizer`, a function, an
  unbounded type parameter (named in the message), a bound that is not `Iterator`, a program's
  own trait named `Iterator`; not reported for a value of unknown type, after an earlier error,
  or for an expression that already failed (a dereference of a non-reference and an `await` on
  a non-task, which crashed the type checker before); where it points.
- `TYPE-129`: an optional item type, reported once at the impl, and at the loop when an item
  becomes optional through a generic argument or a bound; an impl for each kind of built-in
  type. Also `TYPE-125`, `TYPE-123` and `TYPE-128` for a wrong signature, a missing `next` and a
  second impl, and `TIER-016`, `TIER-009` and `TIER-015` for the `LOW` rules on `next`.

**Mutation pass:** 40 mutations over `sema/type_infer.rs`,
`error_management/errors/types/mod.rs`, `interpreter/eval/stmt.rs`,
`interpreter/eval/user_ops.rs` and `rd_parser/src/prelude.rs`, 39 caught (three of them by the
test run timing out, because the mutated loop never ends). Two were caught only after tests were
added: a loop over an expression that already failed (which found the type-checker crash above
and led to the fix) and where `TYPE-135` points. The survivor is an equivalent mutant (reading
the last type argument of an `Iterator` impl instead of the first, when `Iterator` has one).

### `tests/operators.rs`

**What it does:** Integration tests for the operator traits, slice S5c (68 tests). Programs go
through `check_source` for stage, codes, messages and suggestions and through the interpreter
for run-time values.

**Decisions:**
- Each of the ten binary operators, its compound assignment and `Neg`/`BitNot` is generated
  from a table into a program whose only impl is that trait, with a marker in the result, so a
  run that reaches a neighbouring trait, or sema that resolves through one, fails. A second
  table checks each operator against the next trait (`TYPE-136` for `v + 1` with only `Sub`).
- Run time: several impls of one operator by right operand, a number and a string on the left,
  a result of another type, an integer literal against an integer impl (and against `Mul<u32,
  V>`, which gives the literal that type), operators in methods and loops, an enum operand, a
  generic struct, a supertrait default method, closure parameters with no type, a right operand
  not known yet, `Unique` and `Shared` values (probed, not a test), and numbers and strings
  next to a program full of impls.
- Bounds: numbers, strings and impls satisfy `T: Add<T, T>`; `string` satisfies `Add` only,
  an unsigned number does not satisfy `Neg`, a float does not satisfy a bitwise trait; one
  bound per right operand; the operator method by name through a bound, on a struct and on a
  number (`neg`, `bit_not`, `shl`).
- Diagnostics: `TYPE-136` (the pair, the impls there are, an integer literal, unary, a number
  on the left, compound, nothing reported twice), `TYPE-131` for every operator and the
  suggestion with the bound, `TYPE-126` for an unsatisfied bound and for another right
  operand, `TYPE-128` (same kind twice, a unary trait twice, `Box<int>` with `Box<double>`),
  `TYPE-129` (a number with a number, a collection, a tuple, a bare type parameter),
  `TYPE-134` for one right operand with two results, and `TIER-016` for every operator trait.
- A program's own trait named `Add` takes the name, and its `+` is left to the run time.
- An expression that already failed to type (`*` on a non-reference, `await` on a non-task) adds
  nothing when it is read as a field or used as an operand of any operator form; both used to
  panic the type checker.

**Mutation pass:** 39 mutations over `sema/type_infer.rs`, `interpreter/eval/user_ops.rs`,
`interpreter/eval/expr.rs`, `interpreter/eval/mod.rs` and `rd_parser/src/prelude.rs`, 34
caught, one redundant and four dead. Five of the first 32 survived and four were caught after tests were added: the explicit
`neg` and `bit_not` calls on numbers (two mutants), the tier of every operator trait (the
prelude `Neg` without `@tier(low)`), and a right operand not known yet (decided by the only
impl). The first run also showed the supertrait expansion dropping a second bound of one
operator trait, found by a fixture before a test existed. The survivor is a redundant
condition: skipping candidates whose right operand has another run-time kind before comparing
types changes nothing, because the comparison rejects them too. Seven mutations removed an
early return for the error type (in the field read, `peel_wrappers` and five operator helpers);
three were caught, and the four that survived were guards no path reaches (the operator site
returns before any of those helpers sees an operand that already failed), so they were
deleted, and so were two more of the same kind in `native_operator` and `operator_operand_text`.

### `tests/index.rs`

**What it does:** Integration tests for the index traits and the typed built-in indexing, slice
S5d (47 tests). Programs go through `check_source` for stage, codes, messages and suggestions
and through the interpreter for run-time values.

**Decisions:**
- Run time: a read, a write and a compound assignment through impls; one type with `Index` for
  an `int`, a `(int, int)` and a `string`; nested indexing with a field write at the end
  (`t[0][1].x = 20`); a read-only type, a write-only type, an enum, a generic type, `Shared` and
  `Unique` values (indexed once, since `Unique` is moved by the first use on the baseline too), an
  optional list, and the methods by name.
- Bounds: `List`, `Dictionary`, string and impls satisfy `Index` and `IndexSet` bounds with the
  right argument shapes (`[int, T]`, `[K, V]`, `[int, char]`), a string does not satisfy the
  write bound, another kind of index does not satisfy a bound, a read bound does not allow a
  write, an unbounded parameter is `TYPE-131` with the bound in the suggestion, and
  `c.index_set(i, v)` through a bound runs for a struct, a list and a dictionary.
- Diagnostics: `TYPE-136` for a missing read impl (the kinds the type has, the suggestion
  without any), a missing write impl, and both sides of a compound assignment; `TYPE-137` for a
  `Queue`, `Stack`, `Set`, number, and an assignment through a string or tuple; `TYPE-101` for
  the index of a list, string, tuple, array and dictionary and for the stored value, in the
  expected-then-found order; `TYPE-128`, `TYPE-129` (five built-in targets, a number with a
  struct index, a bare type parameter) and `TIER-016`.
- Negative index on a write counts from the end; one past the start or the end is a panic that
  names the index as written.
- Tuples unify item by item, and another arity or another item is a mismatch.
- A program trait named `Index` shadows the read side only; `IndexSet` stays the prelude's.

**Mutation pass:** 30 mutations over `sema/type_infer.rs`, `interpreter/eval/expr.rs`,
`interpreter/eval/user_ops.rs` and `rd_parser/src/prelude.rs`, 29 caught and one redundant: the
shadow guard in `index_site` repeated what `operator_site` already does first (it returns
`None` for a shadowed trait), so the guard was deleted and the behavior got its own test. The
first run of the new tests found three mistakes in the tests themselves (a `Unique` value moved
by its first index, an `L` literal suffix Ubel does not have, and a tuple literal as the first
call argument, which does not parse).


### `tests/dyn_trait.rs`

**What it does:** Integration tests for `dyn Trait`, slice S6 (73 tests). Programs go
through `check_source` for stage, codes, messages and suggestions and through the interpreter for
run-time values.

**Decisions:**
- Run time: a list, a dictionary, a queue and a stack of `dyn`, an array literal coerced element by
  element (also through a `type` alias and for `&dyn`), a field, an enum payload (tuple and struct
  form), an optional, `as dyn`, an assignment, a parameter and a return, a method argument, an
  untyped lambda parameter, a default method, a supertrait method, a generic trait
  (`dyn Convert<int>`), a bound satisfied by a `dyn`, built-in types behind `dyn`, a generic struct
  holding a `dyn` of its parameter, and `+`, `[]`, `for` and `Display` on a `dyn` of the matching
  trait.
- Tiers: `&dyn`, `Unique<dyn>`, `Shared<dyn>` and `SyncShared<dyn>` in `LOW`, a local borrowed as
  `&dyn` in `LOW`, an arena value borrowed as `&dyn` in `MID`, `TIER-005` through `dyn` for a
  `LOW` caller of a `MID` or `HIGH` method, `TIER-004` for an arena value written into a bare
  `dyn`, and the arena borrow that is not elided for a function returning `dyn`.
- Errors: `TYPE-138` for each way a trait is not object safe (no `self`, generic method, `Self`
  in a parameter, in the result, nested, through a supertrait), every violation in one
  diagnostic, the prelude traits, a trait declared after its use, one report per written type
  (parameter, method signature and function result); `TYPE-126` at every coercion site;
  `TYPE-101` for a missing conversion between `dyn` types, between arguments, to a type, a
  wrapper that would be removed and a list of the wrong element type; `TYPE-122`, `TYPE-108`,
  `TYPE-104`, `TYPE-118`, `TYPE-129`, `TYPE-135`, `TYPE-136` and `LIFETIME-001` through `dyn`.

**Mutation pass:** three passes over `sema/type_infer/dyn_trait.rs`, `sema/type_infer.rs`, `sema/type_infer/impl_patterns.rs`, `sema/type_table.rs`, `rd_parser/parsers/parse_type.rs` and `errors/types/mod.rs`. The last pass ran 64 mutants and 63 were caught. The first pass left 19 survivors, each classified: seven were missing tests (a function result type reported once, an optional of a type for an optional `dyn`, a `&Circle` and a `Unique<Circle>` that must not lose their wrapper, `List.set`, `InlineList.push` and the method-argument site) and the tests were added; ten were redundant, equivalent or dead and were deleted (the equal-types early exit, the hint reset, the special cases for an unknown type and a literal variable, and four wrapper lock-step arms that no program reaches); one, the array hint, was simplified so that every part of it is exercised. Later passes found the `deep_apply` arm dead, a literal-variable guard equivalent, and two of the three impl-target arms repeating each other, and those were deleted. The one survivor of the last pass is the `dyn` arm of `count_ref_lifetime`: the match is exhaustive so the arm has to exist, and it only changes the result for a lifetime named inside the arguments of the borrowed parameter itself, which no test pins. The first run of the new tests found one mistake in the tests themselves (a square's area is `side * side`).

### `tests/call_and_return_parsing.rs`

**What it does:** Two parser fixes (13 tests): a call whose first argument starts with `(`, and the
tokens after which `return` reads a value. Programs go through `check_source` and the interpreter.

**Decisions:**
- Parenthesis: a grouped expression, a grouped name, a tuple, parentheses several deep, a grouped
  first and second argument, and a method call, each printed by the interpreter, plus an unclosed
  call that is still a parse error.
- `ROWS` has one row per kind of expression start that `parse_prefix` accepts (an integer, a typed
  integer, a double, a string, a char, both booleans, `-`, `!`, `not`, `~`, a group, an array, an
  `if`, and the six collection names), each written after `return` and printed. A literal followed
  by an operator (`return 3.0 * 2.0 * 2.0`) is the original bug. A bare `return` still returns
  nothing.

**Mutation:** restoring the double consume in `parse_call` and dropping the advance in `parse_dot`
fail 4 or more tests each; removing `DoubleLit`, `TypedIntLit` or any one of the collection tokens
from `can_start_expr` each fails the table.

### `tests/pipe.rs`

**What it does:** The pipe operator, lowered to a call by the parser (30 tests, `PARSER_RULES.md`
section 5.13).

**Decisions:**
- Run time: a bare function, an empty call, the piped value as the first argument (`10 |> sub(3)`
  is 7), chains, a lambda stage, any expression as the piped value, a pipe inside an argument, a
  method, a trait method, a static function and an enum variant as a stage, and precedence
  against `+` and `==`.
- Types: the result has the return type of the stage, the piped value is checked against the first
  parameter, a stage short of arguments is `TYPE-102`, and `?` on a stage unwraps once (also in a
  chain, and after a call stage with arguments).
- A method stage is the same call as `a.m(x)`: it obeys the tier rule (`TIER-005` from a `LOW`
  function to a `HIGH` method, which a bare path stage let through), an unknown method is
  `TYPE-104` with the span of the stage head alone, and a dotted name inside an argument stays a
  path.

**Mutation:** inserting the piped value last, dropping the `Try` wrapper, dropping the piped
argument of a bare stage, reading a method stage as a path and letting the stage head span run on
to the next token are each caught. Merging the span of the lowered call with its stage, and the
span of the `Try` with its call, survive: no program that exists today can observe it.

### `tests/array_literal_hints.rs`

**What it does:** An array literal handed to a written `dyn` element type at a site other than a
`let` (16 tests, `TRAITS_DESIGN.md`, "What S6 settled").

**Decisions:**
- Sites covered: a plain function argument (first, second and named), a `return`, a struct field, a
  field of an enum struct variant and an element of an outer literal.
- What it must not change: a literal of plain elements, mixed plain elements (still `TYPE-101`), a
  generic callee, a non-literal argument, an empty literal, and a missing impl in the literal, now
  one `TYPE-126` instead of `expected Sq, found Tri`.
- A hint armed for a non-literal must not reach a later literal in the program.
- Not covered and not tested: a method argument, a tail expression, a tuple variant payload, a
  generic callee whose parameter holds a placeholder.

**Mutation:** each site turned off is caught by its own test, and so is arming the hint for a
value that is not a literal. Skipping the placeholder guard on a generic callee survives: it only
changes which error an already unsupported call reports.

### `tests/inline_list_index.rs`

**What it does:** `InlineList` indexing at run time (13 tests). Sema accepted it since S5d and the
interpreter panicked.

**Decisions:**
- Read, assign, compound assign, a negative index from the end, a string element and a loop.
- Out of range is checked against the items present, not the capacity (`len 2` in the message for
  a capacity of 4).
- `index` and `index_set` through an `Index` or `IndexSet` bound reach the other two run-time arms
  (`eval_index` through the operator path and `native_index_set`); explicit `.index(i)` on the
  collection itself is not accepted by sema, for a `List` as well.

**Mutation:** each of the three arms disabled, the negative-index rule and the bound check are
caught.

### `tests/nesting_limit.rs`

**What it does:** The nesting limit and the large stack (19 tests, `PARSER_RULES.md` section 5.14).

**Decisions:**
- Within the limit and run on the large stack: a string chain of 900 operands (the shape of the
  original report), integer and `*` chains, 900 nested parentheses, calls and blocks, and a chain
  of 998 operands, the longest that fits.
- Past it, one `PARSE-006` and nothing else: 999 operands, 1100, 20 000, parentheses, calls,
  blocks and a pipe chain. An earlier parse error is kept; a later one is not reported.
- The programs run through `ubel_stratum::stack::with_big_stack`, as the CLI does; a test thread
  has 2 MB.

**Mutation:** not counting the chain, not entering a level in `parse_bp` or in a block, a limit of
1100 or 2000, reporting twice, and not suppressing later errors are each caught. Four mutants
survive, all behaviour-equivalent (see `tests/pipe.rs` and `PARSER_RULES.md` 5.13).

### `tests/builtin_impls.rs`

**What it does:** Integration tests for impls and `extend` blocks on built-in
types, slice S3d (51 tests), plus a unit test in `interpreter/value.rs` that pins
`Value::impl_key` against `ast::types::builtin_impl_key` for every spelling of every
type. Programs go through `check_source` for stage, codes, messages and positions
and through the interpreter for run-time values.

**Decisions:**
- Every primitive spelling is generated into a program that implements a trait,
  calls it as a method, through a bound and in the qualified form, and takes an
  `extend` block; each prints its own spelling.
- Calls: a method with arguments, a literal in parentheses, `Self`, default methods
  three ways, a generic method on a primitive, a generic trait with its argument,
  aliases of primitives and of tuples, the body of an impl checked with `self` as the
  built-in type, `Self` in an `extend` signature.
- Sema keeps types apart: an impl for `int` does not satisfy `long`, a missing impl
  is `TYPE-104` or `TYPE-126`, types of different kinds each have an impl.
- One kind of value, one impl: `int`/`long` is `TYPE-128` with the exact text, every
  pair inside each of the seven kind groups, the same type twice, two traits on types
  of one kind, tuples of one arity (and of different arity side by side), two array
  types.
- Native methods win over `extend`, an `extend` method beats a trait method and the
  qualified form reaches the trait, two traits with one name are `TYPE-127`, the
  qualified form picks one, supertraits are required of a primitive impl, missing
  and mismatched methods are reported.
- Prelude traits: refused where native (`Eq` for `int`, `Hash` for `string`, `Clone`
  for `bool`, `PartialEq` for a tuple) with the exact message, allowed where not
  (`Hash` for `double` makes a dictionary key), needing their supertraits, ordering
  operators on `bool` and `char`, a hand-written impl used through a bound and in the
  qualified form.
- A method that does not exist on a primitive is `TYPE-104` (it used to panic), a
  function without `self` is not a method, an array parameter keeps its native
  methods, `impl` and `extend` for a collection are `TYPE-129`, errors inside a
  built-in target are reported once, and structs and enums keep working beside all
  of it.
- Four fixtures sit beside it: `ok_builtin_impl_isolated`, `err_builtin_impl_isolated`,
  `ok_builtin_impl_combined` and `err_builtin_impl_combined`. The two tests that
  pinned built-in impls as `TYPE-129` (`tests/traits.rs`, `tests/prelude_traits.rs`)
  now assert the new behaviour.
- Mutation-checked: 39 mutations of the key mapping, the definitions, the
  conversion of a target, the overlap rules, the prelude status, the bound checks,
  the call hooks, the `Self` handling and the interpreter's registration and
  dispatch. The first pass left six alive. Four needed tests (an arity error inside
  a tuple target reported once, `Self` in an `extend` signature, a native method on
  an array parameter, the key unit test), and one of those found a real gap, `self`
  untyped in the body of a built-in impl, which is fixed. One conjunct of the
  primitive check could not matter and was removed, and one change to the qualified
  call turned out to be unneeded and was reverted. Run again on the finished code,
  38 of the 39 are caught. The one that is not changes nothing a program can
  observe: the empty-table fast path in `builtin_def_of`, kept because it spares a
  type-text allocation on every method call of a program without built-in impls.

### `prelude.rs`, `tests/prelude_traits.rs`

**What it does:** `prelude.rs` holds the declarations every program sees
without writing them (`Ordering`, `PartialEq`, `Eq`, `PartialOrd`, `Ord`,
`Clone`, `Display`, `Iterator`, the twelve operator traits `Add`, `Sub`, `Mul`, `Div`, `Rem`, `BitAnd`,
`BitOr`, `BitXor`, `Shl`, `Shr`, `Neg`, `BitNot`, `Index` and `IndexSet`, `Hasher`, `Hash`) as Ubel source. `Hasher` and the traits are `@tier(low)`, so code at any tier can
hash, show and call their methods through a bound: the prelude is ordinary source and its methods are `HIGH` unless a tier is written.
`parse()` calls `prelude::inject` after parsing the
program. `tests/prelude_traits.rs` (95 tests) covers what each kind of type
satisfies, the methods, hashing, the `Dictionary` key requirement, the
operators on a type parameter, hand-written impls and what calls them
(operators, `contains`, dictionaries, `order_by`, `group_by`, derived
comparison, `Hash` and `Clone` inside other values) and shadowing.

**Decisions:**
- The prelude source is lexed once per process and every token span is
  shifted past `PRELUDE_SPAN_START`, so a prelude node cannot collide with a
  user node in sema's `Span`-keyed tables. The parser never slices the source
  by span, so this needs no other change.
- The reserved range starts at 2^31, computed from a `u32`, because `wasm32`
  has a 32-bit `usize`. The first version used 2^40, which compiled natively
  and failed the wasm playground build (`shift left by 40 would overflow`) when
  it was deployed; a 64-bit build cannot see that, so a unit test checks that
  the range and every prelude token span fit in a `u32`.
- A name the program declares itself is not injected, nor is anything that
  depends on it, so a prelude signature never binds to a user's type. What an
  item depends on is read from its declaration (its supertraits, now written in
  the prelude source: `trait Ord: PartialOrd + Eq`) plus the types its
  signatures mention (`SIGNATURE_DEPS`). Eleven unit tests in `prelude.rs` pin
  the dependencies, their order and the shadowing sets.
- The tests pin the satisfaction table kind by kind, the exact code and
  position of `TYPE-126`, `TYPE-131` and `TYPE-129`, and that a call through a
  bound or directly on a value runs the right native method.
- Mutation-checked: widening floats to `Eq` and `Ord` fails three tests; no
  supertrait expansion fails three; no operator bound check fails four; no
  prelude methods on values fails one; accepting hand-written impls fails two;
  no native prelude methods fails six; a shadowing rule that does not cascade
  fails five; enums that are not `PartialEq` fail one; collections that
  satisfy fail two; ordered tuples fail one. For part 2: floats that are
  `Hash` fail seven tests; enums that are not `Hash` fail three; no key check
  at an annotation fails five, at `Dictionary.new()` one, at the first `set` of
  an inferred dictionary one; an alias not checked at its use fails one and an
  alias checked at its declaration fails one; no same-line dedupe fails four; a
  `hash` that does nothing fails three; hashing that is not order-sensitive
  fails one; `Hash` without its supertraits fails one. For S2b: 69 mutations of
  the dispatch and the impl checks, each on the function itself, 68 are caught.
  The one that is not, the bit rotation in the hash mixer, changes no result a
  program can observe, because hash values are not a contract. The first pass
  left 17 alive and exposed missing tests (tuple, `Unique` and enum payload
  operands, a derived ordering that must move on to the next field, the `x.eq(y)`
  and `x.lt(y)` call forms, `group_by`, dictionary index assignment, inline-list
  `contains`, an impl written after the signature that needs it); each now has
  one.

### `tests/bounds.rs`

**What it does:** Integration tests for trait bounds, slice S1b (45
tests). Source goes through `check_source` for the stage, codes, messages and
positions, and through the interpreter (sema, then both setters, then
`run_program`) where a test needs runtime values.

**Decisions:**
- Pins the exact code, count and position of every bound diagnostic
  (`TYPE-122`, `TYPE-126`, `TYPE-129`, `TYPE-130`, and `TYPE-104` for a bound
  set that lacks the method), that an integer literal is reported as `int`,
  that diagnostics come out in source order, and the runtime contract that a
  call through a bound runs the trait's method even when the type has an
  inherent method of the same name. One test runs without
  `set_trait_call_sites` to document why that table exists.
- Covers each place a bound is enforced: a function call, a call through a
  variable, a list argument, a struct literal, an enum variant, a type
  annotation and a struct field, plus the places a bound must be visible
  (a generic struct's method, an `extend` block, a MID-tier function with an
  arena value).
- Mutation-checked: removing the `TYPE-130` report fails the four tests that
  expect it; removing the obligations at a function call fails the eight
  call-site tests; removing them at struct and enum construction fails three
  tests, and at type annotations three; installing no bounds for an `extend`
  body fails the two extend tests; checking obligations before literal types
  are settled fails six; and removing the span sort fails only the nested-call
  ordering test.

### `tests/statics.rs`

**What it does:** Integration tests for `static` items. Source goes
through `check_source` for the stage and diagnostic codes, and through
the interpreter (sema first, then `set_int_literal_types`, then
`run_program`) where a test needs runtime values.

**Decisions:**
- Pins what fixtures cannot see: the exact code and count per rule
  (`TIER-015`, `NAME-008`, `PARSE-004`, `PARSE-001`), that a malformed
  declaration is reported once, that a tier block around a const or
  static is not an own annotation, and the runtime contract that a
  static is one value shared by every function.
- Mutation-checked: disabling the static branch of `write_lvalue` fails
  exactly `a_static_is_one_value_shared_by_every_function`,
  `assignment_in_main_is_visible_to_a_function_and_back` and
  `a_closure_writes_the_shared_static`.

### `tests/int_literal_typing.rs`

**What it does:** Integration tests for context-driven typing of
unsuffixed integer literals. Source text goes through lex, parse and sema,
and where a test needs runtime values, through the interpreter with
output capture. Three helpers (`type_error_messages`, `recorded_widths`,
`run`) keep each test to one source string and one assertion.

**Decisions:**
- Covers what the `.ubl` fixtures cannot see: exact diagnostic counts and
  messages for `TYPE-120` at every boundary, which literals sema records
  in `int_literal_types`, that a run without that table panics on a
  sized/plain mix instead of guessing, and the two places an open literal
  is settled as `int` (end of body, type-dependent format spec).
- The interpreter is driven the same way `ubel run` drives it: sema
  first, then `set_int_literal_types`, then `run_program`.

### `check.rs`

**What it does:** `check_source(&str) -> CheckReport` runs lex, parse and
sema over a source string and returns every diagnostic as data, together
with the stage it stopped at (`Stage::Lex`, `Parse`, `Sema`, or `Clean`).
It is the one entry point both `ubel` (the command line) and `ubel-lsp`
(the language server) call, so the two report identical diagnostics for
the same text.

**Decisions:**
- Stops at the first stage that reports errors, since later stages have
  nothing sound to work on once an earlier one failed. Sema's own passes
  keep running after each other inside `analyse`, as before.
- Every per-phase error list is drained through the `Diagnosable` trait
  into one flat, phase-ordered `Vec<Diagnostic>`. Nothing here prints or
  renders; callers choose `render_all`, JSON, or LSP diagnostics.
- The AST borrows the `AstArena`, so the arena cannot leave the function.
  A caller that needs to run the program afterwards (`ubel run`) lexes and
  parses a second time. A `check_with_arena` variant is the fix if that
  cost ever matters.

**Tests:** unit tests in `check.rs`, and end to end through
`crates/cli/tests/cli_tests.rs` and `crates/lsp/tests/lsp_stdio.rs`.

### `cursor.rs`, `parsers/parse_type.rs`

**What it does:** `cursor.rs` is the token cursor every parser shares;
`parse_type.rs` parses type expressions (including `dyn Trait`, a contextual word handled in the
`Ident` arm, with a guard in the lifetime-label check), generic arguments and generic
declaration parameters.

**Decisions:**
- `Cursor` splits a `>>` token to close two nested generic argument
  lists (`at_generic_close`, `eat_generic_close`, `expect_generic_close`,
  private `split_at`). The lexer cannot make this call, only the parser
  knows a position is a type position. See `PARSER_RULES.md` §5.9.

**Tests:** `crates/rd_parser/tests/diagnostic_counts.rs`,
`tests/fixtures/ok_nested_generic_close_isolated.ubl`,
`tests/fixtures/ok_nested_generic_close_combined.ubl`,
`tests/fixtures/err_nested_generic_unclosed.ubl`.

### `parser.rs`, `parsers/parse_expr.rs`, `parsers/parse_stmt.rs`

**What it does:** `parser.rs` is the `Parser` struct and its shared
`enter`/`leave`-style state-swap helpers; `parse_expr.rs` is the Pratt
expression parser; `parse_stmt.rs` is statement parsing (`if`/`while`/
`for`/`match`/etc.) at the statement-position half of the grammar
(expression-position `if`/`match` live in `parse_expr.rs` instead, see
`PARSER_RULES.md` §4 for why the grammar has both).

**Decisions:**
- `Parser` gained a `no_struct_lit: bool` field plus paired
  `enter_no_struct_lit`/`clear_no_struct_lit`/`leave_no_struct_lit`
  helpers, mirroring the existing `tier`/`enter_tier`/`leave_tier`
  pattern exactly. See `PARSER_RULES.md` §5.8 for the full disambiguation
  writeup — the short version: a bare identifier condition followed by a
  block whose first statement is a plain assignment was indistinguishable
  from a struct literal from 2 tokens of lookahead, and no amount of
  additional lookahead can fix that in general, so the fix suppresses
  struct-literal parsing entirely for the condition/iterable/scrutinee of
  `if`/`elif`/`while`/`for`/`match` (6 call sites total, statement- and
  expression-position both), clearing it again inside any real bracket
  pair (`(...)`, call args, `[...]`) so a parenthesized struct literal
  still works as the escape hatch.

**Tests:** `tests/fixtures/ok_condition_struct_lit_ambiguity_isolated.ubl`,
`tests/fixtures/ok_condition_struct_lit_ambiguity_combined.ubl`.

## CI and Workflows

- `.github/workflows/ci-check.yml`, "Ubel Stratum, Fast Compile Check":
  runs on every push and pull request to `master`/`main`, covers this
  crate along with `ubel_stratum`.
- `.github/workflows/parser-crate-migrate.yml`: migration workflow for
  this crate's split from the original monolithic parser.

## Fixes and Problems

### `parsers/parse_pattern.rs`

- Both of this file's wildcard-recognizing arms, one for match-arm
  patterns and one for struct-destructure fields, checked for
  `TokenType::Ident(n) if n == "_"`. The lexer tokenizes a bare `_` as
  its own token, `TokenType::Underscore`, specifically so it is never
  `Ident("_")`. That meant neither arm could ever fire for a real `_`
  in source text: writing `_ => ...` in a match produced a parse error
  instead of a wildcard match, even though `PatternKind::Wildcard`
  itself was already fully implemented and correct everywhere it was
  consumed (name resolution, `PatternCoverage::CatchAll` in type
  inference, the interpreter's pattern matcher). Confirmed via a real
  `_ => ...` match arm before fixing anything: the parser's own error
  message listed `'_'` as an expected token right next to the
  `Underscore` token it had actually received. Fixed by checking
  `TokenType::Underscore` directly in both places instead.

### `parser.rs`, `parsers/parse_expr.rs`, `parsers/parse_stmt.rs`

- A bare identifier used as an `if`/`while`/`for`/`match`
  condition/iterable/scrutinee, immediately followed by a block whose
  first statement was a plain assignment, misparsed as a struct literal
  — `if x == y { hit_count = hit_count + 1 }` read as `y { hit_count =
  hit_count + 1 }`, one field named `hit_count`. Found via exploratory
  testing (a nested-loop diagonal grid scan), root-caused directly
  against `is_struct_open`'s 2-token lookahead rather than guessed at:
  `{ Ident Equal` is genuinely ambiguous between a struct literal's first
  field and a block's first statement, not a lookahead-depth problem.
  Fixed the way Rust resolves the same ambiguity — suppress struct-literal
  parsing for the condition/iterable/scrutinee itself (a new
  `no_struct_lit` restriction on `Parser`), not by adding more lookahead.
  A first attempt broke the parenthesized escape hatch
  (`if (Foo { x = 1 }).ready { ... }`) by leaving the restriction on for
  everything nested inside the condition, parens included — caught by
  actually running the fixture that exercises it, which failed with an
  unclosed-`(` error, not by inspection. Fixed by clearing the
  restriction again inside any bracket pair the parser itself must
  match a close for (`(...)`, call args, `[...]`), where the ambiguity
  cannot occur regardless. See `PARSER_RULES.md` §5.8 for the full
  writeup.

### `cursor.rs`, `parsers/parse_type.rs`, `parsers/parse_expr.rs`

- `List<List<int>>` did not parse. `>>` is one `RightShift` token and
  every generic closer expected a plain `Greater`. Fixed in the cursor by
  splitting the token, not in the lexer, which cannot know it is in a
  type position. The half-consumed mark is cleared by `restore` so a
  speculative parse cannot leak it into a retry.
- A lambda return type annotation (`fn(x: int) string { ... }`) parsed
  the type name as the whole body and reported two unrelated name errors.
  `parse_lambda` now looks ahead for `Type {`, reports one `PARSE-004` on
  the annotation, and parses the block normally. A `Point { x = a }`
  struct literal body is not mistaken for an annotation. The first
  version only recognized identifier-led types and missed `List<int>`,
  because collection types are dedicated keyword tokens, not identifiers;
  found by running the probe rather than by reading the code.
