// ============================================================================
// NOTICE: Full documentation, design decisions, and fix history for this file
// live in docs/ubel_stratum.md, section "sema/type_infer.rs"
// ============================================================================
// src/sema/type_infer.rs
//! Pass 2 — Type Inference and Arena Coloring.
//!
//! 2a. Signature collection — records def_types for every top-level
//!     declaration without touching bodies, enabling forward references.
//!
//! 2b. Body inference — bidirectional checking inside each body.
//!     Expected type known → check; otherwise infer and record.
//!
//! Arena coloring is woven into 2b. Entering a `with arena(…)` block
//! pushes a fresh ArenaId; every constructed value inside gets stamped
//! SemaType::ArenaRef.
//!
//! ## Gap 2 — escape boundary enforcement (docs/MEMORY_MODEL.md §6)
//!
//! Whether an ArenaRef is *allowed* to flow to a given site is also
//! enforced here, not in tier_check — Pass 2 already tracks live arena
//! scope via `arena_stack`/`maybe_arena_ref`, so this is where the
//! answer is cheapest to compute, right as each site is inferred:
//!
//! - **Assignment** — `check_assign_arena_escape`, called from the
//!   `ExprKind::Assign` arm, compares the *specific* `ArenaId` (never
//!   just tagged/untagged — see §3) a value carries against the target's
//!   home arena: an `Ident`'s original declared type, or a `Field`/
//!   `Index` target's receiver/container's own tag.
//! - **Struct field / indexed storage** — the same function; no struct
//!   field can ever be declared `ArenaRef` (no surface syntax for it),
//!   so a receiver that isn't itself tagged has a home arena of `None`.
//! - **Closure capture** — a lambda built inside a `with arena(…)` block
//!   is conservatively `maybe_arena_ref`-tagged too, the same as any
//!   other constructed value. Lexical scoping guarantees a lambda can
//!   only reference an arena-scoped local from inside that local's own
//!   block, so this over-approximates (a closure that captures nothing
//!   arena-related still gets tagged) but never under-approximates —
//!   once tagged, the lambda value rides the same assignment/return
//!   checks as any other arena-scoped value, no separate free-variable
//!   capture analysis needed.
//! - **Return position** was already caught before Gap 2, incidentally,
//!   via a generic `TypeMismatch` in `unify` (declared return type vs.
//!   actual `ArenaRef`-tagged value). `unify` now recognizes this
//!   specific shape and reports the more precise `ArenaRefEscapesBoundary`
//!   instead — see `scope_mismatch_side`.
//!
//! # Known rough edges (not airtight yet)
//! - **Crash, found while building `docs/OUTLIVES_RULES.md`'s §8
//!   arena-escape connection, not caused by it** — confirmed by
//!   reproducing with `unify_struct_field`'s own deferral inert (a
//!   non-`edge` struct, so it falls straight through to the original
//!   `unify` call unchanged): a `return` statement inside a `with
//!   arena(...)` block, in the same function as an `ArenaRefEscapesBoundary`
//!   report, panics in `type_table.rs` on an out-of-bounds `TypeId`
//!   index (`u64::MAX`-shaped) rather than reporting a diagnostic.
//!   Narrowed one step further: an ordinary `TypeMismatch` alongside a
//!   `return` in the same block does *not* crash, so this is specific
//!   to the arena-escape path, not `return`-inside-`with` generally.
//!   Not chased further — real root-causing needs stepping through
//!   `scope_mismatch_side`/`arena_escape`'s interaction with whatever
//!   resolves a function's return type, unrelated to this delivery's
//!   actual scope. Flagged here rather than silently worked around so
//!   it isn't rediscovered from scratch; every fixture this delivery
//!   added avoids the trigger shape on purpose (confirmed each one
//!   individually, not assumed safe from the general pattern).
//! - No occurs-check in unification.
//! - A value derived from `self` (directly, or via `let x = self.field`)
//!   inside an `impl`-block method body reports `TYPE-115
//!   InvalidFormatSpec` on `on_type: "<unknown>"` for *any* format spec
//!   in a string interpolation hole, even though the same value
//!   type-checks and runs fine for ordinary (non-formatting) use.
//!   Confirmed narrow, not assumed: a plain local unrelated to `self`
//!   inside the same method body formats fine; `self.field` accessed
//!   *outside* any `impl` block (a plain struct field in `main()`, say)
//!   formats fine; extracting to a local first (`let x = self.field`
//!   before formatting `x`) does **not** fix it, despite looking like
//!   it should follow the same shape as the case that does work. Most
//!   likely the same root cause as the "impl-block methods don't
//!   dispatch" gap (`PARKED_IDEAS.md`, "Traits / interface system") —
//!   `self`'s type isn't fully wired through inside an `impl`-block
//!   body the way an ordinary parameter's is, and this is one more
//!   symptom of that, not an independent format-spec bug — but not
//!   chased to a proven common fix here.
//! - Multi-element destructuring shares one Span; all get collection elem type.
//! - An unknown method name called on an `enum` value is not reported by
//!   sema (`NoSuchMethod` is only raised for struct receivers) and
//!   panics at runtime instead; see PARKED_IDEAS.md.
//! - A struct/enum method's *own* extra generic params (beyond whatever
//!   generic params the enclosing struct/enum itself declares) aren't
//!   substituted at call sites — GENERICS_RULES.md.
//! - `impl`/`extend` blocks on a generic struct aren't wired to that
//!   struct's own generic scope (no current fixture exercises this;
//!   inline struct methods — the common case — are unaffected).
//!
//! Previously listed here, now real (GENERICS_RULES.md):
//! generic struct/enum/fn instantiation, `self` typing, general struct
//! field access, and struct static/instance method dispatch all used to
//! be `Unknown`-typed no-ops; they're substituted/checked for real now.

#![allow(dead_code, unused_variables, unused_imports)]

use std::collections::{HashMap, HashSet};

use crate::ast::common::{BinOp, GenericParam, Span, TierAnnotation, UnaryOp, Attribute, AttrArg};
use crate::ast::declarations::{
    ConstDecl, EnumDecl, EnumVariantPayload, ExtendDecl, FunctionDecl, ImplBlock, StaticDecl,
    MethodDecl, Param, ParamKind, ReturnType, StructDecl, StructMember,
    TraitDecl, TraitItem, TypeAlias, MethodSig,
};
use crate::ast::expressions::{
    Arg, ArgKind, Expr, ExprKind, IfBranchBody, LambdaBody,
    MatchArmBody, OrElseFallback,
};
use crate::ast::literals::{FormatSpec, InterpolationPart, IntSuffix, Literal};
use crate::ast::patterns::{EnumPatternPayload, Pattern, PatternKind};
use crate::ast::root::{Item, Program};
use crate::ast::statements::{AllocatorKind, BindingTarget, Block, Stmt, StmtKind};
use crate::ast::types::{Type, TypeKind};
use crate::builtins::instance::{self, MethodReturn, ReceiverWrap};
use crate::error_management::{ErrorManager, errors::{TypeError, TierError}};
use crate::sema::sema_context::SemaContext;
use crate::sema::symbol_table::{DefId, DefKind};
use crate::sema::type_table::{ArenaId, PoolId, SemaType, TypeId};

// ── Integer literal suffix ranges ───────────────────────────────────

/// Whether `raw` -- a literal's non-negative magnitude exactly as
/// written; there's no sign in the token itself, unary `-` is a separate
/// prefix operator applied afterward -- fits the suffix's declared type.
/// Signed suffixes only ever accept the non-negative half of their
/// range here, matching Rust's own literal-suffix behavior (`200i8` is
/// `error: literal out of range for i8` in Rust too, even though the
/// bit pattern -56 would fit, because nothing about the token itself
/// makes -56 the intended value).
/// The magnitude of `suffix`'s most-negative value (`128` for `i8`,
/// since `i8::MIN == -128`), for the `-128i8` special case in
/// `infer_expr_inner`'s `UnaryOp::Neg` arm above. `None` for unsigned
/// suffixes, which have no most-negative value to special-case at all.
fn int_suffix_signed_min_magnitude(suffix: IntSuffix) -> Option<u64> {
    match suffix {
        IntSuffix::I8    => Some(i8::MIN.unsigned_abs() as u64),
        IntSuffix::I16   => Some(i16::MIN.unsigned_abs() as u64),
        IntSuffix::I32   => Some(i32::MIN.unsigned_abs() as u64),
        IntSuffix::I64   => Some(i64::MIN.unsigned_abs()),
        IntSuffix::Isize => Some(i64::MIN.unsigned_abs()),
        IntSuffix::U8 | IntSuffix::U16 | IntSuffix::U32
        | IntSuffix::U64 | IntSuffix::Usize => None,
    }
}

/// One unsuffixed integer literal whose type is still open: its value
/// (negative when it sits directly under a unary `-`) and where it was
/// written, kept so a range check can name it once its type is known.
#[derive(Clone, Copy)]
struct IntLitUse {
    value: i128,
    span:  Span,
}

/// The inclusive value range and display name of a concrete integer
/// type, or `None` for anything that is not one. `int`/`long`/`i64`/
/// `isize` share the runtime's 64-bit signed representation, and
/// `uint`/`u32` and `ulong`/`u64`/`usize` share theirs, exactly as the
/// suffix table above does. `float`/`double` are deliberately not
/// integers here: an integer literal never becomes a float implicitly
/// (`let f: float = 5` stays a mismatch, the same as in Rust).
fn int_type_range(t: &SemaType) -> Option<(i128, i128, &'static str)> {
    Some(match t {
        SemaType::Int   => (i64::MIN as i128, i64::MAX as i128, "int"),
        SemaType::Long  => (i64::MIN as i128, i64::MAX as i128, "long"),
        SemaType::I64   => (i64::MIN as i128, i64::MAX as i128, "i64"),
        SemaType::Isize => (i64::MIN as i128, i64::MAX as i128, "isize"),
        SemaType::I8    => (i8::MIN as i128,  i8::MAX as i128,  "i8"),
        SemaType::I16   => (i16::MIN as i128, i16::MAX as i128, "i16"),
        SemaType::I32   => (i32::MIN as i128, i32::MAX as i128, "i32"),
        SemaType::U8    => (0, u8::MAX as i128,  "u8"),
        SemaType::U16   => (0, u16::MAX as i128, "u16"),
        SemaType::U32   => (0, u32::MAX as i128, "u32"),
        SemaType::Uint  => (0, u32::MAX as i128, "uint"),
        SemaType::U64   => (0, u64::MAX as i128, "u64"),
        SemaType::Ulong => (0, u64::MAX as i128, "ulong"),
        SemaType::Usize => (0, u64::MAX as i128, "usize"),
        _ => return None,
    })
}

fn int_suffix_fits(raw: u64, suffix: IntSuffix) -> bool {
    match suffix {
        IntSuffix::I8    => raw <= i8::MAX as u64,
        IntSuffix::I16   => raw <= i16::MAX as u64,
        IntSuffix::I32   => raw <= i32::MAX as u64,
        IntSuffix::I64   => raw <= i64::MAX as u64,
        // Modeled as i64-width at runtime (`Value::Int`) -- see
        // `interpreter::value::Value`'s own doc comment for why.
        IntSuffix::Isize => raw <= i64::MAX as u64,
        IntSuffix::U8    => raw <= u8::MAX as u64,
        IntSuffix::U16   => raw <= u16::MAX as u64,
        IntSuffix::U32   => raw <= u32::MAX as u64,
        // `raw` is already a `u64`; nothing wider for it to overflow.
        IntSuffix::U64   => true,
        // Modeled as u64-width at runtime (`Value::UInt`).
        IntSuffix::Usize => true,
    }
}

// ── Entry point ───────────────────────────────────────────────────

pub fn infer<'ast>(
    program: &Program<'ast>,
    ctx:     &mut SemaContext,
    errors:  &mut ErrorManager,
) {
    let mut icx = InferCtx::new(ctx, errors);
    icx.collect_signatures(program);
    icx.infer_bodies(program);
}

// ── Unifier ───────────────────────────────────────────────────────

struct Unifier {
    subst: HashMap<u32, TypeId>,
}

impl Unifier {
    fn new() -> Self { Unifier { subst: HashMap::new() } }

    fn apply(&self, mut id: TypeId, types: &crate::sema::type_table::TypeTable) -> TypeId {
        loop {
            match types.get(id) {
                SemaType::Var(v) => match self.subst.get(v) {
                    Some(&next) if next != id => id = next,
                    _                         => return id,
                },
                _ => return id,
            }
        }
    }

    fn bind(&mut self, var: u32, ty: TypeId) -> bool {
        match self.subst.get(&var) {
            None            => { self.subst.insert(var, ty); true }
            Some(&existing) => existing == ty,
        }
    }
}

// ── Enum variant metadata ───────────────────────────────────────────

/// Element/field-type info for one enum variant, computed once during
/// signature collection (`collect_enum_sig`) and consulted by every other
/// enum usage site — bare `EnumName.Variant` access, `EnumName.Variant(..)`
/// tuple construction, `EnumName.Variant { .. }` struct construction, and
/// pattern checking. ENUM_RULES.md.
#[derive(Clone)]
enum VariantShape {
    None,
    /// Behaves identically to `None` for every purpose except declaration-
    /// time validation (ENUM_RULES.md §4 item 1/2) — the chosen ordinal
    /// isn't tracked past sema; there's no `as int` cast to read it back
    /// yet (see this section's "Known gap").
    Discriminant,
    Tuple(Vec<TypeId>),
    Struct(Vec<(String, TypeId)>),
}

// ── Struct member metadata (GENERICS_RULES.md) ──────────────────────

/// Whether a parameter list starts with `self`, `mut self`, `&self` or
/// `&mut self`.
fn has_self_param(params: &[Param<'_>]) -> bool {
    params.first().is_some_and(|p| matches!(p.kind,
        ParamKind::SelfVal | ParamKind::SelfMut | ParamKind::SelfRef | ParamKind::SelfRefMut))
}

/// One method's signature, computed once during `collect_struct_sig` and
/// consulted at every call site — mirrors `VariantShape`'s role for enums.
/// `params`/`return_type` may contain `Param` placeholders for a generic
/// struct; substituted per call site via `InferCtx::substitute`.
#[derive(Clone)]
struct MethodShape {
    /// Whether the method's first param is `self`/`mut self`/`&self`/
    /// `&mut self` — distinguishes `Box.new(v)` (associated/static call,
    /// dispatched on the type name) from `boxed.unwrap()` (instance call,
    /// dispatched on a value's own type).
    has_self:    bool,
    params:      Vec<TypeId>,
    return_type: TypeId,
    is_fallible: bool,
}

/// What a `type Name<T...> = Target` expands to. `target` is written in
/// terms of `Param(i)` for the alias's own generic parameters, exactly
/// like a generic struct's field types, and a use site substitutes its
/// arguments in with `InferCtx::substitute`.
#[derive(Clone, Copy)]
struct AliasExpansion {
    arity:  usize,
    target: TypeId,
}

/// One method of a trait as sema sees it. The shape is written in terms of
/// the abstract `Self` (`Param(n)`, n = the trait's generic arity, so `0`
/// until generic traits exist) and is instantiated per implementing type.
#[derive(Clone)]
struct TraitMethodInfo {
    name:        String,
    shape:       MethodShape,
    /// A default body exists, so an impl may omit the method.
    has_default: bool,
}

/// A trait collected by `collect_trait_info`. See docs/TRAITS_DESIGN.md.
#[derive(Clone)]
struct TraitInfo {
    name:    String,
    methods: Vec<TraitMethodInfo>,
}

/// What a checked pattern definitively covers, for exhaustiveness.
enum PatternCoverage {
    /// Matches unconditionally regardless of the scrutinee's shape —
    /// `_`, or a genuine (non-variant-name) binding.
    CatchAll,
    /// Matches only these specific enum variant names.
    Variants(Vec<String>),
    /// Not enum-related (non-enum scrutinee, or a pattern shape this
    /// pass doesn't do deep exhaustiveness analysis on) — doesn't affect
    /// the enum coverage count either way.
    Other,
}

// ── InferCtx ─────────────────────────────────────────────────────

struct InferCtx<'a> {
    ctx:              &'a mut SemaContext,
    errors:           &'a mut ErrorManager,
    unifier:          Unifier,
    current_return:   Option<TypeId>,
    current_fallible: bool,
    arena_stack:      Vec<ArenaId>,
    next_arena:       usize,
    /// Mirrors `arena_stack`, one entry per open `with pool<T>(count) { }`
    /// — MEMORY_MODEL.md §11. Stores the pool's element type alongside
    /// its id since `Pool.new()` (unlike `List.new()`) has no generic
    /// argument of its own to infer from; it picks up both id and
    /// element type from the innermost enclosing pool block.
    pool_stack:       Vec<(PoolId, TypeId)>,
    next_pool:        usize,
    /// Populated once per enum by `collect_enum_sig`, consulted by every
    /// other enum usage site for the rest of Pass 2 — ENUM_RULES.md.
    enum_variants:    HashMap<DefId, Vec<(String, VariantShape)>>,
    /// Generic-param name -> `Param(i)` placeholder, active only while
    /// collecting the signature or checking the body of the struct/enum/fn
    /// currently being processed (GENERICS_RULES.md). Empty outside any
    /// generic decl. `ast_type_to_sema`'s `TypeKind::Named` arm checks
    /// this *before* falling back to `top_level_def`, so a bare `T` that
    /// names one of the enclosing decl's own generic params resolves to
    /// its placeholder instead of silently becoming `Unknown`.
    current_generic_params: HashMap<String, TypeId>,
    /// The expansion of every `type` alias, filled by `collect_alias_sigs`
    /// before any other signature is collected. An alias is transparent:
    /// `ast_type_to_sema` replaces a use of it by its target, so `Score`
    /// from `type Score = int` is simply `int` everywhere.
    alias_expansions: HashMap<DefId, AliasExpansion>,
    /// True only while `collect_alias_sigs` runs. A use of an alias that
    /// is not expanded yet (it is declared later, or is part of a cycle)
    /// sets `alias_blocked` so the caller retries it on the next round
    /// instead of caching a half-resolved target.
    alias_prepass: bool,
    alias_blocked: bool,
    /// Every trait, by definition. Filled by `collect_trait_info` before any
    /// impl is checked.
    traits:           HashMap<DefId, TraitInfo>,
    /// `(trait, implementing type)` -> the span of its `impl`. Exactly one
    /// impl per pair is allowed (`TYPE-128`).
    trait_impls:      HashMap<(DefId, DefId), Span>,
    /// `(type, method name)` -> the traits that supply a method of that
    /// name to the type. Only trait-supplied methods are listed; an
    /// inherent method is recognised by being in `struct_methods` with no
    /// entry here.
    method_origins:   HashMap<(DefId, String), Vec<DefId>>,
    /// `(type, method name)` pairs two or more traits supply with no
    /// inherent method to win. An unqualified call of one is `TYPE-127`.
    ambiguous_methods: HashSet<(DefId, String)>,
    /// `(type, method name)` pairs whose entry in `struct_methods` was put
    /// there by a TRAIT impl. Anything else in the table is inherent, which
    /// is how `add_trait_method` tells an inherent method from the first
    /// trait's entry.
    trait_entries:    HashSet<(DefId, String)>,
    /// What the written type `Self` means right now: the implementing type
    /// inside an `impl`/`extend`/struct, the abstract `Self` parameter
    /// inside a trait. `None` outside all of them.
    self_type:        Option<TypeId>,
    /// Trait bounds of the type parameters in scope, by the parameter's
    /// `TypeId`. Inside a trait's default method the abstract `Self` is
    /// bounded by the trait itself, so `self.other()` resolves through it.
    current_bounds:   HashMap<TypeId, Vec<DefId>>,
    /// `self`'s type while inside a struct's own method bodies — the
    /// abstract `Named { def, args: [Param(0), Param(1), ...] }` for a
    /// generic struct, or `Named { def, args: [] }` for a non-generic
    /// one. Method bodies are checked once, generically — the same way
    /// Rust checks a generic impl's body once rather than per
    /// instantiation — with concrete substitution happening at each call
    /// site instead. `None` outside any method body.
    current_struct_type: Option<TypeId>,
    /// Set by the `Call` arm just before it pre-infers a `Field` callee,
    /// and consumed (reset) by the `Field` arm's first line. While set,
    /// that one `Field` node does not report `NoSuchField` for a name
    /// that is not a field: the `Call` arm's own dispatch reports the
    /// call-shaped `NoSuchMethod` for the same name, so reporting both
    /// gave two diagnostics for one typo. Nested field accesses inside
    /// the callee's target (`a.b.c()`) still report normally, since the
    /// flag is taken before the target is inferred.
    callee_field_pending: bool,
    /// Populated once per struct by `collect_struct_sig`, mirrors
    /// `enum_variants`'s role. Field types may contain `Param`
    /// placeholders for a generic struct.
    struct_fields:    HashMap<DefId, Vec<(String, TypeId)>>,
    /// Populated once per struct by `collect_struct_sig`. Same `Param`-
    /// placeholder treatment as `struct_fields`.
    struct_methods:   HashMap<DefId, Vec<(String, MethodShape)>>,
    /// Populated once per struct by `collect_struct_sig`, alongside
    /// `check_derive_attrs`'s own validation of the same `@derive(...)`
    /// list. Sema's own copy, not shared with `Interpreter::
    /// struct_derives`, which is type-name-keyed and built later, at
    /// `run_program` time, from the same source (each pass re-derives
    /// this fact from the AST rather than one borrowing the other's
    /// table, the same relationship this file's other struct tables
    /// already have with the interpreter's). Consulted so far only by
    /// the `.clone()` instance-method special case below (`ExprKind::
    /// Call`'s struct-instance-method arm), recognizing `.clone()` as
    /// a real, typed method when `@derive(Clone)` is present, instead
    /// of it always reaching `NoSuchMethod`.
    struct_derives:   HashMap<DefId, HashSet<String>>,
    /// How many generic params the struct/enum at this `DefId` declares.
    /// Consulted at `TypeKind::Named` use sites to validate argument
    /// count (`GenericArgCountMismatch`) and at construction/call sites
    /// to know how many fresh `Var`s to allocate before substituting.
    generic_arity:    HashMap<DefId, usize>,
    /// §8 — the enclosing function/method's `@tier(...)`. Needed here
    /// (not just in tier_check.rs) because `expr_types` entries can
    /// still be raw unresolved `Var`s at record-time — resolving a
    /// receiver's type to check `instance::is_high_only` needs the same
    /// live `Unifier`/`apply()` this pass already has, which tier_check
    /// (Pass 3, no `Unifier` of its own) does not. Defaults to `High`
    /// — the same default the whole file already uses for top-level
    /// inference performed outside any function body.
    current_tier:     TierAnnotation,
    /// Unsuffixed integer literals whose type is still open, keyed by the
    /// number of the (root) `Var` standing for them. Several literals
    /// share one entry once their vars have been unified with each other
    /// (`1 + 2`, `[1, 2, 3]`). An entry disappears the moment its var is
    /// bound to a concrete type, which is also when the range check runs.
    /// See `infer_int_literal`.
    int_lit_vars:     HashMap<u32, Vec<IntLitUse>>,
    /// Every integer-literal site seen since the last `finish_int_literals`
    /// (its span and its var), so the final width of each one can be
    /// recorded in `SemaContext::int_literal_types` for the interpreter.
    int_lit_sites:    Vec<(Span, TypeId)>,
}

impl<'a> InferCtx<'a> {
    fn new(ctx: &'a mut SemaContext, errors: &'a mut ErrorManager) -> Self {
        InferCtx {
            ctx,
            errors,
            unifier:          Unifier::new(),
            current_return:   None,
            current_fallible: false,
            arena_stack:      Vec::new(),
            next_arena:       0,
            pool_stack:       Vec::new(),
            next_pool:        0,
            enum_variants:    HashMap::new(),
            current_generic_params: HashMap::new(),
            alias_expansions: HashMap::new(),
            alias_prepass:    false,
            alias_blocked:    false,
            traits:            HashMap::new(),
            trait_impls:       HashMap::new(),
            method_origins:    HashMap::new(),
            ambiguous_methods: HashSet::new(),
            trait_entries:     HashSet::new(),
            self_type:         None,
            current_bounds:    HashMap::new(),
            current_struct_type:    None,
            callee_field_pending:   false,
            struct_fields:    HashMap::new(),
            struct_methods:   HashMap::new(),
            struct_derives:   HashMap::new(),
            generic_arity:    HashMap::new(),
            current_tier:     TierAnnotation::High,
            int_lit_vars:     HashMap::new(),
            int_lit_sites:    Vec::new(),
        }
    }

    // ── Generics (GENERICS_RULES.md) ────────────────────────────────

    /// Enter a struct/enum/fn's own generic scope, returning the
    /// previous scope so the caller can restore it on the way out.
    /// Builds one `Param(i)` placeholder per declared generic param,
    /// keyed by name — repeated references to the same param name within
    /// one declaration (e.g. `T` in both `Some(T)` and a sibling variant)
    /// resolve to the identical `TypeId` for free, since the map is only
    /// built once per `push`.
    fn push_generic_scope(&mut self, params: &[GenericParam]) -> HashMap<String, TypeId> {
        let mut new_map = HashMap::with_capacity(params.len());
        for (i, gp) in params.iter().enumerate() {
            new_map.insert(gp.name.to_string(), self.ctx.types.intern(SemaType::Param(i)));
        }
        std::mem::replace(&mut self.current_generic_params, new_map)
    }

    fn pop_generic_scope(&mut self, prev: HashMap<String, TypeId>) {
        self.current_generic_params = prev;
    }

    /// Build a fresh instantiation of a struct/enum def: `Named { def,
    /// args }` with one fresh `Var` per its own declared generic param
    /// (or just its stored, already-computed `def_type` — cheap, no
    /// allocation — for a non-generic one). Used at every *bare*
    /// construction site (enum fieldless/tuple/struct-payload variant
    /// construction, struct literals, struct associated-function calls)
    /// where there's no already-known instantiation to substitute
    /// against and the concrete type args must instead be *inferred*
    /// from how the constructed value's parts are used — unification
    /// does the rest, the same way this file's existing `fresh_var()`
    /// already resolves an untyped `[]` list literal's element type from
    /// context (GENERICS_RULES.md).
    fn instantiate(&mut self, def_id: DefId) -> TypeId {
        let arity = self.generic_arity.get(&def_id).copied().unwrap_or(0);
        if arity == 0 {
            return self.ctx.def_type(def_id).unwrap_or_else(|| self.unknown());
        }
        let args: Vec<TypeId> = (0..arity).map(|_| self.fresh_var()).collect();
        self.ctx.types.insert(SemaType::Named { def: def_id, args })
    }

    /// Recursively replace every `Param(i)` inside `ty` with `args[i]`.
    /// A type containing no `Param` (i.e. anything already concrete —
    /// every non-generic type) is reconstructed unchanged; correctness
    /// over cheapness here, matching the rest of this pass's existing
    /// style (e.g. `unify`'s `apply`-then-compare).  Every real use site
    /// of a generic struct/enum/fn's stored (raw, `Param`-containing)
    /// signature goes through this before the result is unified,
    /// displayed, or bound to a variable — `enum_shapes_of`, struct field
    /// access, struct static/instance method dispatch, and generic
    /// free-function calls.
    fn substitute(&mut self, ty: TypeId, args: &[TypeId]) -> TypeId {
        let t = self.ctx.types.get(ty).clone();
        match t {
            SemaType::Param(i) => args.get(i).copied().unwrap_or(ty),

            SemaType::List(e) => { let e = self.substitute(e, args); self.ctx.types.insert(SemaType::List(e)) }
            SemaType::Set(e)  => { let e = self.substitute(e, args); self.ctx.types.insert(SemaType::Set(e)) }
            SemaType::Queue(e) => { let e = self.substitute(e, args); self.ctx.types.insert(SemaType::Queue(e)) }
            SemaType::Stack(e) => { let e = self.substitute(e, args); self.ctx.types.insert(SemaType::Stack(e)) }
            SemaType::Slice(e) => { let e = self.substitute(e, args); self.ctx.types.insert(SemaType::Slice(e)) }
            SemaType::Pool(e)  => { let e = self.substitute(e, args); self.ctx.types.insert(SemaType::Pool(e)) }
            SemaType::Handle(e) => { let e = self.substitute(e, args); self.ctx.types.insert(SemaType::Handle(e)) }
            SemaType::Fallible(e) => { let e = self.substitute(e, args); self.ctx.types.insert(SemaType::Fallible(e)) }
            SemaType::Task(e) => { let e = self.substitute(e, args); self.ctx.types.insert(SemaType::Task(e)) }
            SemaType::Optional(e) => { let e = self.substitute(e, args); self.ctx.types.insert(SemaType::Optional(e)) }
            SemaType::GcRef(e) => { let e = self.substitute(e, args); self.ctx.types.insert(SemaType::GcRef(e)) }
            // InlineList/Linqerizer/Reference were missing here entirely
            // until now — same bug class as the `structurally_compatible`
            // Set/Queue/Stack/Pool/Handle fix (that function's own
            // comment): a generic struct/fn whose signature contains one
            // of these three (e.g. `struct Box<T> { r: &T }`) would have
            // its `Param(0)` survive substitution unresolved, since these
            // three fell through to the primitives-only catch-all below
            // instead of recursing into `inner`. Found while adding
            // `Unique`/`Shared`/`SyncShared` alongside them and confirming
            // every wrapper type actually substitutes correctly — leaving
            // three known instances of the same bug sitting right next to
            // the fix would've been an odd thing to knowingly walk past.
            SemaType::InlineList(e) => { let e = self.substitute(e, args); self.ctx.types.insert(SemaType::InlineList(e)) }
            SemaType::Linqerizer(e) => { let e = self.substitute(e, args); self.ctx.types.insert(SemaType::Linqerizer(e)) }
            SemaType::Reference { mutable, lifetime, inner } => {
                let inner = self.substitute(inner, args);
                self.ctx.types.insert(SemaType::Reference { mutable, lifetime, inner })
            }
            SemaType::Unique(e)     => { let e = self.substitute(e, args); self.ctx.types.insert(SemaType::Unique(e)) }
            SemaType::Shared(e)     => { let e = self.substitute(e, args); self.ctx.types.insert(SemaType::Shared(e)) }
            SemaType::SyncShared(e) => { let e = self.substitute(e, args); self.ctx.types.insert(SemaType::SyncShared(e)) }

            SemaType::Dictionary(k, v) => {
                let k = self.substitute(k, args);
                let v = self.substitute(v, args);
                self.ctx.types.insert(SemaType::Dictionary(k, v))
            }
            SemaType::Tuple(ts) => {
                let ts: Vec<TypeId> = ts.iter().map(|t| self.substitute(*t, args)).collect();
                self.ctx.types.insert(SemaType::Tuple(ts))
            }
            SemaType::Array { len, elem } => {
                let elem = self.substitute(elem, args);
                self.ctx.types.insert(SemaType::Array { len, elem })
            }
            SemaType::ArenaRef { arena, mutable, inner } => {
                let inner = self.substitute(inner, args);
                self.ctx.types.insert(SemaType::ArenaRef { arena, mutable, inner })
            }
            SemaType::PoolRef { pool, mutable, inner } => {
                let inner = self.substitute(inner, args);
                self.ctx.types.insert(SemaType::PoolRef { pool, mutable, inner })
            }
            SemaType::OwnedRef { mutable, inner } => {
                let inner = self.substitute(inner, args);
                self.ctx.types.insert(SemaType::OwnedRef { mutable, inner })
            }
            SemaType::Function { params, return_type, is_fallible, generic_arity } => {
                let params: Vec<TypeId> = params.iter().map(|p| self.substitute(*p, args)).collect();
                let return_type = self.substitute(return_type, args);
                self.ctx.types.insert(SemaType::Function { params, return_type, is_fallible, generic_arity })
            }
            SemaType::Named { def, args: inner_args } => {
                let inner_args: Vec<TypeId> = inner_args.iter().map(|t| self.substitute(*t, args)).collect();
                self.ctx.types.insert(SemaType::Named { def, args: inner_args })
            }

            // Primitives, Var, Null, Unknown, Void — nothing to substitute.
            _ => ty,
        }
    }

    // ── Cheap constructors ────────────────────────────────────────

    fn fresh_var(&mut self) -> TypeId { self.ctx.types.fresh_var() }
    fn unknown(&mut self)   -> TypeId { self.ctx.types.intern(SemaType::Unknown) }
    fn void_ty(&mut self)   -> TypeId { self.ctx.types.intern(SemaType::Void) }
    fn bool_ty(&mut self)   -> TypeId { self.ctx.types.intern(SemaType::Bool) }
    fn int_ty(&mut self)    -> TypeId { self.ctx.types.intern(SemaType::Int) }
    fn str_ty(&mut self)    -> TypeId { self.ctx.types.intern(SemaType::Str) }

    fn apply(&self, id: TypeId) -> TypeId {
        self.unifier.apply(id, &self.ctx.types)
    }

    // ── Arena tracking ────────────────────────────────────────────

    fn push_arena(&mut self) -> ArenaId {
        let id = ArenaId(self.next_arena);
        self.next_arena += 1;
        self.arena_stack.push(id);
        id
    }

    fn pop_arena(&mut self) { self.arena_stack.pop(); }

    fn current_arena(&self) -> Option<ArenaId> {
        self.arena_stack.last().copied()
    }

    // ── Pool tracking ─────────────────────────────────────────────

    fn push_pool(&mut self, elem_ty: TypeId) -> PoolId {
        let id = PoolId(self.next_pool);
        self.next_pool += 1;
        self.pool_stack.push((id, elem_ty));
        id
    }

    fn pop_pool(&mut self) { self.pool_stack.pop(); }

    fn current_pool(&self) -> Option<(PoolId, TypeId)> {
        self.pool_stack.last().copied()
    }

    /// Wrap `inner_ty` as an ArenaRef if inside a `with arena` block.
    /// Called on freshly *constructed* values only.
    fn maybe_arena_ref(&mut self, inner_ty: TypeId) -> TypeId {
        match self.current_arena() {
            Some(arena) => self.ctx.types.insert(SemaType::ArenaRef {
                arena,
                mutable: false,
                inner:   inner_ty,
            }),
            None => inner_ty,
        }
    }

    /// GAP 2 — resolve `ty` and return `Some(arena)` only if its
    /// *outermost* layer is `SemaType::ArenaRef`. This is deliberately
    /// shallow (unlike `SemaType::scope_ref_kind`, which recurses):
    /// it answers "is this specific reference itself bound to an arena",
    /// which is what determines a binding's or receiver's *own* home
    /// arena for escape comparisons — not "does this type contain an
    /// arena reference somewhere inside it."
    fn top_level_arena(&mut self, ty: TypeId) -> Option<ArenaId> {
        let resolved = self.apply(ty);
        match self.ctx.types.get(resolved) {
            SemaType::ArenaRef { arena, .. } => Some(*arena),
            _ => None,
        }
    }

    /// GAP 2 — report `ty` as a value that has crossed an arena boundary
    /// it shouldn't have.
    fn arena_escape(&mut self, ty: TypeId, span: Span) {
        let escaped_type = self.display_type(ty);
        self.errors.add_tier_error(TierError::ArenaRefEscapesBoundary {
            escaped_type,
            span,
        });
    }

    /// Same shallow-resolve shape as `top_level_arena`, for `PoolRef` —
    /// MEMORY_MODEL.md §11.
    fn top_level_pool(&mut self, ty: TypeId) -> Option<PoolId> {
        let resolved = self.apply(ty);
        match self.ctx.types.get(resolved) {
            SemaType::PoolRef { pool, .. } => Some(*pool),
            _ => None,
        }
    }

    /// Same shape as `arena_escape`, reporting the pool-specific
    /// diagnostic so the message says "&pool"/"with pool<...>(...)"
    /// rather than reusing arena's wording for a different block kind.
    fn pool_escape(&mut self, ty: TypeId, span: Span) {
        let escaped_type = self.display_type(ty);
        self.errors.add_tier_error(TierError::PoolRefEscapesBoundary {
            escaped_type,
            span,
        });
    }

    /// Type produced by `<Namespace>.new()` for the builtin collection
    /// constructors (`crates/core/src/builtins/constructors.rs`). `None`
    /// for anything not in that list — including builtin namespaces with
    /// no constructor member, like `Math` — so callers fall through to
    /// generic call inference.
    ///
    /// This exists so `List.new()` / `Dictionary.new()` / `Queue.new()` /
    /// `Stack.new()` get a real collection type *and* participate in arena
    /// coloring via `maybe_arena_ref`, the same way array/tuple/dict/struct
    /// literals already do. Without it, these calls fall through the
    /// generic `Field`/`Call` path, which has no field table yet (see that
    /// arm's own TODO) and always infers `Unknown` — silently skipping
    /// arena tagging inside a `with arena(...)` block. See
    /// `docs/MEMORY_MODEL.md` §5 ("Gap 1").
    ///
    /// Keep this in sync with `constructors.rs` and `BUILTIN_NAMESPACES` if
    /// a new collection constructor is added (e.g. a future `Pool.new()`).
    fn builtin_constructor_type(&mut self, namespace: &str) -> Option<TypeId> {
        match namespace {
            "List" => {
                let elem = self.fresh_var();
                Some(self.ctx.types.intern(SemaType::List(elem)))
            }
            "Dictionary" => {
                let k = self.fresh_var();
                let v = self.fresh_var();
                Some(self.ctx.types.insert(SemaType::Dictionary(k, v)))
            }
            "Queue" => {
                let elem = self.fresh_var();
                Some(self.ctx.types.insert(SemaType::Queue(elem)))
            }
            "Stack" => {
                let elem = self.fresh_var();
                Some(self.ctx.types.insert(SemaType::Stack(elem)))
            }
            _ => None,
        }
    }

    /// §8 — turn an `instance::MethodReturn` shape into a concrete
    /// `TypeId`, given the receiver's wrapper (for allocation-producing
    /// methods, §8's "same arena as the receiver" rule) and its bare
    /// composite `TypeId` (for pulling out element type(s)).
    fn method_return_type(
        &mut self,
        ret:     MethodReturn,
        wrap:    ReceiverWrap,
        bare_ty: TypeId,
    ) -> TypeId {
        match ret {
            MethodReturn::Void => self.void_ty(),
            MethodReturn::Int  => self.int_ty(),
            MethodReturn::Bool => self.bool_ty(),

            // Already-stored value (List<T>/Queue<T>/Stack<T>'s T, or
            // Dictionary<K,V>'s V for `at`) — already correctly tiered
            // from whenever it was inserted, nothing new to wrap for
            // tier purposes. Every current caller of this shape
            // (pop/first/last/dequeue/peek/at) falls back to
            // `Value::Null` at runtime on an empty/missing receiver
            // (see each method's own `unwrap_or(Value::Null)` in
            // `builtins/instance/*.rs`), so the static type has to be
            // genuinely nullable — `Optional(elem)`, not bare `elem` —
            // or `x.pop() == null` fails a real TypeMismatch despite
            // being exactly the documented way to check for "empty."
            MethodReturn::Elem => {
                let elem = match self.ctx.types.get(bare_ty) {
                    SemaType::List(e)
                    | SemaType::Queue(e)
                    | SemaType::Stack(e)
                    | SemaType::Pool(e)
                    | SemaType::Linqerizer(e)  => *e,
                    SemaType::Dictionary(_, v) => *v,
                    _ => self.fresh_var(),
                };
                self.ctx.types.insert(SemaType::Optional(elem))
            }

            // The rest all construct a brand-new value — inherit the
            // receiver's own wrapper rather than defaulting to GC.
            MethodReturn::NewSelf => self.apply_receiver_wrap(wrap, bare_ty),
            MethodReturn::NewListOfChar => {
                let elem = self.ctx.types.intern(SemaType::Char);
                let list = self.ctx.types.insert(SemaType::List(elem));
                self.apply_receiver_wrap(wrap, list)
            }
            MethodReturn::NewListOfStr => {
                let elem = self.str_ty();
                let list = self.ctx.types.insert(SemaType::List(elem));
                self.apply_receiver_wrap(wrap, list)
            }
            MethodReturn::NewListOfKey => {
                let key = match self.ctx.types.get(bare_ty) {
                    SemaType::Dictionary(k, _) => *k,
                    _ => self.fresh_var(),
                };
                let list = self.ctx.types.insert(SemaType::List(key));
                self.apply_receiver_wrap(wrap, list)
            }
            MethodReturn::NewListOfValue => {
                let val = match self.ctx.types.get(bare_ty) {
                    SemaType::Dictionary(_, v) => *v,
                    _ => self.fresh_var(),
                };
                let list = self.ctx.types.insert(SemaType::List(val));
                self.apply_receiver_wrap(wrap, list)
            }
            // `Pool<T>.acquire(value)` — `Optional<Handle<T>>`, wrapped
            // in the receiver's own wrap (MEMORY_MODEL.md §11: acquired
            // handles must not escape the `with pool<T>(count) { }`
            // block either, same "same as arena" answer that applies to
            // the pool itself).
            MethodReturn::AcquireHandle => {
                let elem = match self.ctx.types.get(bare_ty) {
                    SemaType::Pool(e) => *e,
                    _ => self.fresh_var(),
                };
                let handle = self.ctx.types.insert(SemaType::Handle(elem));
                let optional = self.ctx.types.insert(SemaType::Optional(handle));
                self.apply_receiver_wrap(wrap, optional)
            }
            // `List<T>.query()` — `Linqerizer<T>`. `T` comes from the
            // receiver `List<T>`, same pull-the-elem-out shape as
            // `NewListOfKey`/`NewListOfValue` pull from `Dictionary`.
            MethodReturn::NewLinqerizerOfElem => {
                let elem = match self.ctx.types.get(bare_ty) {
                    SemaType::List(e) => *e,
                    _ => self.fresh_var(),
                };
                let linq = self.ctx.types.insert(SemaType::Linqerizer(elem));
                self.apply_receiver_wrap(wrap, linq)
            }
            // `Linqerizer<T>.to_list()` — `List<T>`. `T` comes from the
            // receiver `Linqerizer<T>` itself, not a fixed type — this
            // is the mirror image of `NewLinqerizerOfElem` above.
            MethodReturn::NewListOfLinqElem => {
                let elem = match self.ctx.types.get(bare_ty) {
                    SemaType::Linqerizer(e) => *e,
                    _ => self.fresh_var(),
                };
                let list = self.ctx.types.insert(SemaType::List(elem));
                self.apply_receiver_wrap(wrap, list)
            }
        }
    }

    /// Re-wrap a freshly-constructed value in the same ref kind the
    /// receiver carried. `Gc` re-wraps to nothing (bare) rather than an
    /// explicit `SemaType::GcRef` — matching `maybe_arena_ref`'s existing
    /// convention that "no wrapper" already means GC-tier by default; a
    /// bare type and `GcRef(bare)` aren't currently treated as
    /// interchangeable by `unify`, so introducing the explicit form here
    /// would risk spurious mismatches against every other GC-default site.
    fn apply_receiver_wrap(&mut self, wrap: ReceiverWrap, inner: TypeId) -> TypeId {
        match wrap {
            ReceiverWrap::Gc => inner,
            ReceiverWrap::Arena { arena, mutable } =>
                self.ctx.types.insert(SemaType::ArenaRef { arena, mutable, inner }),
            ReceiverWrap::Pool { pool, mutable } =>
                self.ctx.types.insert(SemaType::PoolRef { pool, mutable, inner }),
            ReceiverWrap::Owned { mutable } =>
                self.ctx.types.insert(SemaType::OwnedRef { mutable, inner }),
        }
    }

    /// Convert a syntactic `Type<'ast>` node into a TypeId.
    /// Uses `match ty.kind` (not `&ty.kind`) since TypeKind is Copy,
    /// avoiding match-ergonomics reference confusion throughout.
    fn ast_type_to_sema<'ast>(&mut self, ty: &Type<'ast>) -> TypeId {
        match ty.kind {
            TypeKind::Int    => self.ctx.types.intern(SemaType::Int),
            TypeKind::Uint   => self.ctx.types.intern(SemaType::Uint),
            TypeKind::Long   => self.ctx.types.intern(SemaType::Long),
            TypeKind::Ulong  => self.ctx.types.intern(SemaType::Ulong),
            TypeKind::Short  => self.ctx.types.intern(SemaType::Int),   // widen
            TypeKind::Ushort => self.ctx.types.intern(SemaType::Uint),  // widen
            TypeKind::Byte   => self.ctx.types.intern(SemaType::I8),
            TypeKind::Ubyte  => self.ctx.types.intern(SemaType::U8),
            TypeKind::Float  => self.ctx.types.intern(SemaType::Float),
            TypeKind::Double => self.ctx.types.intern(SemaType::Double),
            TypeKind::Bool   => self.ctx.types.intern(SemaType::Bool),
            TypeKind::Char   => self.ctx.types.intern(SemaType::Char),
            TypeKind::Str    => self.ctx.types.intern(SemaType::Str),
            TypeKind::Void   => self.ctx.types.intern(SemaType::Void),
            TypeKind::I8     => self.ctx.types.intern(SemaType::I8),
            TypeKind::I16    => self.ctx.types.intern(SemaType::I16),
            TypeKind::I32    => self.ctx.types.intern(SemaType::I32),
            TypeKind::I64    => self.ctx.types.intern(SemaType::I64),
            TypeKind::U8     => self.ctx.types.intern(SemaType::U8),
            TypeKind::U16    => self.ctx.types.intern(SemaType::U16),
            TypeKind::U32    => self.ctx.types.intern(SemaType::U32),
            TypeKind::U64    => self.ctx.types.intern(SemaType::U64),
            TypeKind::F32    => self.ctx.types.intern(SemaType::F32),
            TypeKind::F64    => self.ctx.types.intern(SemaType::F64),
            TypeKind::Isize  => self.ctx.types.intern(SemaType::Isize),
            TypeKind::Usize  => self.ctx.types.intern(SemaType::Usize),

            TypeKind::List(inner) => {
                let elem = inner.map(|t| self.ast_type_to_sema(t))
                    .unwrap_or_else(|| self.fresh_var());
                self.ctx.types.intern(SemaType::List(elem))
            }
            TypeKind::Dictionary(kv) => {
                let (k, v) = kv.map(|(k, v)| (self.ast_type_to_sema(k), self.ast_type_to_sema(v)))
                    .unwrap_or_else(|| (self.fresh_var(), self.fresh_var()));
                self.ctx.types.insert(SemaType::Dictionary(k, v))
            }
            TypeKind::Set(inner) => {
                let elem = inner.map(|t| self.ast_type_to_sema(t))
                    .unwrap_or_else(|| self.fresh_var());
                self.ctx.types.intern(SemaType::Set(elem))
            }
            TypeKind::Queue(inner) => {
                let elem = inner.map(|t| self.ast_type_to_sema(t))
                    .unwrap_or_else(|| self.fresh_var());
                self.ctx.types.insert(SemaType::Queue(elem))
            }
            TypeKind::Stack(inner) => {
                let elem = inner.map(|t| self.ast_type_to_sema(t))
                    .unwrap_or_else(|| self.fresh_var());
                self.ctx.types.insert(SemaType::Stack(elem))
            }
            TypeKind::InlineList(inner) => {
                let elem = inner.map(|t| self.ast_type_to_sema(t))
                    .unwrap_or_else(|| self.fresh_var());
                self.ctx.types.insert(SemaType::InlineList(elem))
            }
            TypeKind::Named { path, args } => {
                let root = path.first().copied().unwrap_or("");
                // GENERICS_RULES.md — a bare single-segment name that
                // matches one of the enclosing struct/enum/fn's own
                // generic params (`T` inside `struct Box<T> { value: T }`)
                // resolves to its `Param` placeholder, not a top-level
                // lookup. Checked before `top_level_def` so a generic
                // param can't be shadowed by an unrelated top-level type
                // of the same name.
                // `Self`: the implementing type inside an `impl`, `extend` or
                // struct, the abstract `Self` parameter inside a trait.
                // Outside all of them it falls through to the ordinary
                // lookup and stays unresolved, as before.
                if path.len() == 1 && args.is_empty() && root == "Self" {
                    if let Some(t) = self.self_type { return t; }
                }
                if path.len() == 1 && args.is_empty() {
                    if let Some(&param_ty) = self.current_generic_params.get(root) {
                        return param_ty;
                    }
                }
                let arg_ids: Vec<TypeId> = args.iter()
                    .map(|a| self.ast_type_to_sema(a))
                    .collect();
                // Ownership-model wrappers (MEMORY_MODEL.md §9,
                // DATASTRUCTURES.md "Decisions locked in") — real compiler
                // builtins, not user-declared structs, so they're checked
                // before `top_level_def` the same way `List`/`Set`/etc.
                // never reach it at all (those get their own dedicated
                // `TypeKind` variant instead; these three don't need one
                // since bare `Identifier<Args>` parsing already produces
                // the exact shape needed here). A user who separately
                // declares `struct Unique<T> { ... }` themselves will find
                // this shadows it — same class of reserved-name collision
                // as `get`/`set`/`where` being reserved tokens elsewhere
                // in the language; not diagnosed as a name collision yet.
                if path.len() == 1 && matches!(root, "Unique" | "Shared" | "SyncShared") {
                    if arg_ids.len() != 1 {
                        self.errors.add_type_error(TypeError::GenericArgCountMismatch {
                            type_name: root.to_string(),
                            expected:  1,
                            found:     arg_ids.len(),
                            span:      ty.span,
                        });
                        return self.unknown();
                    }
                    let inner = arg_ids[0];
                    return self.ctx.types.insert(match root {
                        "Unique" => SemaType::Unique(inner),
                        "Shared" => SemaType::Shared(inner),
                        _        => SemaType::SyncShared(inner), // exhaustive via the outer matches! guard
                    });
                }
                match self.ctx.top_level_def(root) {
                    Some(def_id) => {
                        // A `type` alias is transparent: it is replaced by
                        // its target, not kept as a type of its own.
                        if matches!(self.ctx.symbols.lookup(def_id).kind, DefKind::TypeAlias) {
                            return self.expand_alias(def_id, root, arg_ids, ty.span);
                        }
                        if let Some(&expected) = self.generic_arity.get(&def_id) {
                            if expected != arg_ids.len() {
                                self.errors.add_type_error(TypeError::GenericArgCountMismatch {
                                    type_name: root.to_string(),
                                    expected,
                                    found:     arg_ids.len(),
                                    span:      ty.span,
                                });
                            }
                        }
                        self.ctx.types.insert(SemaType::Named {
                            def: def_id, args: arg_ids,
                        })
                    }
                    None => self.unknown(),
                }
            }
            TypeKind::Tuple(fields) => {
                let ids: Vec<TypeId> = fields.iter()
                    .map(|f| self.ast_type_to_sema(f))
                    .collect();
                self.ctx.types.insert(SemaType::Tuple(ids))
            }
            TypeKind::Array { len, elem } => {
                let elem_id = self.ast_type_to_sema(elem);
                self.ctx.types.insert(SemaType::Array { len, elem: elem_id })
            }
            TypeKind::Slice(elem) => {
                let elem_id = self.ast_type_to_sema(elem);
                self.ctx.types.intern(SemaType::Slice(elem_id))
            }
            TypeKind::Fallible(inner) => {
                let inner_id = self.ast_type_to_sema(inner);
                self.ctx.types.intern(SemaType::Fallible(inner_id))
            }
            TypeKind::Task(inner) => {
                let inner_id = inner.map(|t| self.ast_type_to_sema(t))
                    .unwrap_or_else(|| self.void_ty());
                self.ctx.types.intern(SemaType::Task(inner_id))
            }
            TypeKind::Reference { mutable, lifetime, inner } => {
                // Was `SemaType::GcRef(inner_id)` — a stub that silently
                // discarded `mutable` and `lifetime` and made every
                // user-written `&T`/`&mut T` type annotation compile as
                // a plain HIGH-tier GC reference, in any tier. Nothing
                // exercised this path before now (no expression-level
                // borrow operator existed to construct a value of the
                // type), so it went uncaught. Fixed to the real
                // `SemaType::Reference` — see type_table.rs and TYPE-114.
                let inner_id = self.ast_type_to_sema(inner);
                self.ctx.types.insert(SemaType::Reference {
                    mutable,
                    lifetime: lifetime.map(|s| s.to_string()),
                    inner:    inner_id,
                })
            }
            TypeKind::Optional(inner) => {
                let inner_id = self.ast_type_to_sema(inner);
                self.ctx.types.intern(SemaType::Optional(inner_id))
            }
            TypeKind::Function(ft) => {
                let params: Vec<TypeId> = ft.params.iter()
                    .map(|p| self.ast_type_to_sema(p))
                    .collect();
                let ret = ft.return_type
                    .map(|r| self.ast_type_to_sema(r))
                    .unwrap_or_else(|| self.void_ty());
                self.ctx.types.insert(SemaType::Function {
                    params,
                    return_type: ret,
                    is_fallible: ft.is_fallible,
                    generic_arity: 0, // bare `fn(..)`  type annotations are never generic
                })
            }
            TypeKind::Infer => self.fresh_var(),
        }
    }

    /// Convert an optional return annotation to `(TypeId, is_fallible)`.
    fn return_type_to_sema<'ast>(&mut self, ret: Option<&ReturnType<'ast>>) -> (TypeId, bool) {
        match ret {
            None => (self.void_ty(), false),
            Some(rt) => {
                let inner = self.ast_type_to_sema(rt.ty);
                let ty = if rt.is_fallible {
                    self.ctx.types.intern(SemaType::Fallible(inner))
                } else {
                    inner
                };
                (ty, rt.is_fallible)
            }
        }
    }

    // ── Phase 2a: Signature collection ────────────────────────────

    // ── Traits (docs/TRAITS_DESIGN.md, slice S1a) ────────────────────
    //
    // A trait is collected once (`collect_trait_info`), each `impl Trait for
    // Type` is then checked against it and its methods are registered into
    // the type's dispatch table (`register_trait_impls`), and a call is
    // resolved through that table, through a bound on a type parameter, or
    // through an explicit `Trait.method(value)`.

    /// Register every struct and enum's generic arity up front, so a
    /// signature that mentions one (an impl's `Self`, an alias target) is
    /// built correctly whatever order the declarations appear in.
    fn register_generic_arities<'ast>(&mut self, program: &Program<'ast>) {
        for item in program.items {
            let (name, arity) = match item {
                Item::Struct(s) => (s.name, s.generic_params.len()),
                Item::Enum(e)   => (e.name, e.generic_params.len()),
                _ => continue,
            };
            if let Some(id) = self.ctx.top_level_def(name) {
                self.generic_arity.insert(id, arity);
            }
        }
    }

    /// `Self` for an `impl`/`extend` block: the target type with its own
    /// generic parameters as `Param`s, or `None` when the target is not a
    /// plain named type.
    fn self_type_for_target<'ast>(&mut self, target: &Type<'ast>) -> Option<TypeId> {
        let def = self.target_type_def_id(target)?;
        let arity = self.generic_arity.get(&def).copied().unwrap_or(0);
        let args: Vec<TypeId> = (0..arity)
            .map(|i| self.ctx.types.intern(SemaType::Param(i)))
            .collect();
        Some(self.ctx.types.insert(SemaType::Named { def, args }))
    }

    /// How a name used where a trait is required resolves: the trait's
    /// definition, or what the name actually is (`None` = nothing by that
    /// name).
    fn resolve_trait_name(&self, name: &str) -> Result<DefId, Option<&'static str>> {
        let Some(id) = self.ctx.top_level_def(name) else { return Err(None); };
        Err(Some(match self.ctx.symbols.lookup(id).kind {
            DefKind::Trait             => return Ok(id),
            DefKind::Struct { .. }     => "struct",
            DefKind::Enum              => "enum",
            DefKind::Function { .. }   => "function",
            DefKind::Const             => "constant",
            DefKind::Static            => "static",
            DefKind::TypeAlias         => "type alias",
            _                          => "name that is not a trait",
        }))
    }

    fn method_shape_of_fn_type(&self, has_self: bool, fn_ty: TypeId) -> Option<MethodShape> {
        match self.ctx.types.get(fn_ty).clone() {
            SemaType::Function { params, return_type, is_fallible, .. } =>
                Some(MethodShape { has_self, params, return_type, is_fallible }),
            _ => None,
        }
    }

    /// The shape of a required method signature (no body), with `Self`
    /// already resolved to the trait's abstract `Self` parameter.
    fn shape_of_sig<'ast>(&mut self, sig: &MethodSig<'ast>) -> MethodShape {
        let params: Vec<TypeId> = sig.params.iter()
            .filter_map(|p| match p.kind {
                ParamKind::Named { ty, .. } | ParamKind::Discard { ty } =>
                    ty.map(|t| self.ast_type_to_sema(t)),
                _ => None,
            })
            .collect();
        let (return_type, is_fallible) = self.return_type_to_sema(sig.return_type.as_ref());
        MethodShape { has_self: has_self_param(sig.params), params, return_type, is_fallible }
    }

    /// Collect a trait: its required signatures and its default methods,
    /// all written in terms of the abstract `Self`.
    fn collect_trait_info<'ast>(&mut self, t: &TraitDecl<'ast>) {
        let Some(def_id) = self.ctx.top_level_def(t.name) else { return; };
        if !t.generic_params.is_empty() {
            self.errors.add_type_error(TypeError::UnsupportedTraitFeature {
                feature: "a generic trait",
                span:    t.span,
            });
        }
        let self_param = self.ctx.types.intern(SemaType::Param(t.generic_params.len()));
        let prev_self = self.self_type.replace(self_param);
        let prev_generics = self.push_generic_scope(t.generic_params);

        let mut methods: Vec<TraitMethodInfo> = Vec::with_capacity(t.items.len());
        for it in t.items {
            match it {
                TraitItem::MethodSig(sig) => {
                    let shape = self.shape_of_sig(sig);
                    methods.push(TraitMethodInfo {
                        name: sig.name.to_string(), shape, has_default: false,
                    });
                }
                TraitItem::DefaultMethod(m) => {
                    let fn_ty = self.collect_method_sig(m);
                    if let Some(shape) = self.method_shape_of_fn_type(has_self_param(m.params), fn_ty) {
                        methods.push(TraitMethodInfo {
                            name: m.name.to_string(), shape, has_default: true,
                        });
                    }
                }
                TraitItem::AssociatedType { span, .. } => {
                    self.errors.add_type_error(TypeError::UnsupportedTraitFeature {
                        feature: "an associated type",
                        span:    *span,
                    });
                }
            }
        }

        self.pop_generic_scope(prev_generics);
        self.self_type = prev_self;
        self.traits.insert(def_id, TraitInfo { name: t.name.to_string(), methods });
    }

    /// A trait's default method bodies. Inside one, `Self` is the trait's
    /// abstract `Self` parameter and `self` has that type, bounded by the
    /// trait itself, so `self.other_method()` resolves through the trait.
    fn infer_trait_default_bodies<'ast>(&mut self, t: &TraitDecl<'ast>) {
        let Some(trait_def) = self.ctx.top_level_def(t.name) else { return; };
        let self_param = self.ctx.types.intern(SemaType::Param(t.generic_params.len()));
        let prev_self_type = self.self_type.replace(self_param);
        let prev_struct = self.current_struct_type.replace(self_param);
        let mut bounds = HashMap::new();
        bounds.insert(self_param, vec![trait_def]);
        let prev_bounds = std::mem::replace(&mut self.current_bounds, bounds);
        let prev_generics = self.push_generic_scope(t.generic_params);
        for it in t.items {
            if let TraitItem::DefaultMethod(m) = it {
                self.infer_method_body(m);
            }
        }
        self.pop_generic_scope(prev_generics);
        self.current_bounds = prev_bounds;
        self.current_struct_type = prev_struct;
        self.self_type = prev_self_type;
    }

    /// A trait method's shape for one implementing type: the abstract
    /// `Self` replaced by `self_ty`.
    fn instantiate_trait_shape(&mut self, shape: &MethodShape, self_ty: TypeId) -> MethodShape {
        let params: Vec<TypeId> = shape.params.iter()
            .map(|p| self.substitute(*p, &[self_ty]))
            .collect();
        let return_type = self.substitute(shape.return_type, &[self_ty]);
        MethodShape { has_self: shape.has_self, params, return_type, is_fallible: shape.is_fallible }
    }

    /// Two types are the same when they print the same; an unknown on
    /// either side matches anything so one earlier error does not cascade.
    fn same_type(&self, a: TypeId, b: TypeId) -> bool {
        let (sa, sb) = (self.display_type(a), self.display_type(b));
        sa == sb || [&sa, &sb].iter().any(|s| s.contains("<unknown>") || s.contains("<e>"))
    }

    fn shapes_match(&self, a: &MethodShape, b: &MethodShape) -> bool {
        a.has_self == b.has_self
            && a.is_fallible == b.is_fallible
            && a.params.len() == b.params.len()
            && a.params.iter().zip(&b.params).all(|(x, y)| self.same_type(*x, *y))
            && self.same_type(a.return_type, b.return_type)
    }

    /// A signature as written in a diagnostic: `fn(self, int) string`.
    fn shape_text(&self, s: &MethodShape) -> String {
        let mut parts: Vec<String> = Vec::with_capacity(s.params.len() + 1);
        if s.has_self { parts.push("self".to_string()); }
        parts.extend(s.params.iter().map(|p| self.display_type(*p)));
        let fallible = if s.is_fallible { " (fallible)" } else { "" };
        format!("fn({}) {}{}", parts.join(", "), self.display_type(s.return_type), fallible)
    }

    /// Put one trait-supplied method into `target`'s dispatch table. An
    /// inherent method of the same name wins and the trait method is then
    /// reachable only as `Trait.method(value)`. Two traits supplying the
    /// same name keep the first in the table and mark the name ambiguous.
    fn add_trait_method(&mut self, target: DefId, trait_def: DefId, name: &str, shape: MethodShape) {
        let key = (target, name.to_string());
        let in_table = self.struct_methods.get(&target)
            .is_some_and(|ms| ms.iter().any(|(n, _)| n == name));
        // In the table but not put there by a trait: an inherent method.
        let inherent = in_table && !self.trait_entries.contains(&key);
        let origins = self.method_origins.entry(key.clone()).or_default();
        origins.push(trait_def);
        if inherent { return; }
        if origins.len() > 1 {
            self.ambiguous_methods.insert(key);
            return;
        }
        self.trait_entries.insert(key);
        self.struct_methods.entry(target).or_default().push((name.to_string(), shape));
    }

    /// Check every `impl Trait for Type` against its trait and register its
    /// methods (and the trait's default methods it does not override) into
    /// the type's dispatch table. Runs after the inherent registration so an
    /// inherent method is already there to win.
    fn register_trait_impls<'ast>(&mut self, program: &Program<'ast>) {
        for item in program.items {
            let Item::Impl(i) = item else { continue; };
            let Some(path) = i.trait_path else { continue; };
            let trait_name = path.last().copied().unwrap_or("");

            let trait_def = match self.resolve_trait_name(trait_name) {
                Ok(id) => id,
                Err(found) => {
                    self.errors.add_type_error(TypeError::NotATrait {
                        name: trait_name.to_string(), found, span: i.span,
                    });
                    continue;
                }
            };
            let target_def = self.target_type_def_id(i.target_type).filter(|d|
                matches!(self.ctx.symbols.lookup(*d).kind, DefKind::Struct { .. } | DefKind::Enum));
            let Some(target_def) = target_def else {
                self.errors.add_type_error(TypeError::UnsupportedTraitFeature {
                    feature: "implementing a trait for a type that is not a struct or enum",
                    span:    i.span,
                });
                continue;
            };
            if self.generic_arity.get(&target_def).copied().unwrap_or(0) > 0 {
                self.errors.add_type_error(TypeError::UnsupportedTraitFeature {
                    feature: "implementing a trait for a generic type",
                    span:    i.span,
                });
                continue;
            }
            let Some(info) = self.traits.get(&trait_def).cloned() else { continue; };
            let type_name = self.ctx.symbols.lookup(target_def).name.clone();

            if self.trait_impls.contains_key(&(trait_def, target_def)) {
                self.errors.add_type_error(TypeError::OverlappingImpl {
                    trait_name: info.name.clone(), type_name, span: i.span,
                });
                continue;
            }
            self.trait_impls.insert((trait_def, target_def), i.span);
            let self_ty = self.ctx.types.insert(SemaType::Named { def: target_def, args: Vec::new() });

            for tm in &info.methods {
                let impl_m = i.methods.iter().find(|m| m.name == tm.name.as_str());
                let expected = self.instantiate_trait_shape(&tm.shape, self_ty);
                match impl_m {
                    Some(m) => {
                        let fn_ty = self.ctx.resolutions.get(m.span)
                            .and_then(|d| self.ctx.def_type(d));
                        let found = fn_ty.and_then(|t|
                            self.method_shape_of_fn_type(has_self_param(m.params), t));
                        if let Some(found) = found {
                            if !self.shapes_match(&expected, &found) {
                                self.errors.add_type_error(TypeError::TraitMethodSignatureMismatch {
                                    trait_name: info.name.clone(),
                                    method:     tm.name.clone(),
                                    expected:   self.shape_text(&expected),
                                    found:      self.shape_text(&found),
                                    span:       m.span,
                                });
                            }
                        }
                        self.add_trait_method(target_def, trait_def, &tm.name, expected);
                    }
                    None if tm.has_default => {
                        self.add_trait_method(target_def, trait_def, &tm.name, expected);
                    }
                    None => {
                        self.errors.add_type_error(TypeError::TraitMethodMissing {
                            trait_name: info.name.clone(),
                            method:     tm.name.clone(),
                            type_name:  type_name.clone(),
                            span:       i.span,
                        });
                    }
                }
            }
            for m in i.methods {
                if !info.methods.iter().any(|tm| tm.name == m.name) {
                    self.errors.add_type_error(TypeError::UnknownTraitMethod {
                        trait_name: info.name.clone(),
                        method:     m.name.to_string(),
                        span:       m.span,
                    });
                }
            }
        }
    }

    /// Unify a call's arguments with a method's parameter types and report
    /// a wrong argument count. `args` are already inferred.
    fn check_method_args<'ast>(&mut self, params: &[TypeId], args: &[Arg<'ast>], call_span: Span) {
        if params.len() != args.len() {
            self.errors.add_type_error(TypeError::ArgumentCountMismatch {
                expected: params.len(),
                found:    args.len(),
                span:     call_span,
            });
        }
        for (arg, param_ty) in args.iter().zip(params.iter()) {
            let arg_span = match &arg.kind {
                ArgKind::Positional(e)       => e.span,
                ArgKind::Named { value, .. } => value.span,
            };
            if let Some(arg_ty) = self.ctx.expr_type(arg_span).map(|t| self.apply(t)) {
                self.unify(*param_ty, arg_ty, arg_span);
            }
        }
    }

    /// A type parameter as a diagnostic names it: its written name (`T`),
    /// or `Self` for a trait's abstract `Self`.
    fn param_display_name(&self, ty: TypeId) -> String {
        if self.self_type == Some(ty) { return "Self".to_string(); }
        self.current_generic_params.iter()
            .find(|(_, id)| **id == ty)
            .map(|(name, _)| name.clone())
            .unwrap_or_else(|| self.display_type(ty))
    }

    /// `x.method(..)` where `x` has a type-parameter type bounded by
    /// traits (inside a trait default body, the abstract `Self` bounded by
    /// the trait itself): the method must come from one of the bounds.
    fn call_through_bounds<'ast>(
        &mut self,
        receiver_ty: TypeId,
        bounds:      &[DefId],
        method:      &str,
        args:        &[Arg<'ast>],
        callee_span: Span,
        call_span:   Span,
    ) -> TypeId {
        let mut found: Vec<(String, MethodShape)> = Vec::new();
        for b in bounds {
            if let Some(info) = self.traits.get(b) {
                if let Some(m) = info.methods.iter().find(|m| m.name == method && m.shape.has_self) {
                    found.push((info.name.clone(), m.shape.clone()));
                }
            }
        }
        match found.len() {
            0 => {
                self.errors.add_type_error(TypeError::NoSuchMethod {
                    method:  method.to_string(),
                    on_type: self.param_display_name(receiver_ty),
                    span:    callee_span,
                });
                self.unknown()
            }
            1 => {
                let shape = self.instantiate_trait_shape(&found[0].1, receiver_ty);
                self.check_method_args(&shape.params, args, call_span);
                // The interpreter must run THIS trait's method for this call,
                // not an inherent method the concrete type may also have.
                self.ctx.trait_call_sites.insert(callee_span, found[0].0.clone());
                shape.return_type
            }
            _ => {
                self.errors.add_type_error(TypeError::AmbiguousTraitMethod {
                    method:    method.to_string(),
                    traits:    found.into_iter().map(|(n, _)| n).collect(),
                    type_name: self.param_display_name(receiver_ty),
                    span:      callee_span,
                });
                self.unknown()
            }
        }
    }

    /// `Trait.method(value, args..)`: the explicit form, which names the
    /// trait and so never has to choose between two traits supplying the
    /// same method. The first argument is the receiver and its type must
    /// implement the trait.
    fn infer_qualified_trait_call<'ast>(
        &mut self,
        trait_def: DefId,
        method:    &str,
        args:      &[Arg<'ast>],
        span:      Span,
    ) -> TypeId {
        let Some(info) = self.traits.get(&trait_def).cloned() else { return self.unknown(); };
        let Some(tm) = info.methods.iter().find(|m| m.name == method && m.shape.has_self) else {
            self.errors.add_type_error(TypeError::NoSuchMethod {
                method:  method.to_string(),
                on_type: format!("trait {}", info.name),
                span,
            });
            return self.unknown();
        };
        let Some(first) = args.first() else {
            self.errors.add_type_error(TypeError::ArgumentCountMismatch {
                expected: tm.shape.params.len() + 1,
                found:    0,
                span,
            });
            return self.unknown();
        };
        let first_span = match &first.kind {
            ArgKind::Positional(e)       => e.span,
            ArgKind::Named { value, .. } => value.span,
        };
        let Some(recv_ty) = self.ctx.expr_type(first_span).map(|t| self.apply(t)) else {
            return self.unknown();
        };
        if !self.type_implements(recv_ty, trait_def) {
            self.errors.add_type_error(TypeError::UnsatisfiedBound {
                type_name:  self.display_type(recv_ty),
                trait_name: info.name.clone(),
                span:       first_span,
            });
            return self.unknown();
        }
        let shape = self.instantiate_trait_shape(&tm.shape.clone(), recv_ty);
        self.check_method_args(&shape.params, &args[1..], span);
        shape.return_type
    }

    /// Whether `ty` implements `trait_def`: a user struct or enum with an
    /// `impl`, or a type parameter whose bounds include the trait. Anything
    /// unresolved or unknown counts as implementing it, so an earlier error
    /// does not cascade into this one.
    fn type_implements(&self, ty: TypeId, trait_def: DefId) -> bool {
        if ty == TypeId::ERROR { return true; }
        match self.ctx.types.get(ty) {
            SemaType::Named { def, .. } => self.trait_impls.contains_key(&(trait_def, *def)),
            SemaType::Param(_) => self.current_bounds.get(&ty)
                .is_some_and(|bs| bs.contains(&trait_def)),
            SemaType::Unknown | SemaType::Var(_) => true,
            _ => false,
        }
    }

    /// Expand every `type` alias to a fixpoint. Aliases may refer to each
    /// other in any declaration order, so each round converts every alias
    /// not yet done; one that mentions a not-yet-expanded alias is skipped
    /// (`alias_blocked`) and retried next round. A round with no progress
    /// means the remaining aliases can never finish: a cycle
    /// (`TYPE-121`). They get an `Unknown` target so uses of them do not
    /// cascade into further errors.
    ///
    /// Runs before any other signature is collected, so a struct field, a
    /// function parameter or a const written with an alias already sees
    /// the real type. Generic arities of structs and enums are registered
    /// first so an argument-count mistake inside an alias target
    /// (`type X = Box<int, int>`) is still reported.
    fn collect_alias_sigs<'ast>(&mut self, program: &Program<'ast>) {
        let aliases: Vec<&TypeAlias<'ast>> = program.items.iter()
            .filter_map(|item| match item { Item::TypeAlias(a) => Some(a), _ => None })
            .collect();
        if aliases.is_empty() { return; }

        for item in program.items {
            match item {
                Item::Struct(s) => {
                    if let Some(id) = self.ctx.top_level_def(s.name) {
                        self.generic_arity.insert(id, s.generic_params.len());
                    }
                }
                Item::Enum(e) => {
                    if let Some(id) = self.ctx.top_level_def(e.name) {
                        self.generic_arity.insert(id, e.generic_params.len());
                    }
                }
                _ => {}
            }
        }

        self.alias_prepass = true;
        let mut pending: Vec<&TypeAlias<'ast>> = aliases;
        while !pending.is_empty() {
            let mut still: Vec<&TypeAlias<'ast>> = Vec::with_capacity(pending.len());
            for a in pending.iter().copied() {
                let Some(def_id) = self.ctx.top_level_def(a.name) else { continue; };
                let prev_generics = self.push_generic_scope(a.generic_params);
                self.alias_blocked = false;
                let target = self.ast_type_to_sema(a.ty);
                let blocked = self.alias_blocked;
                self.pop_generic_scope(prev_generics);
                if blocked {
                    still.push(a);
                } else {
                    self.alias_expansions.insert(
                        def_id,
                        AliasExpansion { arity: a.generic_params.len(), target },
                    );
                    self.ctx.set_def_type(def_id, target);
                }
            }
            if still.len() == pending.len() {
                for a in still {
                    if let Some(def_id) = self.ctx.top_level_def(a.name) {
                        self.errors.add_type_error(TypeError::TypeAliasCycle {
                            name: a.name.to_string(),
                            span: a.span,
                        });
                        let unknown = self.unknown();
                        self.alias_expansions.insert(
                            def_id,
                            AliasExpansion { arity: a.generic_params.len(), target: unknown },
                        );
                        self.ctx.set_def_type(def_id, unknown);
                    }
                }
                break;
            }
            pending = still;
        }
        self.alias_prepass = false;
        self.alias_blocked = false;
    }

    /// Whether the struct or enum `def` declares an associated function
    /// (a method with no `self`) called `name`.
    fn has_static_method(&self, def: DefId, name: &str) -> bool {
        self.struct_methods.get(&def)
            .is_some_and(|ms| ms.iter().any(|(n, m)| n == name && !m.has_self))
    }

    /// The definition a type NAME written in an expression or pattern
    /// (`P { x = 1 }`, `P.origin()`, `C.Red`, `Message.Move { .. }`) stands
    /// for. An alias to a struct or enum is transparent there too, so it
    /// yields the struct or enum's own definition. An alias to anything
    /// else (an `int`, a `List<T>`) keeps the alias's definition, which
    /// has no struct fields, methods or variants, so every lookup keyed by
    /// it misses exactly as it would for any other non-struct name.
    fn type_def_of(&self, name: &str) -> Option<DefId> {
        let id = self.ctx.top_level_def(name)?;
        if matches!(self.ctx.symbols.lookup(id).kind, DefKind::TypeAlias) {
            if let Some(exp) = self.alias_expansions.get(&id) {
                if let SemaType::Named { def, .. } = self.ctx.types.get(exp.target) {
                    return Some(*def);
                }
            }
        }
        Some(id)
    }

    /// A use of a `type` alias: its target with the use site's generic
    /// arguments substituted in. During the alias pre-pass an alias that
    /// is not expanded yet blocks the alias being converted.
    fn expand_alias(&mut self, def_id: DefId, name: &str, args: Vec<TypeId>, span: Span) -> TypeId {
        let Some(exp) = self.alias_expansions.get(&def_id).copied() else {
            if self.alias_prepass { self.alias_blocked = true; }
            return self.unknown();
        };
        if exp.arity != args.len() {
            self.errors.add_type_error(TypeError::GenericArgCountMismatch {
                type_name: name.to_string(),
                expected:  exp.arity,
                found:     args.len(),
                span,
            });
            return self.unknown();
        }
        self.substitute(exp.target, &args)
    }

    fn collect_signatures<'ast>(&mut self, program: &Program<'ast>) {
        self.register_generic_arities(program);
        self.collect_alias_sigs(program);
        for item in program.items {
            match item {
                Item::Function(f) => { self.collect_fn_sig(f); }
                Item::Struct(s)   => { self.collect_struct_sig(s); }
                Item::Enum(e)     => { self.collect_enum_sig(e); }
                Item::Const(c)    => { self.collect_const_sig(c); }
                Item::Static(s)   => { self.collect_static_sig(s); }
                // `collect_method_sig` alone (below) records each method as
                // its own standalone symbol (a real, pre-existing, and
                // still-needed step — it's what makes `self.ctx.resolutions
                // .get(m.span)` resolve at all) but was never told which
                // struct the method actually belongs to. `TYPE-103`/
                // `TYPE-104` ("type X has no field/method Y") on any
                // `extend`/`impl`-block method — confirmed the actual,
                // reported bug — trace straight back to that: nothing here
                // ever touched `i.target_type`/`x.target_type`, so
                // `struct_methods` (the table `v.method()` dispatch
                // actually looks up, see `collect_struct_sig` below) never
                // got an entry for these methods at all. Fixed by
                // `register_extend_impl_methods`, a deliberately separate
                // pass run after this one finishes (not folded into this
                // loop) so every struct's own `collect_struct_sig` entry
                // already exists to append onto, regardless of whether the
                // `extend`/`impl` block appears before or after the
                // `struct` it targets in the source file.
                Item::Impl(i)     => {
                    let prev = self.self_type;
                    self.self_type = self.self_type_for_target(i.target_type);
                    for m in i.methods { self.collect_method_sig(m); }
                    self.self_type = prev;
                }
                Item::Extend(x) => {
                    let prev = self.self_type;
                    self.self_type = self.self_type_for_target(x.target_type);
                    for m in x.methods { self.collect_method_sig(m); }
                    self.self_type = prev;
                }
                Item::Trait(t) => self.collect_trait_info(t),
                Item::TypeAlias(_) => {} // expanded up front by `collect_alias_sigs`
            }
        }
        self.register_extend_impl_methods(program);
        self.register_trait_impls(program);
    }

    /// The root name of a `target_type` written as a plain (possibly
    /// generic) path — `Vector2` out of `extend Vector2 { .. }`, `Box` out
    /// of `impl<T> Box<T> { .. }` — resolved to its declaring `DefId` the
    /// same way `ast_type_to_sema`'s own `TypeKind::Named` arm does for an
    /// ordinary type reference. `None` for anything that isn't a plain
    /// named path (there's nothing sensible for `extend`/`impl` to target
    /// otherwise) or that doesn't resolve to a known top-level type —
    /// silently skipped by the caller, the same lenient handling
    /// `ast_type_to_sema` gives an unresolved type name anywhere else in
    /// this file (not diagnosed as its own error yet).
    fn target_type_def_id<'ast>(&self, ty: &Type<'ast>) -> Option<DefId> {
        match ty.kind {
            TypeKind::Named { path, .. } => {
                let root = path.first().copied()?;
                // An alias target (`extend P { .. }` with `type P = Point`)
                // is the aliased struct or enum.
                self.type_def_of(root)
            }
            _ => None,
        }
    }

    /// Phase 2a continued: append every `extend`/`impl`-block method's
    /// shape onto its target struct's `struct_methods` entry, the same
    /// dispatch table an in-struct `struct S { fn f(self) {..} }` method
    /// already populates in `collect_struct_sig` below. Deliberately a
    /// second, later pass over `program.items` (not folded into the loop
    /// above) rather than an `.insert()` at each `Item::Impl`/`Item::Extend`
    /// site: `collect_struct_sig` uses a plain `.insert()` that would wipe
    /// out anything an earlier-processed `extend` block had already added
    /// for that struct, so this has to run once every struct's own entry
    /// already exists, appending via `.entry(..).or_default()` rather than
    /// ever inserting fresh.
    ///
    /// Trait `impl`s (`i.trait_path.is_some()`) are skipped here on
    /// purpose — traits themselves aren't dispatched through yet
    /// (`docs/PARKED_IDEAS.md`), so registering their methods into
    /// `struct_methods` would let `v.method()` resolve to a method whose
    /// trait requirement was never actually checked. An inherent `impl`
    /// (`impl Type { .. }`, `trait_path: None`) is registered exactly like
    /// `extend` — the two are equivalent for dispatch purposes today.
    ///
    /// Generic targets (`extend Box<T> { .. }`) reuse the target struct's
    /// own generic arity (`self.generic_arity`) to build the same `Self`
    /// shape `collect_struct_sig`/`infer_struct_bodies` use, but don't
    /// bind the `extend`/`impl` block's own generic parameter *names* —
    /// neither `ImplBlock` nor `ExtendDecl` carries its own
    /// `generic_params` list the way `StructDecl`/`FunctionDecl` do, so
    /// there's nothing here to bind them from. Out of scope for now
    /// (untested, unrequested); the common, non-generic case this was
    /// actually asked to fix is unaffected.
    fn register_extend_impl_methods<'ast>(&mut self, program: &Program<'ast>) {
        for item in program.items {
            let (target_type, methods) = match item {
                Item::Extend(x) => (x.target_type, x.methods),
                Item::Impl(i) if i.trait_path.is_none() => (i.target_type, i.methods),
                _ => continue,
            };
            let Some(def_id) = self.target_type_def_id(target_type) else { continue; };
            for m in methods {
                let Some(fn_ty) = self.ctx.def_type(
                    self.ctx.resolutions.get(m.span).unwrap_or(DefId::INVALID)
                ) else { continue; };
                let has_self = m.params.first()
                    .map(|p| matches!(p.kind,
                        ParamKind::SelfVal | ParamKind::SelfMut
                        | ParamKind::SelfRef | ParamKind::SelfRefMut))
                    .unwrap_or(false);
                if let SemaType::Function { params, return_type, is_fallible, .. } =
                    self.ctx.types.get(fn_ty).clone()
                {
                    self.struct_methods.entry(def_id).or_default().push((
                        m.name.to_string(),
                        MethodShape { has_self, params, return_type, is_fallible },
                    ));
                }
            }
        }
    }

    fn collect_fn_sig<'ast>(&mut self, f: &FunctionDecl<'ast>) -> TypeId {
        let prev_generics = self.push_generic_scope(f.generic_params);
        let mut param_tys: Vec<TypeId> = Vec::with_capacity(f.params.len());
        for p in f.params {
            if let ParamKind::Named { ty, .. } | ParamKind::Discard { ty } = p.kind {
                if let Some(t) = ty {
                    let ty_id = self.ast_type_to_sema(t);
                    param_tys.push(ty_id);
                    self.seed_param_type(p, ty_id);
                }
            }
        }
        let (ret_ty, is_fallible) = self.return_type_to_sema(f.return_type.as_ref());
        self.pop_generic_scope(prev_generics);
        let fn_ty = self.ctx.types.insert(SemaType::Function {
            params: param_tys,
            return_type: ret_ty,
            is_fallible,
            generic_arity: f.generic_params.len(),
        });
        if let Some(def_id) = self.ctx.top_level_def(f.name) {
            self.ctx.set_def_type(def_id, fn_ty);
            self.generic_arity.insert(def_id, f.generic_params.len());
        }
        fn_ty
    }

    fn collect_method_sig<'ast>(&mut self, m: &MethodDecl<'ast>) -> TypeId {
        // NOTE: a method's *own* extra generic params (beyond whatever
        // struct-level scope the caller may already have pushed, see
        // `collect_struct_sig`) aren't substituted at call sites yet;
        // scoped out for now (GENERICS_RULES.md "Known gaps"). Pushing
        // here would only matter for that unimplemented case, so it's
        // deliberately skipped rather than half-wired.
        let mut param_tys: Vec<TypeId> = Vec::with_capacity(m.params.len());
        for p in m.params {
            if let ParamKind::Named { ty, .. } | ParamKind::Discard { ty } = p.kind {
                if let Some(t) = ty {
                    let ty_id = self.ast_type_to_sema(t);
                    param_tys.push(ty_id);
                    self.seed_param_type(p, ty_id);
                }
            }
        }
        let (ret_ty, is_fallible) = self.return_type_to_sema(m.return_type.as_ref());
        let fn_ty = self.ctx.types.insert(SemaType::Function {
            params: param_tys,
            return_type: ret_ty,
            is_fallible,
            generic_arity: m.generic_params.len(),
        });
        if let Some(def_id) = self.ctx.resolutions.get(m.span) {
            self.ctx.set_def_type(def_id, fn_ty);
        }
        fn_ty
    }

    fn collect_struct_sig<'ast>(&mut self, s: &StructDecl<'ast>) {
        let Some(def_id) = self.ctx.top_level_def(s.name) else { return; };
        self.check_derive_attrs(s.attributes, false);
        let derived: HashSet<String> = crate::ast::common::derive_trait_names(s.attributes)
            .into_iter().map(str::to_string).collect();
        self.struct_derives.insert(def_id, derived);
        self.generic_arity.insert(def_id, s.generic_params.len());
        let prev_generics = self.push_generic_scope(s.generic_params);
        // The abstract "Self" type while collecting this struct's own
        // fields/methods — `Named { def, args: [Param(0), Param(1), ..] }`
        // for a generic struct, `Named { def, args: [] }` for a plain
        // one. Field/method signatures are stored in these (possibly
        // `Param`-containing) terms; every real use site substitutes
        // concrete args in via `substitute` (GENERICS_RULES.md).
        let self_args: Vec<TypeId> = (0..s.generic_params.len())
            .map(|i| self.ctx.types.intern(SemaType::Param(i)))
            .collect();
        let struct_ty = self.ctx.types.insert(SemaType::Named { def: def_id, args: self_args });
        self.ctx.set_def_type(def_id, struct_ty);
        let prev_self_type = self.self_type.replace(struct_ty);

        let mut fields:  Vec<(String, TypeId)>      = Vec::with_capacity(s.members.len());
        let mut methods: Vec<(String, MethodShape)> = Vec::new();

        for member in s.members {
            match member {
                StructMember::Field(f) => {
                    let field_ty = self.ast_type_to_sema(f.ty);
                    if let Some(field_def) = self.ctx.resolutions.get(f.span) {
                        self.ctx.set_def_type(field_def, field_ty);
                    }
                    fields.push((f.name.to_string(), field_ty));
                }
                StructMember::Method(m) => {
                    let fn_ty = self.collect_method_sig(m);
                    let has_self = m.params.first()
                        .map(|p| matches!(p.kind,
                            ParamKind::SelfVal | ParamKind::SelfMut
                            | ParamKind::SelfRef | ParamKind::SelfRefMut))
                        .unwrap_or(false);
                    if let SemaType::Function { params, return_type, is_fallible, .. } =
                        self.ctx.types.get(fn_ty).clone()
                    {
                        methods.push((m.name.to_string(), MethodShape {
                            has_self, params, return_type, is_fallible,
                        }));
                    }
                }
                StructMember::Property(_) => {}
            }
        }

        self.struct_fields.insert(def_id, fields);
        self.struct_methods.insert(def_id, methods);
        self.self_type = prev_self_type;
        self.pop_generic_scope(prev_generics);
    }

    fn collect_enum_sig<'ast>(&mut self, e: &EnumDecl<'ast>) {
        let Some(def_id) = self.ctx.top_level_def(e.name) else { return; };
        self.check_derive_attrs(e.attributes, true);
        self.generic_arity.insert(def_id, e.generic_params.len());
        let prev_generics = self.push_generic_scope(e.generic_params);
        let self_args: Vec<TypeId> = (0..e.generic_params.len())
            .map(|i| self.ctx.types.intern(SemaType::Param(i)))
            .collect();
        let enum_ty = self.ctx.types.insert(SemaType::Named { def: def_id, args: self_args });
        self.ctx.set_def_type(def_id, enum_ty);

        let mut shapes: Vec<(String, VariantShape)> = Vec::with_capacity(e.variants.len());
        let mut has_discriminant = false;
        let mut has_payload      = false;

        for variant in e.variants {
            if let Some(var_def) = self.ctx.resolutions.get(variant.span) {
                self.ctx.set_def_type(var_def, enum_ty);
            }
            let shape = match &variant.payload {
                EnumVariantPayload::None => VariantShape::None,
                EnumVariantPayload::Discriminant(expr) => {
                    has_discriminant = true;
                    // Auto-increment (ENUM_RULES.md §4 item 1) needs no
                    // active tracking here — nothing downstream currently
                    // reads a discriminant's chosen value back out (no
                    // `as int` cast exists yet), so this validates that
                    // the written expression is at least int-shaped and
                    // stops there. See this section's "Known gap."
                    let d_ty  = self.infer_expr(expr);
                    let int_ty = self.int_ty();
                    self.unify(int_ty, d_ty, expr.span);
                    VariantShape::Discriminant
                }
                EnumVariantPayload::Tuple(tys) => {
                    has_payload = true;
                    VariantShape::Tuple(tys.iter().map(|t| self.ast_type_to_sema(t)).collect())
                }
                EnumVariantPayload::Struct(fields) => {
                    has_payload = true;
                    VariantShape::Struct(
                        fields.iter()
                            .map(|f| (f.name.to_string(), self.ast_type_to_sema(f.ty)))
                            .collect()
                    )
                }
            };
            shapes.push((variant.name.to_string(), shape));
        }

        // ENUM_RULES.md §4 item 2 — an explicit discriminant and a
        // payload-carrying variant have no defined combined runtime
        // representation; reject the enum declaration outright rather
        // than silently picking one interpretation.
        if has_discriminant && has_payload {
            self.errors.add_type_error(TypeError::MixedDiscriminantAndPayload {
                enum_name: e.name.to_string(),
                span:      e.span,
            });
        }

        self.pop_generic_scope(prev_generics);
        self.enum_variants.insert(def_id, shapes);
    }

    /// Resolve `ty` down to `(enum DefId, variant shapes)` if it names a
    /// known enum, else `None` (covers non-enum types and unresolved
    /// vars uniformly — every enum caller below just treats "not an
    /// enum" the same way regardless of why). For a generic enum, the
    /// stored shapes (raw, `Param`-containing — see `collect_enum_sig`)
    /// are substituted against `ty`'s own concrete `args` before being
    /// returned, so every caller (`check_pattern`, tuple/struct-variant
    /// construction) gets already-concrete types for free and needs no
    /// generics-awareness of its own (GENERICS_RULES.md).
    fn enum_shapes_of(&mut self, ty: TypeId) -> Option<(DefId, Vec<(String, VariantShape)>)> {
        let resolved = self.apply(ty);
        let SemaType::Named { def, args } = self.ctx.types.get(resolved).clone() else { return None; };
        let raw_shapes = self.enum_variants.get(&def)?.clone();
        if args.is_empty() {
            return Some((def, raw_shapes));
        }
        let shapes: Vec<(String, VariantShape)> = raw_shapes.into_iter()
            .map(|(name, shape)| {
                let shape = match shape {
                    VariantShape::None         => VariantShape::None,
                    VariantShape::Discriminant => VariantShape::Discriminant,
                    VariantShape::Tuple(tys) => VariantShape::Tuple(
                        tys.into_iter().map(|t| self.substitute(t, &args)).collect()
                    ),
                    VariantShape::Struct(fields) => VariantShape::Struct(
                        fields.into_iter()
                            .map(|(n, t)| (n, self.substitute(t, &args)))
                            .collect()
                    ),
                };
                (name, shape)
            })
            .collect();
        Some((def, shapes))
    }

    /// Type-checks a match-arm pattern against the scrutinee's type,
    /// binding any names it introduces. Returns what it definitively
    /// covers, for the exhaustiveness check in `StmtKind::Match`/
    /// `ExprKind::Match`. ENUM_RULES.md.
    fn check_pattern<'ast>(&mut self, pat: &Pattern<'ast>, scrutinee_ty: TypeId) -> PatternCoverage {
        match &pat.kind {
            PatternKind::Wildcard => PatternCoverage::CatchAll,

            PatternKind::Ident { name, .. } => {
                if let Some((enum_def, shapes)) = self.enum_shapes_of(scrutinee_ty) {
                    if let Some((vname, shape)) = shapes.iter().find(|(n, _)| n == name) {
                        // The actual point of this section's fix: a bare
                        // unqualified variant name (`North`, not
                        // `Direction.North`) used to parse as this same
                        // PatternKind::Ident and silently behave as an
                        // unconditional binding — "always matches, binds
                        // name" per the interpreter's own comment — so
                        // whichever arm's name happened to come first
                        // fired regardless of the scrutinee's real value.
                        // Reinterpreted here now that the scrutinee's
                        // type is known: matches only this one variant,
                        // introduces no binding. Pass 1 already declared
                        // `name` as a fresh Local for the general-binding
                        // case; that declaration goes simply unused here,
                        // which is harmless.
                        let expected = match shape {
                            VariantShape::None | VariantShape::Discriminant => {
                                return PatternCoverage::Variants(vec![vname.clone()]);
                            }
                            VariantShape::Tuple(t)  => t.len(),
                            VariantShape::Struct(t) => t.len(),
                        };
                        // A payload-carrying variant referenced bare with
                        // no payload pattern at all (`Ok => ...` instead
                        // of `Ok(x)`) — surface it instead of silently
                        // treating `name` as a binding for a shape it
                        // doesn't fit.
                        self.errors.add_type_error(TypeError::VariantArityMismatch {
                            enum_name:    self.ctx.symbols.lookup(enum_def).name.clone(),
                            variant_name: vname.clone(),
                            expected,
                            found:        0,
                            span:         pat.span,
                        });
                        return PatternCoverage::Variants(vec![vname.clone()]);
                    }
                }
                // Genuine catch-all binding.
                if let Some(def_id) = self.ctx.resolutions.get(pat.span) {
                    self.ctx.set_def_type(def_id, scrutinee_ty);
                }
                PatternCoverage::CatchAll
            }

            PatternKind::Literal(lit) => {
                let lit_ty = self.infer_literal(lit, pat.span);
                self.unify(scrutinee_ty, lit_ty, pat.span);
                PatternCoverage::Other
            }

            PatternKind::Enum { path, payload } => {
                self.check_enum_pattern(path, payload, scrutinee_ty, pat.span)
            }

            PatternKind::Or(pats) => {
                let mut variants   = Vec::new();
                let mut catch_all  = false;
                for p in pats.iter() {
                    match self.check_pattern(p, scrutinee_ty) {
                        PatternCoverage::CatchAll     => catch_all = true,
                        PatternCoverage::Variants(vs) => variants.extend(vs),
                        PatternCoverage::Other        => {}
                    }
                }
                if catch_all { PatternCoverage::CatchAll }
                else if !variants.is_empty() { PatternCoverage::Variants(variants) }
                else { PatternCoverage::Other }
            }

            PatternKind::Tuple(pats) => {
                let resolved = self.apply(scrutinee_ty);
                if let SemaType::Tuple(elem_tys) = self.ctx.types.get(resolved) {
                    let elem_tys = elem_tys.clone();
                    for (p, t) in pats.iter().zip(elem_tys.iter()) {
                        self.check_pattern(p, *t);
                    }
                    for p in pats.iter().skip(elem_tys.len()) {
                        let fresh = self.fresh_var();
                        self.check_pattern(p, fresh);
                    }
                } else {
                    for p in pats.iter() {
                        let fresh = self.fresh_var();
                        self.check_pattern(p, fresh);
                    }
                }
                PatternCoverage::Other
            }

            // Struct-destructure / array / range / other-language-level
            // patterns aren't part of this section's scope — walked
            // permissively (bindings still get *some* type, so later
            // references don't dangle) without deep shape validation.
            // Doesn't affect enum exhaustiveness either way.
            // `Name { field, ... }` with a 1-segment name always parses
            // as this (not PatternKind::Enum) regardless of whether
            // `Name` turns out to be a plain struct or an enum's
            // struct-payload variant — the parser can't tell without
            // type info (`parse_pattern.rs`: 2+ segments is the only
            // syntactic signal it has, `Result.Err { code }` vs
            // `Point { x, y }`). Same reinterpretation this section
            // already does for bare `PatternKind::Ident` variant names —
            // if `name` matches a Struct-payload variant of the known
            // enum scrutinee, treat it as that; otherwise it's a genuine
            // struct pattern.
            PatternKind::Struct { name: Some(n), fields } => {
                if let Some((enum_def, shapes)) = self.enum_shapes_of(scrutinee_ty) {
                    if let Some((vname, shape)) = shapes.iter().find(|(sn, _)| sn == n) {
                        let vname = vname.clone();
                        return match shape {
                            VariantShape::Struct(field_tys) => {
                                let field_tys = field_tys.clone();
                                for f in fields.iter() {
                                    match field_tys.iter().find(|(fn_, _)| fn_ == f.field) {
                                        Some((_, t)) => {
                                            if let Some(sub_pat) = &f.pattern {
                                                self.check_pattern(sub_pat, *t);
                                            } else if let Some(def_id) = self.ctx.resolutions.get(f.span) {
                                                self.ctx.set_def_type(def_id, *t);
                                            }
                                        }
                                        None => {
                                            self.errors.add_type_error(TypeError::UnknownVariant {
                                                enum_name:    self.ctx.symbols.lookup(enum_def).name.clone(),
                                                variant_name: format!("{}.{{{}}}", vname, f.field),
                                                span:         f.span,
                                            });
                                        }
                                    }
                                }
                                PatternCoverage::Variants(vec![vname])
                            }
                            _ => {
                                // Real variant, wrong payload shape.
                                let expected = match shape {
                                    VariantShape::Tuple(t)  => t.len(),
                                    _                        => 0,
                                };
                                self.errors.add_type_error(TypeError::VariantArityMismatch {
                                    enum_name:    self.ctx.symbols.lookup(enum_def).name.clone(),
                                    variant_name: vname.clone(),
                                    expected,
                                    found:        fields.len(),
                                    span:         pat.span,
                                });
                                PatternCoverage::Variants(vec![vname])
                            }
                        };
                    }
                }
                for f in fields.iter() {
                    if let Some(sub_pat) = &f.pattern {
                        let fresh = self.fresh_var();
                        self.check_pattern(sub_pat, fresh);
                    } else if let Some(def_id) = self.ctx.resolutions.get(f.span) {
                        let fresh = self.fresh_var();
                        self.ctx.set_def_type(def_id, fresh);
                    }
                }
                PatternCoverage::Other
            }
            PatternKind::Struct { name: None, fields } => {
                for f in fields.iter() {
                    if let Some(sub_pat) = &f.pattern {
                        let fresh = self.fresh_var();
                        self.check_pattern(sub_pat, fresh);
                    } else if let Some(def_id) = self.ctx.resolutions.get(f.span) {
                        let fresh = self.fresh_var();
                        self.ctx.set_def_type(def_id, fresh);
                    }
                }
                PatternCoverage::Other
            }
            PatternKind::Array { elements, .. } => {
                for p in elements.iter() {
                    let fresh = self.fresh_var();
                    self.check_pattern(p, fresh);
                }
                PatternCoverage::Other
            }
            PatternKind::Extract(fields) => {
                for f in fields.iter() {
                    if let Some(sub_pat) = &f.pattern {
                        let fresh = self.fresh_var();
                        self.check_pattern(sub_pat, fresh);
                    } else if let Some(def_id) = self.ctx.resolutions.get(f.span) {
                        let fresh = self.fresh_var();
                        self.ctx.set_def_type(def_id, fresh);
                    }
                }
                PatternCoverage::Other
            }
            PatternKind::Range { .. } => PatternCoverage::Other,
        }
    }

    fn check_enum_pattern<'ast>(
        &mut self,
        path: &[&'ast str],
        payload: &EnumPatternPayload<'ast>,
        scrutinee_ty: TypeId,
        span: Span,
    ) -> PatternCoverage {
        let Some((enum_def, shapes)) = self.enum_shapes_of(scrutinee_ty) else {
            // Scrutinee isn't a known enum (Unknown/unresolved var, or a
            // genuinely non-enum type — that mismatch surfaces on its
            // own via the scrutinee's own inference). Still walk payload
            // sub-patterns with fresh vars so their bindings get *some*
            // type instead of dangling.
            self.check_enum_payload_fallback(payload);
            return PatternCoverage::Other;
        };

        let Some(variant_name) = path.last().copied() else { return PatternCoverage::Other; };

        let Some((vname, shape)) = shapes.iter().find(|(n, _)| n == variant_name) else {
            self.errors.add_type_error(TypeError::UnknownVariant {
                enum_name:    self.ctx.symbols.lookup(enum_def).name.clone(),
                variant_name: variant_name.to_string(),
                span,
            });
            self.check_enum_payload_fallback(payload);
            return PatternCoverage::Other;
        };
        let vname = vname.clone();

        match (shape, payload) {
            (VariantShape::None, EnumPatternPayload::None)
            | (VariantShape::Discriminant, EnumPatternPayload::None) => {}

            (VariantShape::Tuple(elem_tys), EnumPatternPayload::Tuple(pats)) => {
                let elem_tys = elem_tys.clone();
                if elem_tys.len() != pats.len() {
                    self.errors.add_type_error(TypeError::VariantArityMismatch {
                        enum_name:    self.ctx.symbols.lookup(enum_def).name.clone(),
                        variant_name: vname.clone(),
                        expected:     elem_tys.len(),
                        found:        pats.len(),
                        span,
                    });
                }
                for (sub_pat, elem_ty) in pats.iter().zip(elem_tys.iter()) {
                    self.check_pattern(sub_pat, *elem_ty);
                }
                for sub_pat in pats.iter().skip(elem_tys.len()) {
                    let fresh = self.fresh_var();
                    self.check_pattern(sub_pat, fresh);
                }
            }

            (VariantShape::Struct(field_tys), EnumPatternPayload::Struct(fields)) => {
                let field_tys = field_tys.clone();
                for f in fields.iter() {
                    match field_tys.iter().find(|(n, _)| n == f.field) {
                        Some((_, t)) => {
                            if let Some(sub_pat) = &f.pattern {
                                self.check_pattern(sub_pat, *t);
                            } else if let Some(def_id) = self.ctx.resolutions.get(f.span) {
                                self.ctx.set_def_type(def_id, *t);
                            }
                        }
                        None => {
                            self.errors.add_type_error(TypeError::UnknownVariant {
                                enum_name:    self.ctx.symbols.lookup(enum_def).name.clone(),
                                variant_name: format!("{}.{{{}}}", vname, f.field),
                                span:         f.span,
                            });
                            if let Some(sub_pat) = &f.pattern {
                                let fresh = self.fresh_var();
                                self.check_pattern(sub_pat, fresh);
                            }
                        }
                    }
                }
            }

            // Payload shape doesn't match the pattern's payload shape at
            // all (e.g. matching a tuple-payload variant with no parens,
            // or a fieldless variant with parens) — a degenerate arity
            // mismatch (0 either side vs. however many the pattern wrote).
            _ => {
                let (expected, found) = match (shape, payload) {
                    (VariantShape::Tuple(t), EnumPatternPayload::None)  => (t.len(), 0),
                    (VariantShape::Struct(t), EnumPatternPayload::None) => (t.len(), 0),
                    (VariantShape::None | VariantShape::Discriminant, EnumPatternPayload::Tuple(p))
                        => (0, p.len()),
                    (VariantShape::None | VariantShape::Discriminant, EnumPatternPayload::Struct(p))
                        => (0, p.len()),
                    _ => (0, 0),
                };
                self.errors.add_type_error(TypeError::VariantArityMismatch {
                    enum_name: self.ctx.symbols.lookup(enum_def).name.clone(),
                    variant_name: vname.clone(),
                    expected,
                    found,
                    span,
                });
                self.check_enum_payload_fallback(payload);
            }
        }

        PatternCoverage::Variants(vec![vname])
    }

    fn check_enum_payload_fallback<'ast>(&mut self, payload: &EnumPatternPayload<'ast>) {
        match payload {
            EnumPatternPayload::None => {}
            EnumPatternPayload::Tuple(pats) => {
                for p in pats.iter() {
                    let fresh = self.fresh_var();
                    self.check_pattern(p, fresh);
                }
            }
            EnumPatternPayload::Struct(fields) => {
                for f in fields.iter() {
                    if let Some(sub_pat) = &f.pattern {
                        let fresh = self.fresh_var();
                        self.check_pattern(sub_pat, fresh);
                    } else if let Some(def_id) = self.ctx.resolutions.get(f.span) {
                        let fresh = self.fresh_var();
                        self.ctx.set_def_type(def_id, fresh);
                    }
                }
            }
        }
    }

    /// Checks match-arm coverage against an enum scrutinee's full variant
    /// set, emitting `NonExhaustiveMatch` if neither a catch-all arm nor
    /// the union of every guard-less arm's coverage accounts for all of
    /// them. Pragmatic top-level-only exhaustiveness (no nested-pattern
    /// usefulness analysis) — not Rust's full decision-tree algorithm,
    /// but a real, useful check rather than none at all.
    fn check_match_exhaustiveness<'ast>(
        &mut self,
        scrutinee_ty: TypeId,
        arms: &[(PatternCoverage, bool /* has_guard */)],
        span: Span,
    ) {
        let Some((_, shapes)) = self.enum_shapes_of(scrutinee_ty) else { return; };

        if arms.iter().any(|(cov, has_guard)| !has_guard && matches!(cov, PatternCoverage::CatchAll)) {
            return;
        }

        let mut covered: std::collections::HashSet<&str> = std::collections::HashSet::new();
        for (cov, has_guard) in arms.iter() {
            if *has_guard { continue; }
            if let PatternCoverage::Variants(vs) = cov {
                covered.extend(vs.iter().map(|s| s.as_str()));
            }
        }

        let missing: Vec<String> = shapes.iter()
            .map(|(n, _)| n.clone())
            .filter(|n| !covered.contains(n.as_str()))
            .collect();

        if !missing.is_empty() {
            self.errors.add_type_error(TypeError::NonExhaustiveMatch {
                missing_variants: missing,
                span,
            });
        }
    }

    fn collect_const_sig<'ast>(&mut self, c: &ConstDecl<'ast>) {
        let Some(def_id) = self.ctx.top_level_def(c.name) else { return; };
        let ty = c.ty.map(|t| self.ast_type_to_sema(t))
            .unwrap_or_else(|| self.fresh_var());
        self.ctx.set_def_type(def_id, ty);
    }

    /// A static's type is always written out (the parser requires the
    /// annotation), so it is known before any body is inferred.
    fn collect_static_sig<'ast>(&mut self, s: &StaticDecl<'ast>) {
        let Some(def_id) = self.ctx.top_level_def(s.name) else { return; };
        let ty = self.ast_type_to_sema(s.ty);
        self.ctx.set_def_type(def_id, ty);
    }

    // ── Phase 2b: Body inference ──────────────────────────────────

    fn infer_bodies<'ast>(&mut self, program: &Program<'ast>) {
        for item in program.items {
            match item {
                Item::Function(f) => self.infer_function_body(f),
                Item::Struct(s)   => self.infer_struct_bodies(s),
                Item::Const(c)    => self.infer_const_body(c),
                Item::Static(s)   => self.infer_static_body(s),
                Item::Impl(i) => self.infer_extend_impl_bodies(i.target_type, i.methods),
                Item::Extend(x) => self.infer_extend_impl_bodies(x.target_type, x.methods),
                Item::Trait(t) => self.infer_trait_default_bodies(t),
                Item::Enum(_) | Item::TypeAlias(_) => {}
            }
        }
        self.finish_int_literals();
    }

    fn infer_function_body<'ast>(&mut self, f: &FunctionDecl<'ast>) {
        for param in f.params { self.seed_param(param); }
        let (ret_ty, is_fallible) = self.return_type_to_sema(f.return_type.as_ref());
        let prev_ret      = self.current_return.replace(ret_ty);
        let prev_fallible = self.current_fallible;
        self.current_fallible = is_fallible;
        let prev_tier = self.current_tier;
        self.current_tier = f.tier;
        self.infer_block(&f.body);
        self.finish_int_literals();
        self.current_return   = prev_ret;
        self.current_fallible = prev_fallible;
        self.current_tier     = prev_tier;
    }

    fn infer_method_body<'ast>(&mut self, m: &MethodDecl<'ast>) {
        for param in m.params { self.seed_param(param); }
        let (ret_ty, is_fallible) = self.return_type_to_sema(m.return_type.as_ref());
        let prev_ret      = self.current_return.replace(ret_ty);
        let prev_fallible = self.current_fallible;
        self.current_fallible = is_fallible;
        let prev_tier = self.current_tier;
        self.current_tier = m.tier;
        self.infer_block(&m.body);
        self.finish_int_literals();
        self.current_return   = prev_ret;
        self.current_fallible = prev_fallible;
        self.current_tier     = prev_tier;
    }

    /// Records a param's already-resolved type into the same side tables
    /// `seed_param` used to compute independently: the definition's own
    /// type (via `resolutions`, populated earlier by name_resolution) and
    /// its binding type (keyed by the param's own span). Called from
    /// `collect_fn_sig`/`collect_method_sig`, under whatever generic scope
    /// is active there, so a function's own generic params resolve
    /// correctly. `seed_param` below reads `binding_type` back instead of
    /// resolving `ast_type_to_sema` a second time with no generic scope of
    /// its own. See Open Decision #6, docs/MEMORY_MODEL.md.
    fn seed_param_type<'ast>(&mut self, param: &Param<'ast>, ty_id: TypeId) {
        if let Some(def_id) = self.ctx.resolutions.get(param.span) {
            self.ctx.set_def_type(def_id, ty_id);
            self.ctx.set_binding_type(param.span, ty_id);
        }
    }

    fn seed_param<'ast>(&mut self, param: &Param<'ast>) {
        match param.kind {
            ParamKind::Named { ty, .. } => {
                if self.ctx.binding_type(param.span).is_some() {
                    // Already resolved by collect_fn_sig/collect_method_sig,
                    // under the correct generic scope. Resolving again here
                    // used to both waste the work and, for a bad annotation,
                    // double-report the exact same diagnostic (see
                    // tests/fixtures/err_unique_missing_type_argument.ubl).
                    return;
                }
                let ty_id = ty.map(|t| self.ast_type_to_sema(t))
                    .unwrap_or_else(|| self.fresh_var());
                self.seed_param_type(param, ty_id);
            }
            _ => {} // self params (TODO when current_struct_type threaded in)
        }
    }

    fn infer_struct_bodies<'ast>(&mut self, s: &StructDecl<'ast>) {
        let Some(def_id) = self.ctx.top_level_def(s.name) else { return; };
        let prev_generics = self.push_generic_scope(s.generic_params);
        // `self`'s type for the duration of this struct's own method
        // bodies — see `current_struct_type`'s own doc comment. Rebuilt
        // here (not reused from `collect_struct_sig`) since that field
        // TypeId belongs to a different `push_generic_scope` call and
        // this is a fresh one — same positional `Param` indices, so the
        // *meaning* is identical, just a different `TypeId` instance.
        let self_args: Vec<TypeId> = (0..s.generic_params.len())
            .map(|i| self.ctx.types.intern(SemaType::Param(i)))
            .collect();
        let self_ty = self.ctx.types.insert(SemaType::Named { def: def_id, args: self_args });
        let prev_self = self.current_struct_type.replace(self_ty);
        let prev_self_type = self.self_type.replace(self_ty);
        for member in s.members {
            if let StructMember::Method(m) = member {
                self.infer_method_body(m);
            }
        }
        self.self_type = prev_self_type;
        self.current_struct_type = prev_self;
        self.pop_generic_scope(prev_generics);
    }

    /// The `extend`/`impl` twin of `infer_struct_bodies` just above: sets
    /// `current_struct_type` around each method body the same way, so
    /// `self.x` inside an `extend`/`impl` method actually type-checks
    /// against the real target struct instead of silently inferring as
    /// `Unknown` — previously the case for *every* `extend`/`impl` method
    /// (confirmed: `self.x + "not a number"` inside one raised no error at
    /// all before this), since nothing set `current_struct_type` for this
    /// path and `seed_param` explicitly does nothing for `self` params of
    /// its own (see that function's own `TODO` comment). Applies to every
    /// `impl`, trait or inherent — unlike dispatch registration
    /// (`register_extend_impl_methods`), which skips trait impls since
    /// traits aren't dispatched through yet, a trait impl's method body
    /// still deserves correct `self` typing for its own sake. Silently
    /// does nothing for a `target_type` that isn't a plain named path or
    /// doesn't resolve — same lenient handling as `target_type_def_id`'s
    /// other caller.
    fn infer_extend_impl_bodies<'ast>(
        &mut self,
        target_type: &'ast Type<'ast>,
        methods:     &'ast [MethodDecl<'ast>],
    ) {
        let Some(def_id) = self.target_type_def_id(target_type) else {
            for m in methods { self.infer_method_body(m); }
            return;
        };
        let arity = self.generic_arity.get(&def_id).copied().unwrap_or(0);
        let self_args: Vec<TypeId> = (0..arity)
            .map(|i| self.ctx.types.intern(SemaType::Param(i)))
            .collect();
        let self_ty = self.ctx.types.insert(SemaType::Named { def: def_id, args: self_args });
        let prev_self = self.current_struct_type.replace(self_ty);
        let prev_self_type = self.self_type.replace(self_ty);
        for m in methods {
            self.infer_method_body(m);
        }
        self.self_type = prev_self_type;
        self.current_struct_type = prev_self;
    }

    fn infer_const_body<'ast>(&mut self, c: &ConstDecl<'ast>) {
        let inferred = self.infer_expr(c.value);
        if let Some(def_id) = self.ctx.top_level_def(c.name) {
            if let Some(declared) = self.ctx.def_type(def_id) {
                self.unify(declared, inferred, c.value.span);
            } else {
                self.ctx.set_def_type(def_id, inferred);
            }
        }
        // A const's type is shared by every function that reads it, so
        // whatever its initializer left open is settled here, not left for
        // one unrelated caller to decide.
        self.finish_int_literals();
    }

    /// The initializer must match the declared type. As with a const, a
    /// literal in it is typed by that declaration (`static HP: u8 = 200`)
    /// and settled here, since the type is shared by every reader.
    fn infer_static_body<'ast>(&mut self, s: &StaticDecl<'ast>) {
        let inferred = self.infer_expr(s.value);
        if let Some(def_id) = self.ctx.top_level_def(s.name) {
            if let Some(declared) = self.ctx.def_type(def_id) {
                self.unify(declared, inferred, s.value.span);
            }
        }
        self.finish_int_literals();
    }

    // ── Block ─────────────────────────────────────────────────────

    fn infer_block<'ast>(&mut self, block: &Block<'ast>) -> TypeId {
        let mut last = self.void_ty();
        for stmt in block.stmts {
            last = self.infer_stmt(stmt);
        }
        last
    }

    /// Infer an `if`/`elif`/`else` branch body's type — either a
    /// `{ block }` (type of its last statement) or the single-line
    /// `then expr` form (type of the expression). Mirrors the
    /// `MatchArmBody` dispatch used for match arms below.
    fn infer_if_branch<'ast>(&mut self, body: &IfBranchBody<'ast>) -> TypeId {
        match body {
            IfBranchBody::Expr(e)  => self.infer_expr(e),
            IfBranchBody::Block(b) => self.infer_block(b),
        }
    }

    // ── Statements ────────────────────────────────────────────────

    fn infer_stmt<'ast>(&mut self, stmt: &Stmt<'ast>) -> TypeId {
        match &stmt.kind {
            StmtKind::Let { binding, ty, value, .. } => {
                let rhs_ty = self.infer_expr(value);
                let bind_ty = match ty {
                    Some(ann) => {
                        let ann_id = self.ast_type_to_sema(ann);
                        self.unify(ann_id, rhs_ty, stmt.span);
                        ann_id
                    }
                    None => rhs_ty,
                };
                self.record_binding(binding, bind_ty, stmt.span);
                self.void_ty()
            }
            StmtKind::Expr(e) => self.infer_expr(e),
            StmtKind::Return(maybe_e) => {
                let ret = maybe_e.map(|e| self.infer_expr(e))
                    .unwrap_or_else(|| self.void_ty());
                if let Some(expected) = self.current_return {
                    let expected_inner = match self.ctx.types.get(expected) {
                        SemaType::Fallible(inner) => *inner,
                        _ => expected,
                    };
                    self.unify(expected_inner, ret, stmt.span);
                }
                // NOT void_ty(): a block's trailing statement type matters
                // for expression-bodied lambdas (`fn(x) x * 2`), which unify
                // it against the lambda's inferred return type. A `return`
                // statement diverges — it has no meaningful "value" of its
                // own here, already unified against current_return above —
                // so this must be an unconstrained fresh var (unifies with
                // anything) rather than void (which would conflict with
                // whatever `ret` actually was, exactly like the never-taken
                // `Some` branch bug this fixes: correct type computed, then
                // silently overwritten by a hardcoded wrong one).
                self.fresh_var()
            }
            StmtKind::Fail(e)        => { self.infer_expr(e); self.void_ty() }
            StmtKind::Break(maybe_e) => { maybe_e.map(|e| self.infer_expr(e)); self.void_ty() }
            StmtKind::Continue       => self.void_ty(),
            StmtKind::Defer(e)       => { self.infer_expr(e); self.void_ty() }

            StmtKind::If(if_node) => {
                let cond    = self.infer_expr(if_node.condition);
                let bool_ty = self.bool_ty();
                self.unify(bool_ty, cond, if_node.condition.span);
                let then_ty = self.infer_if_branch(&if_node.then_body);
                for elif in if_node.elif_branches {
                    let ct = self.infer_expr(elif.condition);
                    self.unify(bool_ty, ct, elif.condition.span);
                    self.infer_if_branch(&elif.body);
                }
                if let Some(else_b) = &if_node.else_body {
                    let else_ty = self.infer_if_branch(else_b);
                    let void_ty = self.void_ty();
                    if then_ty != void_ty && else_ty != void_ty {
                        self.unify(then_ty, else_ty, stmt.span);
                    }
                }
                self.void_ty()
            }
            StmtKind::Match { scrutinee, arms } => {
                let scrutinee_ty = self.infer_expr(scrutinee);
                let mut coverage = Vec::with_capacity(arms.len());
                for arm in arms.iter() {
                    let cov = self.check_pattern(&arm.pattern, scrutinee_ty);
                    if let Some(g) = arm.guard { self.infer_expr(g); }
                    match &arm.body {
                        MatchArmBody::Expr(e)  => { self.infer_expr(e); }
                        MatchArmBody::Block(b) => { self.infer_block(b); }
                    }
                    coverage.push((cov, arm.guard.is_some()));
                }
                self.check_match_exhaustiveness(scrutinee_ty, &coverage, stmt.span);
                self.void_ty()
            }
            StmtKind::For { binding, iter, body } => {
                let iter_ty = self.infer_expr(iter);
                let elem_ty = self.element_type_of(iter_ty);
                self.record_binding(binding, elem_ty, stmt.span);
                self.infer_block(body);
                self.void_ty()
            }
            StmtKind::While { condition, body } => {
                let cond    = self.infer_expr(condition);
                let bool_ty = self.bool_ty();
                self.unify(bool_ty, cond, condition.span);
                self.infer_block(body);
                self.void_ty()
            }
            StmtKind::Loop(body) => { self.infer_block(body); self.void_ty() }
            // BUG FIX (MEMORY_MODEL.md §11) — this arm used to ignore
            // `allocator` entirely and push an arena scope for *every*
            // `with` block, so `with pool<T>(count) { }` and even
            // `with gc { }`/`with heap { }` silently got arena's escape-
            // boundary semantics whether they wanted them or not. Now
            // dispatches on the actual allocator kind; only `Arena` and
            // `Pool` push a scope, since those are the only two kinds
            // with a lifetime narrower than their enclosing function.
            StmtKind::With { allocator, body } => {
                match allocator {
                    AllocatorKind::Arena(_) => {
                        let _arena_id = self.push_arena();
                        self.infer_block(body);
                        self.pop_arena();
                    }
                    AllocatorKind::Pool { ty, count } => {
                        let elem_ty  = self.ast_type_to_sema(ty);
                        let count_ty = self.infer_expr(count);
                        let int_ty   = self.int_ty();
                        self.unify(int_ty, count_ty, count.span);
                        let _pool_id = self.push_pool(elem_ty);
                        self.infer_block(body);
                        self.pop_pool();
                    }
                    AllocatorKind::Gc | AllocatorKind::Heap => {
                        self.infer_block(body);
                    }
                }
                self.void_ty()
            }
            StmtKind::Using { bindings, body } => {
                for b in bindings.iter() {
                    let ty = self.infer_expr(b.value);
                    if let Some(def_id) = self.ctx.resolutions.get(b.span) {
                        self.ctx.set_def_type(def_id, ty);
                        self.ctx.set_binding_type(b.span, ty);
                    }
                }
                self.infer_block(body);
                self.void_ty()
            }
            StmtKind::Extract { value, .. } => { self.infer_expr(value); self.void_ty() }
            StmtKind::Try { body, catch_body, .. } => {
                self.infer_block(body);
                if let Some(cb) = catch_body { self.infer_block(cb); }
                self.void_ty()
            }
            StmtKind::Unsafe(body) => { self.infer_block(body); self.void_ty() }
        }
    }

    fn record_binding<'ast>(&mut self, target: &BindingTarget<'ast>, ty: TypeId, span: Span) {
        match target {
            BindingTarget::Ident(_) => {
                if let Some(def_id) = self.ctx.resolutions.get(span) {
                    self.ctx.set_def_type(def_id, ty);
                    self.ctx.set_binding_type(span, ty);
                }
            }
            BindingTarget::Destructure(_) => {
                self.ctx.set_binding_type(span, ty);
            }
        }
    }

    /// DATASTRUCTURES.md §1 — `for x in pool { }` iterates a `Pool<T>`
    /// directly, same as every other collection here; no `.iter()`
    /// method call needed (none of `List`/`Queue`/`Stack` have one
    /// either). Bare `T` values, not paired with their `Handle` — see
    /// `value_to_iter_vec`'s own doc comment on why.
    fn element_type_of(&mut self, collection_ty: TypeId) -> TypeId {
        let resolved = self.apply(collection_ty);
        match self.ctx.types.get(resolved) {
            SemaType::List(e)
            | SemaType::Set(e)
            | SemaType::Queue(e)
            | SemaType::Stack(e)
            | SemaType::Slice(e)
            | SemaType::InlineList(e)
            | SemaType::Pool(e)          => *e,
            SemaType::Array { elem, .. } => *elem,
            SemaType::ArenaRef { inner, .. } => {
                let inner = *inner;
                self.element_type_of(inner)
            }
            SemaType::PoolRef { inner, .. } => {
                let inner = *inner;
                self.element_type_of(inner)
            }
            _ => self.fresh_var(),
        }
    }

    // ── Expressions ───────────────────────────────────────────────

    fn infer_expr<'ast>(&mut self, expr: &Expr<'ast>) -> TypeId {
        let ty = self.infer_expr_inner(expr);
        self.ctx.set_expr_type(expr.span, ty);
        ty
    }

    /// GAP 2 — detect an `ArenaRef`/`PoolRef` value (MEMORY_MODEL.md §11
    /// generalized this from arena-only to both) flowing into a binding,
    /// struct field, or indexed slot whose own home scope (if any)
    /// doesn't match. Returns `true` if an escape was detected and
    /// reported (the caller should skip the generic `unify` to avoid a
    /// duplicate, less-specific diagnostic on the same expression).
    ///
    /// "Home arena/pool" per target shape:
    ///   - `Ident`  — the ArenaId (if any) the binding's *original*
    ///     `def_type` carries. Reassignment never mutates `def_types`
    ///     (only the unifier's substitution table changes), so re-reading
    ///     it here always reflects the declaration site, not the current
    ///     statement — exactly the "which arena does this binding belong
    ///     to" question we need.
    ///   - `Field { target: receiver, .. }` — the receiver's own
    ///     top-level ArenaId, if the receiver itself is arena-tagged
    ///     (i.e. the whole struct instance lives in that arena, so
    ///     storing a same-arena value into one of its fields is safe).
    ///     No struct field can be *declared* `ArenaRef` (no surface
    ///     syntax exists for it), so an untagged receiver's home arena
    ///     is always `None` — any arena-tagged value assigned into a
    ///     field on it is unconditionally an escape.
    ///   - `Index { target: container, .. }` — same idea, using the
    ///     indexed container's own top-level ArenaId.
    ///   - anything else (assignment through `Try`/`OptionalChain`, etc.)
    ///     — skipped. Rare enough in practice not to risk a false
    ///     positive from a shape this function doesn't model yet.
    ///
    /// Deliberately conservative: this only compares *top-level* tags,
    /// and for `Ident` targets it flags a mismatch even on the very
    /// first assignment to an untyped, not-yet-arena-tagged binding
    /// (e.g. an untyped function parameter). Proving that case safe in
    /// general requires liveness analysis this pass doesn't do — see
    /// docs/MEMORY_MODEL.md §6 for the reasoning; over-flagging a
    /// borderline-safe pattern is the right default for a memory-safety
    /// check, the same way a real borrow checker sometimes does.
    /// Same idea as the arena case immediately above, checked first
    /// since a value can only ever be tagged with one kind of scope ref
    /// at its top level. Reuses the exact same "home scope per target
    /// shape" resolution — only the tag type and the reported diagnostic
    /// differ, so `home_ty` is computed once and both checks probe it.
    fn check_assign_arena_escape<'ast>(
        &mut self,
        target: &Expr<'ast>,
        target_ty: TypeId,
        value_ty: TypeId,
        span: Span,
    ) -> bool {
        let home_ty: TypeId = match &target.kind {
            ExprKind::Ident(_) => target_ty,
            ExprKind::Field { target: receiver, .. } => {
                self.ctx.expr_type(receiver.span).unwrap_or(target_ty)
            }
            ExprKind::Index { target: container, .. } => {
                self.ctx.expr_type(container.span).unwrap_or(target_ty)
            }
            _ => return false,
        };

        if let Some(value_pool) = self.top_level_pool(value_ty) {
            if self.top_level_pool(home_ty) == Some(value_pool) { return false; }
            self.pool_escape(value_ty, span);
            return true;
        }

        let Some(value_arena) = self.top_level_arena(value_ty) else { return false; };
        if self.top_level_arena(home_ty) == Some(value_arena) { return false; }

        self.arena_escape(value_ty, span);
        true
    }

    fn infer_expr_inner<'ast>(&mut self, expr: &Expr<'ast>) -> TypeId {
        match &expr.kind {
            ExprKind::Lit(lit) => self.infer_literal(lit, expr.span),

            ExprKind::Ident(_) => {
                if let Some(def_id) = self.ctx.resolutions.get(expr.span) {
                    self.ctx.def_type(def_id).unwrap_or_else(|| self.fresh_var())
                } else {
                    self.unknown()
                }
            }

            ExprKind::SelfExpr => self.current_struct_type.unwrap_or_else(|| self.unknown()),

            ExprKind::ShortDecl { value, .. } => {
                let ty = self.infer_expr(value);
                if let Some(def_id) = self.ctx.resolutions.get(expr.span) {
                    self.ctx.set_def_type(def_id, ty);
                    self.ctx.set_binding_type(expr.span, ty);
                }
                ty
            }

            ExprKind::Assign { target, value, .. } => {
                let target_ty = self.infer_expr(target);
                let value_ty  = self.infer_expr(value);
                // GAP 2 — check for an arena escape first. If the assign
                // itself is the escape, report that specifically and skip
                // the generic structural unify below: since ArenaRef pairs
                // with mismatched arenas are never structurally compatible
                // (see `structurally_compatible`), unify would otherwise
                // immediately pile a second, less useful TypeMismatch on
                // top of the same problem.
                if !self.check_assign_arena_escape(target, target_ty, value_ty, expr.span) {
                    self.unify(target_ty, value_ty, expr.span);
                }
                self.void_ty()
            }

            ExprKind::Pipe { left, right } => {
                self.infer_expr(left);
                self.infer_expr(right)
            }

            ExprKind::BinOp { op, lhs, rhs } => {
                let lhs_ty = self.infer_expr(lhs);
                let rhs_ty = self.infer_expr(rhs);
                self.binop_result(*op, lhs_ty, rhs_ty, expr.span)
            }

            ExprKind::UnaryOp { op, operand } => {
                // `-128i8` (and the i16/i32/i64/isize equivalents):
                // special-cased the way Rust's own compiler conventionally
                // treats a negated integer literal, so the type's full
                // signed range — including its most-negative value — is
                // available to a literal written this way. Without this,
                // `TYPE-120` only ever sees the positive magnitude `128`
                // (see `int_suffix_fits`'s own doc comment for why that's
                // the check's default), which overflows `i8` even though
                // the actual value `-128` is `i8::MIN` and perfectly
                // valid. Scoped exactly like Rust's own special case: only
                // a literal *directly* under the `-` gets it (`-x` for a
                // variable `x` doesn't, only `-` immediately followed by
                // a suffixed literal does), and only signed suffixes have
                // a most-negative value to special-case in the first
                // place — this deliberately does not touch (or excuse)
                // `-5u8`, which stays exactly what it already was: sema
                // accepts it (there's no compile-time negation-validity
                // check for *any* type here, signed or not — matches
                // this codebase's existing convention of leaving
                // operator-validity to the interpreter's own runtime
                // panic, same as e.g. `"hello" + 5`), and the interpreter
                // panics on it at runtime ("cannot negate u8") the same
                // way it already did before this feature existed.
                if let (UnaryOp::Neg, ExprKind::Lit(Literal::TypedInt { raw, suffix })) =
                    (op, &operand.kind)
                {
                    if let Some(min_magnitude) = int_suffix_signed_min_magnitude(*suffix) {
                        if *raw <= min_magnitude {
                            return self.int_suffix_sema_type(*suffix);
                        }
                        // Falls through to the generic path below on
                        // purpose: `-200i8` really is out of range even
                        // negated, and that path is what raises `TYPE-120`
                        // for it.
                    }
                }
                // `-128` for an `i8` binding: an unsuffixed literal directly
                // under `-` is checked as the negative value it denotes, so
                // the type's most-negative value is reachable, and `-1` for
                // a `u8` is rejected instead of wrapping. The literal and the
                // negation share one type, so the operand records the same
                // var the whole expression returns.
                if let (UnaryOp::Neg, ExprKind::Lit(Literal::Int(n))) = (op, &operand.kind) {
                    let ty = self.infer_int_literal(-(*n as i128), operand.span);
                    self.ctx.set_expr_type(operand.span, ty);
                    return ty;
                }
                let op_ty = self.infer_expr(operand);
                match op {
                    UnaryOp::Not    => self.bool_ty(),
                    UnaryOp::Neg    => op_ty,
                    UnaryOp::BitNot => op_ty,
                    UnaryOp::Await  => self.unwrap_task(op_ty, expr.span),
                }
            }

            ExprKind::Call { callee, args } => {
                self.callee_field_pending = matches!(callee.kind, ExprKind::Field { .. });
                let callee_ty = self.infer_expr(callee);
                self.callee_field_pending = false;
                for arg in args.iter() {
                    match &arg.kind {
                        ArgKind::Positional(e)       => { self.infer_expr(e); }
                        ArgKind::Named { value, .. } => { self.infer_expr(value); }
                    }
                }

                // GAP 1 FIX — `<Collection>.new()` (e.g. `List.new()`) is
                // parsed as Call { callee: Field { target: Ident(ns), field:
                // "new" } }. The generic Field arm below has no field table
                // yet and always returns Unknown, so without this check
                // every builtin constructor call would type as Unknown and
                // silently skip arena coloring. Narrowly scoped to the
                // known constructor namespaces in builtin_constructor_type;
                // general field/method resolution is untouched. See
                // docs/MEMORY_MODEL.md §5.
                if let ExprKind::Field { target, field } = callee.kind {
                    if field == "new" {
                        if let ExprKind::Ident(ns) = target.kind {
                            // §11 FIX (MEMORY_MODEL.md) — `Pool.new()` is
                            // deliberately NOT in `builtin_constructor_type`:
                            // unlike `List.new()` etc. it has no generic
                            // argument of its own to infer fresh — its
                            // element type and capacity come from the
                            // innermost enclosing `with pool<T>(count) { }`
                            // block (the "Unify" design: `pool<T>(count)`
                            // is the low-level allocator, `Pool<T>` is the
                            // ergonomic handle scoped to it). Checked
                            // before the generic path below so a bare
                            // `Pool.new()` outside any pool block gets a
                            // clear, dedicated error instead of silently
                            // DATASTRUCTURES.md §5 — `InlineList.new(capacity)`:
                            // capacity must be a literal integer, checked
                            // directly against the argument's own AST
                            // node — genuine inline storage needs its
                            // size known at compile time, and this is
                            // the narrowest thing that guarantees that
                            // without building real const generics
                            // (confirmed the language has none anywhere:
                            // `parse_generic_params` only ever parses
                            // `Ident (: Bound)?`). Checked before the
                            // generic path below, same reasoning as the
                            // `Pool` special case just below this one.
                            if ns == "InlineList" {
                                let capacity_lit = args.first().and_then(|a| match a.kind {
                                    ArgKind::Positional(e) => match e.kind {
                                        ExprKind::Lit(Literal::Int(n)) if n >= 0 => Some(n as u64),
                                        _ => None,
                                    },
                                    _ => None,
                                });
                                if args.len() != 1 || capacity_lit.is_none() {
                                    self.errors.add_type_error(TypeError::InlineListCapacityNotLiteral {
                                        span: expr.span,
                                    });
                                    return self.unknown();
                                }
                                let elem = self.fresh_var();
                                let inline_list_ty = self.ctx.types.insert(SemaType::InlineList(elem));
                                return self.maybe_arena_ref(inline_list_ty);
                            }
                            // falling through to Unknown.
                            if ns == "Pool" {
                                match self.current_pool() {
                                    Some((pool_id, elem_ty)) => {
                                        if self.current_tier == TierAnnotation::Low {
                                            self.errors.add_tier_error(TierError::CollectionConstructionInLowTier {
                                                collection: "Pool".to_string(),
                                                span:       expr.span,
                                            });
                                        }
                                        let pool_ty = self.ctx.types.insert(SemaType::Pool(elem_ty));
                                        return self.ctx.types.insert(SemaType::PoolRef {
                                            pool:    pool_id,
                                            mutable: false,
                                            inner:   pool_ty,
                                        });
                                    }
                                    None => {
                                        self.errors.add_tier_error(TierError::PoolConstructedOutsideBlock {
                                            span: expr.span,
                                        });
                                        return self.unknown();
                                    }
                                }
                            }
                            // MEMORY_MODEL.md §9 — `Unique.new(value)`/
                            // `Shared.new(value)`/`SyncShared.new(value)`.
                            // Unlike `List.new()` etc. (`builtin_constructor_
                            // type`, fresh type var, resolved later by
                            // unification), these take exactly one REQUIRED
                            // argument and its own inferred type directly
                            // *is* T — no fresh var, no later unification
                            // needed. Tier-gated the opposite way collection
                            // construction is: banned everywhere except
                            // `@tier(low)`, since these three now *are* LOW
                            // tier's memory model (Open Decision #5,
                            // resolved). Checked here (not folded into
                            // `builtin_constructor_type`) for the same
                            // reason `InlineList`/`Pool` are — real logic
                            // beyond the generic fresh-var pattern.
                            if matches!(ns, "Unique" | "Shared" | "SyncShared") {
                                if args.len() != 1 {
                                    self.errors.add_type_error(TypeError::ArgumentCountMismatch {
                                        expected: 1,
                                        found:    args.len(),
                                        span:     expr.span,
                                    });
                                    return self.unknown();
                                }
                                if self.current_tier != TierAnnotation::Low {
                                    self.errors.add_tier_error(TierError::OwnershipWrapperOutsideLowTier {
                                        wrapper: ns.to_string(),
                                        actual:  self.current_tier,
                                        span:    expr.span,
                                    });
                                }
                                let arg_ty = match &args[0].kind {
                                    ArgKind::Positional(e)       => self.infer_expr(e),
                                    ArgKind::Named { value, .. } => self.infer_expr(value),
                                };
                                return self.ctx.types.insert(match ns {
                                    "Unique" => SemaType::Unique(arg_ty),
                                    "Shared" => SemaType::Shared(arg_ty),
                                    _        => SemaType::SyncShared(arg_ty), // exhaustive via the outer matches! guard
                                });
                            }
                            if let Some(ctor_ty) = self.builtin_constructor_type(ns) {
                                // §9 FIX (MEMORY_MODEL.md) — LOW tier has
                                // no memory model of its own yet
                                // (`OwnedRef` + borrow checker are Phase 4,
                                // not started). Without this check, a
                                // `@tier(low)` function calling
                                // `List.new()` etc. would fall straight
                                // through `maybe_arena_ref` below to a
                                // silent, untagged bare type — i.e.
                                // HIGH-tier (GC-default) semantics nobody
                                // has designed for LOW. Emit and continue
                                // (same non-fatal pattern as
                                // ArenaInWrongTier/MethodInWrongTier)
                                // rather than returning Unknown, so one
                                // bad constructor call doesn't cascade
                                // spurious errors through the rest of the
                                // function.
                                if self.current_tier == TierAnnotation::Low {
                                    self.errors.add_tier_error(TierError::CollectionConstructionInLowTier {
                                        collection: ns.to_string(),
                                        span:       expr.span,
                                    });
                                }
                                return self.maybe_arena_ref(ctor_ty);
                            }
                        }
                    }
                }

                // `Trait.method(value, ..)`: the explicit trait-qualified call.
                if let ExprKind::Field { target, field } = callee.kind {
                    if let ExprKind::Ident(ns) = target.kind {
                        if let Some(def_id) = self.ctx.top_level_def(ns) {
                            if matches!(self.ctx.symbols.lookup(def_id).kind, DefKind::Trait) {
                                return self.infer_qualified_trait_call(def_id, field, args, expr.span);
                            }
                        }
                    }
                }

                // ENUM_RULES.md — tuple-payload variant construction,
                // `Result.Ok(5)`. Separate check from the constructor
                // block above (that one's gated on `field == "new"`;
                // variant names are arbitrary). Struct-payload
                // construction (`Message.Move { x = 1, y = 2 }`) goes
                // through `ExprKind::StructLit` instead — different
                // surface syntax, already routed there by the parser.
                if let ExprKind::Field { target, field } = callee.kind {
                    if let ExprKind::Ident(ns) = target.kind {
                        if let Some(def_id) = self.type_def_of(ns) {
                            if let Some(shapes) = self.enum_variants.get(&def_id) {
                                let shapes  = shapes.clone();
                                // GENERICS_RULES.md — a fresh instantiation
                                // per call site (not the raw, possibly
                                // `Param`-containing stored type): a bare
                                // constructor call has no already-known
                                // concrete args, so they're inferred from
                                // how the payload argument(s) below unify
                                // against the (substituted) element types.
                                let enum_ty  = self.instantiate(def_id);
                                let inst_args: Vec<TypeId> = match self.ctx.types.get(enum_ty).clone() {
                                    SemaType::Named { args, .. } => args,
                                    _ => Vec::new(),
                                };
                                if let Some((vname, shape)) = shapes.iter().find(|(n, _)| n == field) {
                                    if let VariantShape::Tuple(elem_tys) = shape {
                                        let elem_tys: Vec<TypeId> = elem_tys.iter()
                                            .map(|t| self.substitute(*t, &inst_args))
                                            .collect();
                                        if elem_tys.len() != args.len() {
                                            self.errors.add_type_error(TypeError::VariantArityMismatch {
                                                enum_name:    ns.to_string(),
                                                variant_name: vname.clone(),
                                                expected:     elem_tys.len(),
                                                found:        args.len(),
                                                span:         expr.span,
                                            });
                                        }
                                        for (arg, elem_ty) in args.iter().zip(elem_tys.iter()) {
                                            if let ArgKind::Positional(e) = &arg.kind {
                                                let arg_ty = self.infer_expr(e);
                                                self.unify(*elem_ty, arg_ty, e.span);
                                            }
                                        }
                                        return self.maybe_arena_ref(enum_ty);
                                    }
                                } else if !self.has_static_method(def_id, field) {
                                    // Not a variant, and not an associated
                                    // fn declared in an `extend`/`impl`
                                    // block either (`Color.make()`): that
                                    // case falls through to the
                                    // associated-call branch below.
                                    self.errors.add_type_error(TypeError::UnknownVariant {
                                        enum_name:    ns.to_string(),
                                        variant_name: field.to_string(),
                                        span:         expr.span,
                                    });
                                    return self.unknown();
                                }
                            }
                        }
                    }
                }

                // GENERICS_RULES.md — struct associated/static function
                // calls: `Box.new(42)`, dispatched on the type name (the
                // matched method has no `self` param). Mirrors the enum
                // tuple-variant constructor check just above. Instance
                // calls (`boxed.unwrap()`) are handled separately, after
                // the builtin-instance-method block below, since that one
                // already needs the *receiver's* resolved type in scope
                // rather than a bare type name.
                if let ExprKind::Field { target, field } = callee.kind {
                    if let ExprKind::Ident(ns) = target.kind {
                        if let Some(def_id) = self.type_def_of(ns) {
                            if let Some(methods) = self.struct_methods.get(&def_id).cloned() {
                                if let Some((_, m)) = methods.iter().find(|(n, m)| n == field && !m.has_self) {
                                    let m = m.clone();
                                    let arity = self.generic_arity.get(&def_id).copied().unwrap_or(0);
                                    let fresh_args: Vec<TypeId> = (0..arity).map(|_| self.fresh_var()).collect();
                                    let params: Vec<TypeId> = m.params.iter()
                                        .map(|p| self.substitute(*p, &fresh_args))
                                        .collect();
                                    let return_type = self.substitute(m.return_type, &fresh_args);
                                    if params.len() != args.len() {
                                        self.errors.add_type_error(TypeError::ArgumentCountMismatch {
                                            expected: params.len(),
                                            found:    args.len(),
                                            span:     expr.span,
                                        });
                                    }
                                    for (arg, param_ty) in args.iter().zip(params.iter()) {
                                        let arg_span = match &arg.kind {
                                            ArgKind::Positional(e)       => e.span,
                                            ArgKind::Named { value, .. } => value.span,
                                        };
                                        if let Some(arg_ty) = self.ctx.expr_type(arg_span).map(|t| self.apply(t)) {
                                            self.unify(*param_ty, arg_ty, arg_span);
                                        }
                                    }
                                    return self.maybe_arena_ref(return_type);
                                }
                            }
                        }
                    }
                }

                // §8 FIX (MEMORY_MODEL.md) — builtin instance methods
                // (`myList.push(x)`, `"s".to_upper()`, ...). The generic
                // Field arm below has no field table (see that arm's own
                // TODO) and always infers Unknown, so without this every
                // builtin method call silently typed as Unknown: no
                // NoSuchMethod check, no arg-count check, no HIGH-only
                // rejection, and — the actual §8 gap — an
                // allocation-producing method's result (e.g. `to_upper`,
                // `split`, `keys`) had no receiver tier to inherit and
                // would've defaulted to un-tagged/GC regardless of whether
                // the receiver was arena- or owned-scoped, quietly
                // reopening Gap 2's escape hole from the result side
                // instead of the reference side.
                //
                // Narrowly scoped to `instance::resolve_receiver`'s six
                // builtin kinds (List/Str/Dict/Tuple/Queue/Stack); anything
                // else (user-defined struct methods, etc) falls through to
                // `call_return_type` below, unchanged. HIGH-only rejection
                // for a method flagged in `instance::is_high_only` lives
                // here too, not in tier_check.rs alongside await/LINQ's
                // otherwise-identical rule — tier_check (Pass 3) has no
                // `Unifier` of its own, and `expr_types` entries can still
                // be raw unresolved `Var`s at record-time, so resolving a
                // receiver's type correctly needs the live `apply()` this
                // pass already has.
                if let ExprKind::Field { target, field } = callee.kind {
                    let receiver_ty = self.ctx.expr_type(target.span)
                        .map(|ty| { let ty = self.default_if_int_lit(ty); self.apply(ty) });
                    if let Some(receiver_ty) = receiver_ty {
                        if let Some((wrap, kind, bare_ty)) =
                            instance::resolve_receiver(&self.ctx.types, receiver_ty)
                        {
                            let Some((ret, arity)) = instance::signature(kind, field) else {
                                let on_type = self.display_type(receiver_ty);
                                self.errors.add_type_error(TypeError::NoSuchMethod {
                                    method: field.to_string(),
                                    on_type,
                                    span: callee.span,
                                });
                                return self.unknown();
                            };
                            if args.len() != arity {
                                self.errors.add_type_error(TypeError::ArgumentCountMismatch {
                                    expected: arity,
                                    found:    args.len(),
                                    span:     expr.span,
                                });
                            }
                            if instance::is_high_only(kind, field)
                                && self.current_tier != TierAnnotation::High
                            {
                                self.errors.add_tier_error(TierError::MethodInWrongTier {
                                    method: field.to_string(),
                                    actual: self.current_tier,
                                    span:   expr.span,
                                });
                            }

                            // `Linqerizer<T>.select(selector)` and
                            // `.group_by(key_selector)` both have a return
                            // type that depends on the *argument's* own
                            // inferred type (the selector's return type),
                            // which `method_return_type`'s
                            // `(MethodReturn, ReceiverWrap, TypeId)` shape
                            // has no way to see — every other method here
                            // has a return shape that's a fixed function of
                            // the *receiver* alone. Intercept before the
                            // generic path runs, same relationship
                            // `Pool.new()`/`InlineList.new()`'s own
                            // constructor special cases already have to the
                            // generic `builtin_constructor_type` path.
                            if kind == instance::ReceiverKind::Linqerizer
                                && (field == "select" || field == "group_by")
                            {
                                let arg_span = args.first().map(|a| match &a.kind {
                                    ArgKind::Positional(e)       => e.span,
                                    ArgKind::Named { value, .. } => value.span,
                                });
                                let selector_ret = arg_span
                                    .and_then(|span| self.ctx.expr_type(span))
                                    .map(|ty| self.apply(ty))
                                    .and_then(|ty| match self.ctx.types.get(ty) {
                                        SemaType::Function { return_type, .. } => Some(*return_type),
                                        _ => None,
                                    })
                                    .unwrap_or_else(|| self.fresh_var());

                                if field == "select" {
                                    // Linqerizer<T> -> Linqerizer<U>, U = selector's return type.
                                    let linq = self.ctx.types.insert(SemaType::Linqerizer(selector_ret));
                                    return self.apply_receiver_wrap(wrap, linq);
                                } else {
                                    // group_by: Linqerizer<T> -> Dictionary<U, List<T>>,
                                    // U = key_selector's return type, T = this
                                    // Linqerizer's own (unchanged) element type.
                                    let elem = match self.ctx.types.get(bare_ty) {
                                        SemaType::Linqerizer(e) => *e,
                                        _ => self.fresh_var(),
                                    };
                                    let value_list = self.ctx.types.insert(SemaType::List(elem));
                                    let dict = self.ctx.types.insert(SemaType::Dictionary(selector_ret, value_list));
                                    return self.apply_receiver_wrap(wrap, dict);
                                }
                            }

                            return self.method_return_type(ret, wrap, bare_ty);
                        }

                        // GENERICS_RULES.md — user struct instance
                        // methods: `boxed.unwrap()`. `receiver_ty`'s own
                        // `args` are already the concrete instantiation
                        // (inferred back when `boxed` was constructed),
                        // so — unlike the associated-call case above —
                        // no fresh `Var`s are needed here, just substitute
                        // the receiver's own args straight in.
                        //
                        // MEMORY_MODEL.md §9 Open Decision #5's remaining
                        // half (PARKED_IDEAS.md, "Traits / interface
                        // system"): peel at most one ownership wrapper
                        // (`Unique`/`Shared`/`SyncShared`) before this
                        // check, mirroring `instance::resolve_receiver`'s
                        // own peel for the six builtin kinds just above.
                        // `resolve_receiver` can't be reused directly for
                        // this: it returns `None` outright for a bare
                        // `Named` struct (none of its `ReceiverKind` arms
                        // match one), discarding the very `bare_ty` this
                        // branch needs, so the peel is repeated narrowly
                        // here rather than threaded through that call.
                        // Not reapplied to the return type below, for the
                        // same reason `resolve_receiver`'s own comment
                        // gives: nothing here returns a value that itself
                        // needs `Unique`/`Shared`/`SyncShared` re-applied,
                        // only the tier wrap `maybe_arena_ref` already
                        // handles. The interpreter side needed no
                        // matching change: `eval_method_call`
                        // (`interpreter/eval/expr.rs`) already peels all
                        // three unconditionally, for every receiver, not
                        // just the six builtin kinds.
                        // The receiver is a type parameter with trait bounds
                        // (inside a trait default body: the abstract `Self`).
                        if matches!(self.ctx.types.get(receiver_ty), SemaType::Param(_)) {
                            if let Some(bounds) = self.current_bounds.get(&receiver_ty).cloned() {
                                return self.call_through_bounds(
                                    receiver_ty, &bounds, field, args, callee.span, expr.span,
                                );
                            }
                        }
                        let struct_recv_ty = match self.ctx.types.get(receiver_ty) {
                            SemaType::Unique(inner)
                            | SemaType::Shared(inner)
                            | SemaType::SyncShared(inner) => *inner,
                            _ => receiver_ty,
                        };
                        if let SemaType::Named { def, args: recv_args } =
                            self.ctx.types.get(struct_recv_ty).clone()
                        {
                            // A struct always has a methods entry (possibly
                            // empty), but an enum only gets one when an
                            // `extend`/`impl` block adds a method. Without
                            // this an unknown method on a plain enum value
                            // fell straight through to an unchecked call and
                            // panicked at runtime. Only a user struct or enum
                            // is treated as "has a (possibly empty) method
                            // list"; any other `Named` keeps the old path.
                            let is_user_type = matches!(
                                self.ctx.symbols.lookup(def).kind,
                                DefKind::Enum | DefKind::Struct { .. }
                            );
                            let methods_opt = self.struct_methods.get(&def).cloned()
                                .or_else(|| if is_user_type { Some(Vec::new()) } else { None });
                            if let Some(methods) = methods_opt {
                                // `c.cb(4)` where `cb` is a struct FIELD of
                                // function type, not a method. A real method
                                // of the same name wins (found first), the
                                // interpreter checks in the same order.
                                // Two traits supply this name and no inherent
                                // method does: the caller has to say which.
                                if self.ambiguous_methods.contains(&(def, field.to_string())) {
                                    let traits: Vec<String> = self.method_origins
                                        .get(&(def, field.to_string()))
                                        .map(|ts| ts.iter()
                                            .filter_map(|t| self.traits.get(t).map(|i| i.name.clone()))
                                            .collect())
                                        .unwrap_or_default();
                                    self.errors.add_type_error(TypeError::AmbiguousTraitMethod {
                                        method:    field.to_string(),
                                        traits,
                                        type_name: self.display_type(struct_recv_ty),
                                        span:      callee.span,
                                    });
                                    return self.unknown();
                                }
                                let found_method = methods.iter()
                                    .find(|(n, m)| n == field && m.has_self).cloned();
                                let calls_a_field = found_method.is_none()
                                    && self.struct_fields.get(&def)
                                        .is_some_and(|fs| fs.iter().any(|(n, _)| n == field));
                                if !calls_a_field { return match found_method {
                                    Some((_, m)) => {
                                        let m = m.clone();
                                        let params: Vec<TypeId> = m.params.iter()
                                            .map(|p| self.substitute(*p, &recv_args))
                                            .collect();
                                        let return_type = self.substitute(m.return_type, &recv_args);
                                        if params.len() != args.len() {
                                            self.errors.add_type_error(TypeError::ArgumentCountMismatch {
                                                expected: params.len(),
                                                found:    args.len(),
                                                span:     expr.span,
                                            });
                                        }
                                        for (arg, param_ty) in args.iter().zip(params.iter()) {
                                            let arg_span = match &arg.kind {
                                                ArgKind::Positional(e)       => e.span,
                                                ArgKind::Named { value, .. } => value.span,
                                            };
                                            if let Some(arg_ty) = self.ctx.expr_type(arg_span).map(|t| self.apply(t)) {
                                                self.unify(*param_ty, arg_ty, arg_span);
                                            }
                                        }
                                        self.maybe_arena_ref(return_type)
                                    }
                                    None => {
                                        // `.clone()` isn't a real entry in
                                        // `struct_methods` (nothing in
                                        // `StructDecl::members` produced
                                        // one). It's a derive-gated
                                        // pseudo-method, recognized here
                                        // directly instead. Mirrors the
                                        // interpreter's own dispatch order
                                        // (`eval_method_call`,
                                        // `interpreter/eval/expr.rs`):
                                        // a real user-defined method
                                        // named `clone` would already have
                                        // been found above and returned,
                                        // so this only ever fires for the
                                        // derived case.
                                        if field == "clone"
                                            && self.struct_derives.get(&def)
                                                .is_some_and(|d| d.contains("Clone"))
                                        {
                                            if !args.is_empty() {
                                                self.errors.add_type_error(TypeError::ArgumentCountMismatch {
                                                    expected: 0,
                                                    found:    args.len(),
                                                    span:     expr.span,
                                                });
                                            }
                                            return self.maybe_arena_ref(receiver_ty);
                                        }
                                        let on_type = self.display_type(receiver_ty);
                                        self.errors.add_type_error(TypeError::NoSuchMethod {
                                            method: field.to_string(),
                                            on_type,
                                            span:   callee.span,
                                        });
                                        self.unknown()
                                    }
                                }; }
                            }
                        }
                    }
                }

                self.call_return_type(callee_ty, args, expr.span)
            }

            ExprKind::Field { target, field } => {
                // Taken before anything is inferred, so it only ever
                // applies to this node; see `callee_field_pending`.
                let is_call_callee = std::mem::take(&mut self.callee_field_pending);
                // `EnumName.Variant` (fieldless/discriminant only — a
                // payload-carrying variant referenced bare with no call
                // isn't a valid value on its own; falls through to the
                // generic Unknown below same as any other unhandled
                // shape). Mirrors `Pool.new()`'s constructor special-
                // case: recognized syntactically here rather than via
                // the general field table, which doesn't exist yet.
                if let ExprKind::Ident(name) = &target.kind {
                    if let Some(def_id) = self.type_def_of(name) {
                        if let Some(shapes) = self.enum_variants.get(&def_id) {
                            let shapes = shapes.clone();
                            if let Some((_, shape)) = shapes.iter().find(|(n, _)| n == field) {
                                if matches!(shape, VariantShape::None | VariantShape::Discriminant) {
                                    // GENERICS_RULES.md — fresh per-use
                                    // instantiation, same reasoning as the
                                    // tuple-variant constructor above:
                                    // `Option.None` has no argument to
                                    // infer T from here, so it starts as
                                    // an unresolved Var and picks up a
                                    // concrete type from wherever the
                                    // result is used (an annotation, a
                                    // return type, a later unify).
                                    let enum_ty = self.instantiate(def_id);
                                    return self.maybe_arena_ref(enum_ty);
                                }
                            } else if !self.has_static_method(def_id, field) {
                                // When this is the callee of a call
                                // (`Color.nothing()`), the `Call` arm reports
                                // the same unknown name against the whole
                                // call, so reporting it here too is one typo
                                // shown twice.
                                if !is_call_callee {
                                    self.errors.add_type_error(TypeError::UnknownVariant {
                                        enum_name:    name.to_string(),
                                        variant_name: field.to_string(),
                                        span:         expr.span,
                                    });
                                }
                                return self.unknown();
                            }
                        }
                    }
                }

                // GENERICS_RULES.md / struct field access — `foo.field`
                // on a plain struct instance. `Named { def, args }`'s
                // `args` are already the receiver's *own* concrete
                // instantiation (inferred back when the receiver itself
                // was constructed), so no fresh-var allocation is needed
                // here — just substitute into the field's raw stored type.
                let receiver_ty = self.infer_expr(target);
                let receiver_ty = self.default_if_int_lit(receiver_ty);
                let receiver_ty = self.apply(receiver_ty);
                if let SemaType::Named { def, args } = self.ctx.types.get(receiver_ty).clone() {
                    if let Some(fields) = self.struct_fields.get(&def).cloned() {
                        if let Some((_, raw_ty)) = fields.iter().find(|(n, _)| n == field) {
                            return self.substitute(*raw_ty, &args);
                        }
                        // Not a field — this `ExprKind::Field` may be
                        // getting pre-inferred as the *callee* of an
                        // enclosing `Call` (`Box.new(..)`, `boxed.unwrap()`
                        // — the Call arm unconditionally infers its
                        // callee before running its own static/instance
                        // method dispatch, same as it already did for
                        // enum tuple-variant construction pre-dating this
                        // change). A real method name here is expected
                        // and not an error; only a name that's neither a
                        // field nor a method is genuinely unknown.
                        let is_method = self.struct_methods.get(&def)
                            .map(|ms| ms.iter().any(|(n, _)| n == field))
                            .unwrap_or(false)
                            // `.clone()` is a derive-gated pseudo-method,
                            // not a real `struct_methods` entry. This
                            // `Field` node is only ever the pre-inferred
                            // *callee* of an enclosing `Call` when it's
                            // "clone" (there's no real field of that
                            // name either), so this only needs to stop
                            // `NoSuchField` from firing here; the actual
                            // return-type computation happens in the
                            // `Call` arm's own instance-method dispatch
                            // below, which already knows about `Clone`.
                            || (*field == "clone" && self.struct_derives.get(&def)
                                .is_some_and(|d| d.contains("Clone")));
                        if !is_method && !is_call_callee {
                            let on_type = self.display_type(receiver_ty);
                            self.errors.add_type_error(TypeError::NoSuchField {
                                field: field.to_string(),
                                on_type,
                                span:  expr.span,
                            });
                        }
                        return self.unknown();
                    }
                }
                self.unknown() // not a known struct/enum receiver
            }
            ExprKind::OptionalChain { target, .. } => {
                self.infer_expr(target);
                self.unknown() // TODO: field table
            }

            ExprKind::Index { target, index } => {
                let coll = self.infer_expr(target);
                self.infer_expr(index);
                self.element_type_of(coll)
            }

            ExprKind::Try(inner)   => {
                let inner_ty = self.infer_expr(inner);
                self.unwrap_fallible(inner_ty)
            }
            ExprKind::Borrow { mutable, place } => {
                let place_ty = self.infer_expr(place);
                self.ctx.types.insert(SemaType::Reference {
                    mutable:  *mutable,
                    lifetime: None, // no surface label at an expression site
                    inner:    place_ty,
                })
            }
            ExprKind::Deref(inner) => {
                let inner_ty = self.infer_expr(inner);
                self.unwrap_reference(inner_ty, expr.span)
            }
            ExprKind::Await(inner) => {
                let inner_ty = self.infer_expr(inner);
                self.unwrap_task(inner_ty, expr.span)
            }
            ExprKind::As { expr: inner, ty } => {
                self.infer_expr(inner);
                self.ast_type_to_sema(ty)
            }

            ExprKind::Array(elems) => {
                let elem_ty = if elems.is_empty() {
                    self.fresh_var()
                } else {
                    let first = self.infer_expr(elems[0]);
                    for e in &elems[1..] {
                        let ty = self.infer_expr(e);
                        self.unify(first, ty, e.span);
                    }
                    first
                };
                let list_ty = self.ctx.types.intern(SemaType::List(elem_ty));
                self.maybe_arena_ref(list_ty)
            }

            ExprKind::Tuple(elems) => {
                let ids: Vec<TypeId> = elems.iter().map(|e| self.infer_expr(e)).collect();
                let tuple_ty = self.ctx.types.insert(SemaType::Tuple(ids));
                self.maybe_arena_ref(tuple_ty)
            }

            ExprKind::Dict(entries) => {
                let (k0, v0) = if entries.is_empty() {
                    (self.fresh_var(), self.fresh_var())
                } else {
                    (self.infer_expr(entries[0].key), self.infer_expr(entries[0].value))
                };
                for entry in entries.iter().skip(1) {
                    let kt = self.infer_expr(entry.key);
                    let vt = self.infer_expr(entry.value);
                    self.unify(k0, kt, entry.span);
                    self.unify(v0, vt, entry.span);
                }
                let dict_ty = self.ctx.types.insert(SemaType::Dictionary(k0, v0));
                self.maybe_arena_ref(dict_ty)
            }

            ExprKind::AnonObject(fields) => {
                for f in fields.iter() { self.infer_expr(f.value); }
                self.unknown() // no structural record type yet
            }

            ExprKind::StructLit { path, fields } => {
                // ENUM_RULES.md — `Message.Move { x = 1, y = 2 }`, a
                // struct-payload variant construction, arrives here as a
                // 2-segment path (parser routes it the same as a plain
                // struct literal; the only signal it's an enum variant
                // is the extra path segment). Plain struct literals
                // (`Holder { data = ... }`, 1-segment) keep their
                // existing, unvalidated behavior below — general struct-
                // field checking isn't part of this section's scope.
                if path.len() >= 2 {
                    if let Some(def_id) = self.type_def_of(path[0]) {
                        if let Some(shapes) = self.enum_variants.get(&def_id) {
                            let shapes    = shapes.clone();
                            // GENERICS_RULES.md — same fresh-per-call-site
                            // reasoning as the tuple-variant constructor:
                            // the struct-payload fields' values below are
                            // what T gets inferred from via unification.
                            let enum_ty   = self.instantiate(def_id);
                            let inst_args: Vec<TypeId> = match self.ctx.types.get(enum_ty).clone() {
                                SemaType::Named { args, .. } => args,
                                _ => Vec::new(),
                            };
                            let variant   = path[path.len() - 1];
                            match shapes.iter().find(|(n, _)| n == variant) {
                                Some((vname, VariantShape::Struct(field_tys))) => {
                                    let vname     = vname.clone();
                                    let field_tys: Vec<(String, TypeId)> = field_tys.iter()
                                        .map(|(n, t)| (n.clone(), self.substitute(*t, &inst_args)))
                                        .collect();
                                    for f in fields.iter() {
                                        match field_tys.iter().find(|(n, _)| n == f.name) {
                                            Some((_, t)) => {
                                                let val_ty = self.infer_expr(f.value);
                                                self.unify(*t, val_ty, f.span);
                                            }
                                            None => {
                                                self.infer_expr(f.value);
                                                self.errors.add_type_error(TypeError::UnknownVariant {
                                                    enum_name:    path[0].to_string(),
                                                    variant_name: format!("{}.{{{}}}", vname, f.name),
                                                    span:         f.span,
                                                });
                                            }
                                        }
                                    }
                                    return self.maybe_arena_ref(enum_ty);
                                }
                                Some(_) => {
                                    // Real variant, wrong payload shape
                                    // (fieldless/tuple constructed with
                                    // `{ }` syntax) — walk fields once so
                                    // their own errors surface, but don't
                                    // fall through to the generic path
                                    // below (which would infer them
                                    // again and double-report).
                                    for f in fields.iter() { self.infer_expr(f.value); }
                                    return self.maybe_arena_ref(enum_ty);
                                }
                                None => {
                                    for f in fields.iter() { self.infer_expr(f.value); }
                                    self.errors.add_type_error(TypeError::UnknownVariant {
                                        enum_name:    path[0].to_string(),
                                        variant_name: variant.to_string(),
                                        span:         expr.span,
                                    });
                                    return self.unknown();
                                }
                            }
                        }
                    }
                }
                // GENERICS_RULES.md / plain struct literal field
                // validation — `Rectangle { width = w, height = h }`.
                // Fresh per-call-site instantiation, same as a struct's
                // `TypeName.method(..)` associated-function call: each
                // provided field's value is what the struct's own generic
                // args (if any) get inferred from.
                let root = path.first().copied().unwrap_or("");
                if let Some(def_id) = self.type_def_of(root) {
                    if let Some(decl_fields) = self.struct_fields.get(&def_id).cloned() {
                        let struct_ty  = self.instantiate(def_id);
                        let inst_args: Vec<TypeId> = match self.ctx.types.get(struct_ty).clone() {
                            SemaType::Named { args, .. } => args,
                            _ => Vec::new(),
                        };
                        for f in fields.iter() {
                            let val_ty = self.infer_expr(f.value);
                            match decl_fields.iter().find(|(n, _)| n == f.name) {
                                Some((_, raw_ty)) => {
                                    let field_ty = self.substitute(*raw_ty, &inst_args);
                                    self.unify_struct_field(def_id, field_ty, val_ty, f.span);
                                }
                                None => {
                                    self.errors.add_type_error(TypeError::NoSuchField {
                                        field:   f.name.to_string(),
                                        on_type: root.to_string(),
                                        span:    f.span,
                                    });
                                }
                            }
                        }
                        return self.maybe_arena_ref(struct_ty);
                    }
                }
                for f in fields.iter() { self.infer_expr(f.value); }
                let struct_ty = self.type_def_of(root)
                    .and_then(|id| self.ctx.def_type(id))
                    .unwrap_or_else(|| self.unknown());
                self.maybe_arena_ref(struct_ty)
            }

            ExprKind::Lambda(lambda) => {
                let param_tys: Vec<TypeId> = lambda.params.iter().map(|p| {
                    let ty = p.ty.map(|t| self.ast_type_to_sema(t))
                        .unwrap_or_else(|| self.fresh_var());
                    if let Some(def_id) = self.ctx.resolutions.get(p.span) {
                        self.ctx.set_def_type(def_id, ty);
                        self.ctx.set_binding_type(p.span, ty);
                    }
                    ty
                }).collect();
                let ret_var       = self.fresh_var();
                let prev_ret      = self.current_return.replace(ret_var);
                let prev_fallible = self.current_fallible;
                self.current_fallible = false;
                let body_ty = match &lambda.body {
                    LambdaBody::Block(b) => self.infer_block(b),
                    LambdaBody::Expr(e)  => self.infer_expr(e),
                };
                self.unify(ret_var, body_ty, lambda.span);
                self.current_return   = prev_ret;
                self.current_fallible = prev_fallible;
                let ret_resolved = self.apply(ret_var);
                let fn_ty = self.ctx.types.insert(SemaType::Function {
                    params:      param_tys,
                    return_type: ret_resolved,
                    is_fallible: false,
                    generic_arity: 0, // lambdas are never generic
                });
                // GAP 2 — closure capture. A lambda built inside a
                // `with arena(…)` block may capture arena-scoped locals
                // from the enclosing scope; lexical scoping guarantees
                // any such capture can only happen from inside that same
                // block. Tag every lambda constructed here the same way
                // array/tuple/dict/struct literals already are, so that
                // if *this lambda value* is later assigned outward,
                // returned, or stored in a struct field, the existing
                // escape checks catch it — no separate free-variable
                // capture analysis required. See module doc comment.
                self.maybe_arena_ref(fn_ty)
            }

            ExprKind::Block(b) => self.infer_block(b),

            ExprKind::If(if_node) => {
                let cond    = self.infer_expr(if_node.condition);
                let bool_ty = self.bool_ty();
                self.unify(bool_ty, cond, if_node.condition.span);
                let then_ty = self.infer_if_branch(&if_node.then_body);
                for elif in if_node.elif_branches {
                    let ct = self.infer_expr(elif.condition);
                    self.unify(bool_ty, ct, elif.condition.span);
                    self.infer_if_branch(&elif.body);
                }
                if let Some(else_b) = &if_node.else_body {
                    let else_ty = self.infer_if_branch(else_b);
                    let void_ty = self.void_ty();
                    if then_ty != void_ty { self.unify(then_ty, else_ty, expr.span); }
                    then_ty
                } else {
                    self.void_ty()
                }
            }

            ExprKind::Match(m) => {
                let scrutinee_ty = self.infer_expr(m.scrutinee);
                let void_ty = self.void_ty();
                let mut result = void_ty;
                let mut coverage = Vec::with_capacity(m.arms.len());
                for arm in m.arms.iter() {
                    let cov = self.check_pattern(&arm.pattern, scrutinee_ty);
                    if let Some(g) = arm.guard { self.infer_expr(g); }
                    let arm_ty = match &arm.body {
                        MatchArmBody::Expr(e)  => self.infer_expr(e),
                        MatchArmBody::Block(b) => self.infer_block(b),
                    };
                    if arm_ty != void_ty { result = arm_ty; }
                    coverage.push((cov, arm.guard.is_some()));
                }
                self.check_match_exhaustiveness(scrutinee_ty, &coverage, m.span);
                result
            }

            ExprKind::OrElse { expr: inner, fallback } => {
                let inner_ty = self.infer_expr(inner);
                if let OrElseFallback::Expr(fb) = fallback {
                    let fb_ty = self.infer_expr(fb);
                    self.unify(inner_ty, fb_ty, expr.span);
                }
                self.unwrap_optional(inner_ty)
            }
        }
    }

    // ── Integer-literal variables ──────────────────────────────────
    //
    // docs/PARKED_IDEAS.md, "Unsuffixed integer literals: full
    // context-driven typing (Rust style)". An unsuffixed literal starts
    // as a fresh type variable that remembers its value. Unifying that
    // variable with a concrete integer type range-checks the value
    // (`TYPE-120`) and binds it; unifying it with another literal
    // variable merges the two; unifying it with anything else (a float,
    // a struct, a string) is an ordinary type mismatch. Whatever is
    // still open when the enclosing body ends is a plain `int`.

    /// A new literal variable for one unsuffixed integer literal.
    fn infer_int_literal(&mut self, value: i128, span: Span) -> TypeId {
        let ty = self.fresh_var();
        if let &SemaType::Var(n) = self.ctx.types.get(ty) {
            self.int_lit_vars.insert(n, vec![IntLitUse { value, span }]);
        }
        self.int_lit_sites.push((span, ty));
        ty
    }

    /// The var number if `ty` (already `apply`-ed) is a still-open
    /// integer-literal variable.
    fn int_lit_var_of(&self, ty: TypeId) -> Option<u32> {
        if ty == TypeId::ERROR { return None; }
        match self.ctx.types.get(ty) {
            &SemaType::Var(n) if self.int_lit_vars.contains_key(&n) => Some(n),
            _ => None,
        }
    }

    /// Range-check every literal behind `var` against `target`, then bind
    /// the variable to it. `target_ty` must be a concrete integer type
    /// (the caller establishes that via `int_type_range`).
    fn bind_int_lit(&mut self, var: u32, target_ty: TypeId, range: (i128, i128, &'static str)) {
        let (min, max, name) = range;
        let uses = self.int_lit_vars.remove(&var).unwrap_or_default();
        for u in uses {
            if u.value < min || u.value > max {
                self.errors.add_type_error(TypeError::IntLiteralOutOfRange {
                    suffix:   name,
                    raw:      u.value.unsigned_abs() as u64,
                    negative: u.value < 0,
                    inferred: true,
                    span:     u.span,
                });
            }
        }
        self.unifier.bind(var, target_ty);
    }

    /// Settle an open literal variable as plain `int`.
    fn default_int_lit_var(&mut self, var: u32) {
        let int_ty = self.int_ty();
        let range  = int_type_range(&SemaType::Int).expect("int is an integer type");
        self.bind_int_lit(var, int_ty, range);
    }

    /// If `ty` is still an open literal variable, settle it as `int` and
    /// return `int`; otherwise return `ty` untouched. For the few places
    /// that need a concrete shape right now (a format hole, an `await`
    /// operand, a method receiver) rather than a type to unify later.
    ///
    /// The returned id is always the *resolved* type: a variable that an
    /// earlier call already settled must not come back as the stale
    /// unresolved id.
    fn default_if_int_lit(&mut self, ty: TypeId) -> TypeId {
        let applied = self.apply(ty);
        match self.int_lit_var_of(applied) {
            Some(var) => { self.default_int_lit_var(var); self.int_ty() }
            None      => applied,
        }
    }

    /// The literal-variable half of `unify`. `a` and `b` are already
    /// `apply`-ed and distinct. Returns `true` when at least one side was
    /// an open literal variable and this handled the pair completely.
    fn try_unify_int_lit(&mut self, a: TypeId, b: TypeId, span: Span) -> bool {
        let la = self.int_lit_var_of(a);
        let lb = self.int_lit_var_of(b);
        let (lit_var, lit_ty, other) = match (la, lb) {
            (None, None) => return false,
            // Two literals: one variable now stands for both.
            (Some(x), Some(y)) => {
                self.unifier.bind(x, b);
                if let Some(uses) = self.int_lit_vars.remove(&x) {
                    self.int_lit_vars.entry(y).or_default().extend(uses);
                }
                return true;
            }
            (Some(x), None) => (x, a, b),
            (None, Some(y)) => (y, b, a),
        };

        let other_ty = self.ctx.types.get(other).clone();

        // A concrete integer type: range-check and bind.
        if let Some(range) = int_type_range(&other_ty) {
            self.bind_int_lit(lit_var, other, range);
            return true;
        }
        match other_ty {
            // An ordinary variable simply becomes the literal's type.
            SemaType::Var(o) => { self.unifier.bind(o, lit_ty); true }
            // Unknown absorbs without cascading, as everywhere in `unify`.
            SemaType::Unknown => true,
            // `maybe_int == 5`: the literal meets the payload type.
            SemaType::Optional(inner) => { self.unify(inner, lit_ty, span); true }
            // Anything else cannot be an integer. Settle the literal as
            // `int` and unify again, so the mismatch (or scope-escape)
            // diagnostic reads exactly as it did before literals were
            // context-typed.
            _ => {
                self.default_int_lit_var(lit_var);
                self.unify(a, b, span);
                true
            }
        }
    }

    /// End of a body (or const initializer): record the width each
    /// literal ended up with for the interpreter, and settle every
    /// literal nothing constrained as plain `int`.
    fn finish_int_literals(&mut self) {
        let sites = std::mem::take(&mut self.int_lit_sites);
        for (span, ty) in sites {
            let applied = self.apply(ty);
            if let Some(var) = self.int_lit_var_of(applied) {
                self.default_int_lit_var(var);
                continue;
            }
            if applied == TypeId::ERROR { continue; }
            // `int`, `long`, `i64` and `isize` are all the interpreter's
            // default 64-bit value, so they need no entry.
            let suffix = match self.ctx.types.get(applied) {
                SemaType::I8    => Some(IntSuffix::I8),
                SemaType::I16   => Some(IntSuffix::I16),
                SemaType::I32   => Some(IntSuffix::I32),
                SemaType::U8    => Some(IntSuffix::U8),
                SemaType::U16   => Some(IntSuffix::U16),
                SemaType::U32 | SemaType::Uint              => Some(IntSuffix::U32),
                SemaType::U64 | SemaType::Ulong             => Some(IntSuffix::U64),
                SemaType::Usize                             => Some(IntSuffix::Usize),
                _ => None,
            };
            if let Some(s) = suffix {
                self.ctx.int_literal_types.insert(span, s);
            }
        }
    }

    // ── Literal typing ────────────────────────────────────────────

    fn infer_literal<'ast>(&mut self, lit: &Literal<'ast>, span: Span) -> TypeId {
        match lit {
            // Unsuffixed: the type comes from where the literal is used
            // (docs/PARKED_IDEAS.md, "Unsuffixed integer literals"), so it
            // starts as a literal type variable, see `infer_int_literal`.
            Literal::Int(n)   => self.infer_int_literal(*n as i128, span),
            // `TYPE-120`: a suffix (explicit or the lexer's own
            // auto-promoted implicit `u64`, see `Literal::TypedInt`'s doc
            // comment) claims a specific width -- check the value
            // actually fits it now, at the one place both are known
            // together, rather than silently wrapping it at runtime.
            Literal::TypedInt { raw, suffix } => {
                if !int_suffix_fits(*raw, *suffix) {
                    self.errors.add_type_error(TypeError::IntLiteralOutOfRange {
                        suffix:   suffix.as_str(),
                        raw:      *raw,
                        negative: false,
                        inferred: false,
                        span,
                    });
                }
                self.int_suffix_sema_type(*suffix)
            }
            Literal::Float(_) => self.ctx.types.intern(SemaType::Float),
            Literal::Double(_)=> self.ctx.types.intern(SemaType::Double),
            Literal::Bool(_)  => self.ctx.types.intern(SemaType::Bool),
            Literal::Char(_)  => self.ctx.types.intern(SemaType::Char),
            Literal::Null     => self.ctx.types.intern(SemaType::Null),
            Literal::Str(_) | Literal::VerbatimStr(_) => self.ctx.types.intern(SemaType::Str),
            // Real, pre-existing gap found while wiring format specs
            // through this exact literal: interpolation holes were
            // PARSED (parse_interp emits real parse errors for a broken
            // hole) but never actually TYPE-CHECKED — `$"{undefined_
            // name}"` sailed through sema undetected, only failing (or
            // not) at interpret time. Walking each hole's expression
            // here fixes that as a side effect of needing each hole's
            // type anyway, to validate its format spec against it.
            Literal::InterpolatedStr(parts)
            | Literal::InterpolatedVerbatimStr(parts) => {
                for part in parts.iter() {
                    if let InterpolationPart::Expr { expr, spec } = part {
                        let hole_ty = self.infer_expr(expr);
                        if let Some(spec) = spec {
                            self.check_format_spec(spec, hole_ty, expr.span);
                        }
                    }
                }
                self.ctx.types.intern(SemaType::Str)
            }
        }
    }

    /// The `SemaType` an explicit (or auto-promoted implicit) integer
    /// literal suffix resolves to. Always the Rust-named variant --
    /// there's no suffix syntax for the C#-named twins (`Uint`/`Long`/
    /// `Ulong`), see `IntSuffix`'s own doc comment.
    fn int_suffix_sema_type(&mut self, suffix: IntSuffix) -> TypeId {
        match suffix {
            IntSuffix::I8    => self.ctx.types.intern(SemaType::I8),
            IntSuffix::I16   => self.ctx.types.intern(SemaType::I16),
            IntSuffix::I32   => self.ctx.types.intern(SemaType::I32),
            IntSuffix::I64   => self.ctx.types.intern(SemaType::I64),
            IntSuffix::U8    => self.ctx.types.intern(SemaType::U8),
            IntSuffix::U16   => self.ctx.types.intern(SemaType::U16),
            IntSuffix::U32   => self.ctx.types.intern(SemaType::U32),
            IntSuffix::U64   => self.ctx.types.intern(SemaType::U64),
            IntSuffix::Isize => self.ctx.types.intern(SemaType::Isize),
            IntSuffix::Usize => self.ctx.types.intern(SemaType::Usize),
        }
    }

    /// `TYPE-116`/`TYPE-117`: `@derive(...)` recognizes six trait names
    /// today: `PartialEq`, `Eq`, `Hash`, `Ord`, `PartialOrd`, `Clone`,
    /// all struct-only for now (`on_enum`: an `enum`'s `==` is already
    /// structural, `Value::equals`'s Enum arm, so `@derive(PartialEq)`
    /// there is exactly as redundant as `@derive(Debug)` is everywhere;
    /// the other five simply aren't implemented for enum declarations
    /// yet, no derived ordering/hash/clone exists for an enum at all,
    /// so a request for one is treated the same as any other name this
    /// function doesn't recognize *in this context*, same as
    /// `UnknownDeriveTrait`'s own doc comment already frames the
    /// variant: "recognized, supported... in this context").
    ///
    /// Two passes: the first accepts or rejects each individual name
    /// (unrecognized, `Debug`/`Display`, `PartialEq`-on-enum, or a
    /// struct-only name used on an enum all report `UnknownDeriveTrait`
    /// here) and separately records which of the six were accepted; the
    /// second checks prerequisite chains against that full set,
    /// regardless of what order the names were written in (`@derive(Eq,
    /// PartialEq)` and `@derive(PartialEq, Eq)` are both fine): `Eq`
    /// needs `PartialEq`, `PartialOrd` needs `PartialEq`, `Ord` needs
    /// both `PartialOrd` and `Eq` (checked directly, not just
    /// transitively through `PartialOrd`, so `@derive(Ord)` alone
    /// reports both gaps rather than only the first one found), `Hash`
    /// needs `Eq` (not a real Rust supertrait bound for `Hash`, but the
    /// bound every actual hash-map API uses, and this project's whole
    /// reason for wanting `Hash`, a future `Dict` key. `Clone` has no
    /// prerequisite.
    ///
    /// Walks `attribute.args` directly rather than going through
    /// `ast::common::derive_trait_names` specifically so a non-`Ident`
    /// arg (`@derive("PartialEq")`, `@derive(x = 1)`) gets reported
    /// instead of silently vanishing. That helper exists for a
    /// different consumer (the interpreter, post-validation) that
    /// deliberately doesn't want to see those.
    fn check_derive_attrs(&mut self, attributes: &[Attribute], on_enum: bool) {
        const RECOGNIZED: &[&str] = &["PartialEq", "Eq", "Hash", "Ord", "PartialOrd", "Clone"];
        let mut present: HashSet<&str> = HashSet::new();
        let mut derive_span: Option<Span> = None;

        for attr in attributes.iter().filter(|a| a.name == "derive") {
            derive_span.get_or_insert(attr.span);
            for arg in attr.args.iter() {
                let bad_name = match arg {
                    AttrArg::Ident(name) if RECOGNIZED.contains(name) && !on_enum => {
                        present.insert(name);
                        None
                    }
                    AttrArg::Ident(name)         => Some(name.to_string()),
                    AttrArg::Str(s)              => Some(format!("\"{}\"", s)),
                    AttrArg::Int(n)              => Some(n.to_string()),
                    AttrArg::Bool(b)             => Some(b.to_string()),
                    AttrArg::Named { key, .. }   => Some(format!("{} = ...", key)),
                    AttrArg::Nested { name, .. } => Some(format!("{}(...)", name)),
                };
                if let Some(trait_name) = bad_name {
                    self.errors.add_type_error(TypeError::UnknownDeriveTrait {
                        trait_name,
                        span: attr.span,
                    });
                }
            }
        }

        let Some(span) = derive_span else { return; };
        let mut requires = |this: &mut Self, name: &str, needs: &str| {
            if present.contains(name) && !present.contains(needs) {
                this.errors.add_type_error(TypeError::DeriveRequiresOther {
                    trait_name: name.to_string(),
                    requires:   needs.to_string(),
                    span,
                });
            }
        };
        requires(self, "Eq", "PartialEq");
        requires(self, "PartialOrd", "PartialEq");
        requires(self, "Ord", "PartialOrd");
        requires(self, "Ord", "Eq");
        requires(self, "Hash", "Eq");
    }

    /// `.precision` only means something for Float/Double (decimal
    /// places) or Str (max length, truncating); `+`/zero-pad only mean
    /// something for Int/Float/Double; a numeric base only means
    /// something for Int; `#` only means something alongside a base.
    /// Anything else is a real error (`TYPE-115`/`TYPE-119`), not a
    /// silent no-op. Width/align/fill/`?` apply to any type (padding/
    /// truncation work on the rendered string regardless), so nothing
    /// to check for those.
    fn check_format_spec(&mut self, spec: &FormatSpec, hole_ty: TypeId, span: Span) {
        // Precision, `+`, zero-pad and a numeric base are only implemented
        // for plain `int` (and float/double/str) at runtime, see
        // `apply_format_spec`, so a spec that depends on the type settles
        // an open literal (`{255:x}`, or `n` in `let n = 255` used as
        // `{n:+}`) as `int`. Width, fill, alignment and `?` do not depend
        // on the type and leave it open for a later use to decide.
        let type_dependent = spec.precision.is_some() || spec.sign_plus
            || spec.zero_pad || spec.base.is_some();
        let hole_ty = if type_dependent {
            self.default_if_int_lit(hole_ty)
        } else {
            self.apply(hole_ty)
        };
        let resolved = self.ctx.types.get(hole_ty);
        let is_numeric = matches!(resolved, SemaType::Int | SemaType::Float | SemaType::Double);
        let on_type = || resolved.display(&self.ctx.types, &self.ctx.symbols);

        if spec.precision.is_some() {
            let ok = matches!(resolved, SemaType::Float | SemaType::Double | SemaType::Str);
            if !ok {
                self.errors.add_type_error(TypeError::InvalidFormatSpec {
                    spec_part: "precision".to_string(), on_type: on_type(), span,
                });
            }
        }
        if spec.sign_plus && !is_numeric {
            self.errors.add_type_error(TypeError::InvalidFormatSpec {
                spec_part: "sign (+)".to_string(), on_type: on_type(), span,
            });
        }
        if spec.zero_pad && !is_numeric {
            self.errors.add_type_error(TypeError::InvalidFormatSpec {
                spec_part: "zero-pad (0)".to_string(), on_type: on_type(), span,
            });
        }
        if spec.base.is_some() && !matches!(resolved, SemaType::Int) {
            self.errors.add_type_error(TypeError::InvalidFormatSpec {
                spec_part: "numeric base".to_string(), on_type: on_type(), span,
            });
        }
        if spec.alternate && spec.base.is_none() {
            self.errors.add_type_error(TypeError::AlternateFormatWithoutBase { span });
        }
    }

    // ── BinOp result type ─────────────────────────────────────────

    fn binop_result(&mut self, op: BinOp, lhs: TypeId, rhs: TypeId, span: Span) -> TypeId {
        match op {
            BinOp::Add | BinOp::Sub | BinOp::Mul | BinOp::Div | BinOp::Rem
            | BinOp::BitAnd | BinOp::BitOr | BinOp::BitXor | BinOp::Shl | BinOp::Shr => {
                self.unify(lhs, rhs, span);
                self.apply(lhs)
            }
            BinOp::Eq | BinOp::Ne => {
                self.unify(lhs, rhs, span);
                self.bool_ty()
            }
            // TYPE-118: previously nothing checked here at all, this
            // arm used to cover Eq/Ne/Lt/Le/Gt/Ge together, unifying the
            // operand types and calling it done, so `"a" < "b"` or two
            // structs compared with `<` sailed through sema only to hit
            // a runtime panic in `eval_binop`'s `promote_numeric`
            // ("arithmetic not supported on {type}"). Orderable now:
            // Int/Float/Double (the pre-existing numeric behavior,
            // unchanged), Str (newly real), and a struct that's
            // `@derive`d `PartialOrd`/`Ord` (newly real). Everything
            // else (`Bool` included, which used to reach the same
            // runtime panic Str did) now fails here instead, with a
            // real message pointing at the missing derive instead of an
            // opaque runtime crash.
            BinOp::Lt | BinOp::Le | BinOp::Gt | BinOp::Ge => {
                self.unify(lhs, rhs, span);
                let resolved = self.apply(lhs);
                let orderable = match self.ctx.types.get(resolved) {
                    SemaType::Int | SemaType::Float | SemaType::Double | SemaType::Str => true,
                    // The sized integers and `f32`/`f64` were missing from
                    // this list, so `a < b` on two `u32`s was TYPE-118
                    // even though the interpreter's `sized_int_binop`
                    // compares them fine.
                    SemaType::Uint | SemaType::Long | SemaType::Ulong
                    | SemaType::I8 | SemaType::I16 | SemaType::I32 | SemaType::I64
                    | SemaType::U8 | SemaType::U16 | SemaType::U32 | SemaType::U64
                    | SemaType::Isize | SemaType::Usize
                    | SemaType::F32 | SemaType::F64 => true,
                    // Two unconstrained literals (`1 < 2`) are still just
                    // an integer of some width, and integers are ordered.
                    SemaType::Var(n) if self.int_lit_vars.contains_key(n) => true,
                    SemaType::Named { def, .. } => self.struct_derives.get(def)
                        .is_some_and(|d| d.contains("PartialOrd") || d.contains("Ord")),
                    // Genuinely unresolved (e.g. a Linqerizer lambda
                    // parameter's type, still pending unification with
                    // the pipeline's element type at the point this
                    // particular comparison gets visited). "Don't know
                    // yet" isn't "known to be wrong". Not flagging this
                    // matches every other type check in this file: none
                    // of them treat `SemaType::Unknown` as a positive
                    // finding of its own.
                    SemaType::Unknown => true,
                    _ => false,
                };
                if !orderable {
                    let on_type = self.display_type(resolved);
                    self.errors.add_type_error(TypeError::TypeNotOrderable { on_type, span });
                }
                self.bool_ty()
            }
            BinOp::And | BinOp::Or => {
                let bool_ty = self.bool_ty();
                self.unify(bool_ty, lhs, span);
                self.unify(bool_ty, rhs, span);
                bool_ty
            }
            BinOp::Range | BinOp::RangeIncl => self.unknown(),
        }
    }

    // ── Type unwrapping helpers ───────────────────────────────────

    fn unwrap_task(&mut self, ty: TypeId, span: Span) -> TypeId {
        let ty = self.default_if_int_lit(ty);
        let resolved = self.apply(ty);
        match self.ctx.types.get(resolved) {
            SemaType::Task(inner) => *inner,
            SemaType::Var(_) => {
                let inner = self.fresh_var();
                let task  = self.ctx.types.intern(SemaType::Task(inner));
                self.unify(resolved, task, span);
                inner
            }
            _ => {
                self.errors.add_type_error(TypeError::AwaitOnNonTask {
                    found: self.display_type(ty),
                    span,
                });
                TypeId::ERROR
            }
        }
    }

    fn unwrap_reference(&mut self, ty: TypeId, span: Span) -> TypeId {
        let ty = self.default_if_int_lit(ty);
        let resolved = self.apply(ty);
        match self.ctx.types.get(resolved) {
            SemaType::Reference { inner, .. } => *inner,
            SemaType::Var(_) => {
                let inner = self.fresh_var();
                let reference = self.ctx.types.intern(SemaType::Reference {
                    mutable: false, lifetime: None, inner,
                });
                self.unify(resolved, reference, span);
                inner
            }
            _ => {
                self.errors.add_type_error(TypeError::DerefOnNonReference {
                    found: self.display_type(ty),
                    span,
                });
                TypeId::ERROR
            }
        }
    }

    fn unwrap_fallible(&mut self, ty: TypeId) -> TypeId {
        let resolved = self.apply(ty);
        match self.ctx.types.get(resolved) {
            SemaType::Fallible(inner) => *inner,
            _ => resolved,
        }
    }

    fn unwrap_optional(&mut self, ty: TypeId) -> TypeId {
        let resolved = self.apply(ty);
        match self.ctx.types.get(resolved) {
            SemaType::Optional(inner) => *inner,
            _ => resolved,
        }
    }

    /// GENERICS_RULES.md — was previously "just return the declared
    /// return type," with `args` inferred (each individually, for their
    /// own diagnostics) but never unified against the fn's own param
    /// types at all — not for generic functions, not for *any* plain
    /// function call. `identity(5)` and `identity(5, 5, 5)` type-checked
    /// identically. Fixed uniformly rather than special-cased to only
    /// generic callees: a non-generic fn's `generic_arity` is 0, so the
    /// fresh-Var/substitute step below is a no-op for it and this is
    /// just real argument checking that never existed, generic or not.
    fn call_return_type<'ast>(&mut self, callee_ty: TypeId, args: &[Arg<'ast>], span: Span) -> TypeId {
        let resolved = self.apply(callee_ty);
        match self.ctx.types.get(resolved).clone() {
            SemaType::Function { params, return_type, generic_arity, .. } => {
                let fresh_args: Vec<TypeId> = (0..generic_arity).map(|_| self.fresh_var()).collect();
                let params: Vec<TypeId> = params.iter()
                    .map(|p| self.substitute(*p, &fresh_args))
                    .collect();
                let return_type = self.substitute(return_type, &fresh_args);

                if params.len() != args.len() {
                    self.errors.add_type_error(TypeError::ArgumentCountMismatch {
                        expected: params.len(),
                        found:    args.len(),
                        span,
                    });
                }
                for (arg, param_ty) in args.iter().zip(params.iter()) {
                    let arg_span = match &arg.kind {
                        ArgKind::Positional(e)       => e.span,
                        ArgKind::Named { value, .. } => value.span,
                    };
                    if let Some(arg_ty) = self.ctx.expr_type(arg_span).map(|t| self.apply(t)) {
                        self.unify(*param_ty, arg_ty, arg_span);
                    }
                }
                return_type
            }
            SemaType::Var(_)   => self.fresh_var(),
            SemaType::Unknown  => self.unknown(),
            _ => {
                self.errors.add_type_error(TypeError::NoSuchMethod {
                    method:  "<call>".into(),
                    on_type: self.display_type(callee_ty),
                    span,
                });
                TypeId::ERROR
            }
        }
    }

    // ── Unification ───────────────────────────────────────────────

    /// GAP 2 / `docs/OUTLIVES_RULES.md` §8's "free win" — a plain
    /// struct-literal field normally goes through ordinary `unify`.
    /// One exception: the declaring struct is `edge` and the field's
    /// declared type is a *named*-lifetime reference (`&L T`). There,
    /// `unify`'s generic `scope_mismatch_side` rule (any `ArenaRef`-
    /// tagged value meeting a non-`ArenaRef` expected type is an
    /// escape) is too blunt — an `edge struct` field storing a
    /// reference built in the *same* arena the struct itself is being
    /// constructed in is exactly what `edge struct` exists for, not a
    /// violation. `MEMORY_MODEL.md` §9 already documented `is_edge` as
    /// fully decorative before this; this is the connection.
    ///
    /// Concretely: `&d` for an arena-resident `d` doesn't itself carry
    /// an outer `ArenaRef` tag — the tag lives one layer in, on the
    /// *pointee* (`Reference { inner: ArenaRef { inner: Data } }`, not
    /// `ArenaRef { inner: Reference { inner: Data } } }`), confirmed
    /// directly rather than assumed (an earlier version of this
    /// function checked the wrong layer and silently did nothing —
    /// caught by the probe script still failing after the "fix",
    /// not by re-reading the diff). So the tag has to be stripped from
    /// the *inner* type, reconstructing a plain `Reference` around it,
    /// before handing off to `unify` — not stripped from `val_ty`
    /// itself.
    ///
    /// Deferring doesn't mean skipping enforcement — it means routing
    /// it to `outlives_check.rs`'s own struct-literal boundary check
    /// instead (same loan-region machinery as the function-call case),
    /// which is what can actually tell "still live" from "already
    /// dead," not just "tagged with an arena at all." Every other case
    /// (non-`edge` structs, unnamed reference fields, non-arena
    /// values) falls through to plain `unify`, unchanged.
    fn unify_struct_field(&mut self, def_id: DefId, field_ty: TypeId, val_ty: TypeId, span: Span) {
        let is_edge = matches!(
            self.ctx.symbols.lookup(def_id).kind,
            DefKind::Struct { is_edge: true }
        );
        let field_is_named_ref = matches!(
            self.ctx.types.get(self.apply(field_ty)),
            SemaType::Reference { lifetime: Some(_), .. }
        );
        if is_edge && field_is_named_ref {
            let resolved_val = self.apply(val_ty);
            if let SemaType::Reference { mutable, lifetime, inner } = self.ctx.types.get(resolved_val).clone() {
                let resolved_inner = self.apply(inner);
                if let SemaType::ArenaRef { inner: stripped, .. } = self.ctx.types.get(resolved_inner).clone() {
                    let stripped_val_ty = self.ctx.types.insert(SemaType::Reference { mutable, lifetime, inner: stripped });
                    self.unify(field_ty, stripped_val_ty, span);
                    return;
                }
            }
        }
        self.unify(field_ty, val_ty, span);
    }

    fn unify(&mut self, a: TypeId, b: TypeId, span: Span) {
        let a = self.apply(a);
        let b = self.apply(b);
        if a == b { return; }

        // An integer-literal variable has its own binding rules (range
        // check, no implicit float, merging with other literals).
        if self.try_unify_int_lit(a, b, span) { return; }

        // FIX: use reference patterns so we don't try to move out of &SemaType.
        // u32 is Copy so binding through &SemaType::Var(v) gives v: u32.
        let a_is_var = matches!(self.ctx.types.get(a), SemaType::Var(_));
        let b_is_var = matches!(self.ctx.types.get(b), SemaType::Var(_));

        if a_is_var {
            if let &SemaType::Var(v) = self.ctx.types.get(a) {
                self.unifier.bind(v, b);
                return;
            }
        }
        if b_is_var {
            if let &SemaType::Var(v) = self.ctx.types.get(b) {
                self.unifier.bind(v, a);
                return;
            }
        }

        // Unknown / ERROR absorb without cascading.
        let a_unk = matches!(self.ctx.types.get(a), SemaType::Unknown);
        let b_unk = matches!(self.ctx.types.get(b), SemaType::Unknown);
        if a_unk || b_unk { return; }
        if a == TypeId::ERROR || b == TypeId::ERROR { return; }

        if self.structurally_compatible(a, b, span) { return; }

        // GAP 2 — an ArenaRef/PoolRef meeting an incompatible context (a
        // different scope, or a context with no scope at all — e.g. a
        // MID-tier function's declared return type, which can never
        // itself express either tag) is specifically a scope escape, not
        // a generic shape mismatch. Prefer the dedicated diagnostic
        // whenever either side carries a tag.
        if let Some((escaped, is_pool)) = self.scope_mismatch_side(a, b) {
            if is_pool { self.pool_escape(escaped, span); } else { self.arena_escape(escaped, span); }
            return;
        }

        self.errors.add_type_error(TypeError::TypeMismatch {
            expected:   self.display_type(a),
            found:      self.display_type(b),
            span,
            because_of: None,
        });
    }

    /// GAP 2 — if either resolved type is `SemaType::ArenaRef` or
    /// `SemaType::PoolRef`, return that side's `TypeId` plus which kind
    /// it was (preferring `b`, conventionally the "actual" / "found"
    /// side in an `expected, found` unify call, which reads better in
    /// the "Value of type `X` ... cannot cross" message). Returns `None`
    /// when neither side carries either tag, i.e. this truly is an
    /// unrelated shape mismatch. Checked pool-first for the same reason
    /// as `check_assign_arena_escape` — a value only ever carries one.
    fn scope_mismatch_side(&mut self, a: TypeId, b: TypeId) -> Option<(TypeId, bool)> {
        let a_is_pool = matches!(self.ctx.types.get(a), SemaType::PoolRef { .. });
        let b_is_pool = matches!(self.ctx.types.get(b), SemaType::PoolRef { .. });
        if b_is_pool { return Some((b, true)); }
        if a_is_pool { return Some((a, true)); }

        let a_is_arena = matches!(self.ctx.types.get(a), SemaType::ArenaRef { .. });
        let b_is_arena = matches!(self.ctx.types.get(b), SemaType::ArenaRef { .. });
        if b_is_arena { Some((b, false)) } else if a_is_arena { Some((a, false)) } else { None }
    }

    /// Returns true if two concrete types are structurally compatible,
    /// recursively unifying their type arguments. Extracts inner TypeIds
    /// (which are Copy) before calling unify to avoid borrow conflicts.
    ///
    /// `span` is where the outer unification happened. Every nested unify
    /// (a function's parameters and return type, a generic's arguments, a
    /// dictionary's key and value, an inner element type) reports at that
    /// span, so a mismatch deep inside `List<int>` against `List<string>`
    /// points at the offending expression instead of at offset 0.
    fn structurally_compatible(&mut self, a: TypeId, b: TypeId, span: Span) -> bool {
        // GENERICS_RULES.md — `fn(..)` type compatibility, e.g. checking
        // a lambda/closure argument's inferred type against a declared
        // `fn(int) int`-shaped param. Multi-pair (each param position,
        // plus the return type), so it can't reuse the single-inner-pair
        // pattern the rest of this function is built around — handled
        // separately, up front. Never exercised before this file's own
        // `call_return_type` started actually unifying call arguments
        // against declared param types at all (previously: computed and
        // discarded) — a plain shape mismatch (param count) is a real
        // difference; a nested unresolved `Var` (an untyped lambda
        // param's type, inferred from how it's *used* inside the lambda
        // body) is exactly what a normal call argument commonly looks
        // like and must bind through here, not hard-fail.
        let fn_pair: Option<(Vec<TypeId>, TypeId, Vec<TypeId>, TypeId)> = {
            match (self.ctx.types.get(a), self.ctx.types.get(b)) {
                (SemaType::Function { params: pa, return_type: ra, .. },
                 SemaType::Function { params: pb, return_type: rb, .. }) =>
                    Some((pa.clone(), *ra, pb.clone(), *rb)),
                _ => None,
            }
        };
        if let Some((pa, ra, pb, rb)) = fn_pair {
            if pa.len() != pb.len() { return false; }
            for (ia, ib) in pa.iter().zip(pb.iter()) {
                self.unify(*ia, *ib, span);
            }
            self.unify(ra, rb, span);
            return true;
        }

        // GENERICS_RULES.md — `Named { def, args }` compatibility. Was
        // previously `def_a == def_b` alone, with `args` completely
        // ignored — meaning two independently-built instantiations of
        // the same generic type (the canonical case: a `let` binding's
        // own type annotation, built fresh via `ast_type_to_sema`,
        // reconciled against its initializer's own separately-built
        // `Named`, e.g. `let x: Option<int> = Option.None`) were treated
        // as compatible without ever binding the initializer's
        // unresolved `Var` args to the annotation's concrete ones. Two
        // non-generic types (`args` empty on both sides) still take the
        // cheap `def_a == def_b` path with nothing further to unify.
        let named_pair: Option<(DefId, Vec<TypeId>, DefId, Vec<TypeId>)> = {
            match (self.ctx.types.get(a), self.ctx.types.get(b)) {
                (SemaType::Named { def: da, args: aa }, SemaType::Named { def: db, args: ab }) =>
                    Some((*da, aa.clone(), *db, ab.clone())),
                _ => None,
            }
        };
        if let Some((da, aa, db, ab)) = named_pair {
            if da != db { return false; }
            if aa.len() != ab.len() { return false; } // same def => should never differ; defensive
            for (ia, ib) in aa.iter().zip(ab.iter()) {
                self.unify(*ia, *ib, span);
            }
            return true;
        }

        // `Dictionary` carries two type arguments, so it cannot go through
        // the single inner-pair extraction below, and it was missing from
        // this function entirely: `let d: Dictionary<string, int> =
        // Dictionary.new()` failed with a TypeMismatch against
        // `Dictionary<?T, ?T>` because the key and value arguments were
        // never unified. Same bug class as the `Set`/`Queue`/`Stack`
        // additions just below.
        let dict_pair: Option<(TypeId, TypeId, TypeId, TypeId)> = {
            match (self.ctx.types.get(a), self.ctx.types.get(b)) {
                (SemaType::Dictionary(ka, va), SemaType::Dictionary(kb, vb)) =>
                    Some((*ka, *va, *kb, *vb)),
                _ => None,
            }
        };
        if let Some((ka, va, kb, vb)) = dict_pair {
            self.unify(ka, kb, span);
            self.unify(va, vb, span);
            return true;
        }

        // Extract inner id pairs first, releasing the immutable borrow on
        // self.ctx.types before we call self.unify (which needs &mut self).
        let inner: Option<(TypeId, TypeId)> = {
            let at = self.ctx.types.get(a);
            let bt = self.ctx.types.get(b);
            match (at, bt) {
                (SemaType::List(ia),     SemaType::List(ib))     => Some((*ia, *ib)),
                // Set/Queue/Stack/Pool/Handle were missing here entirely
                // until now — found while adding InlineList alongside
                // them. Same bug class as the Function/Named fix
                // (GENERICS_RULES.md §2): two separately-constructed
                // instances of the same wrapping type never actually
                // unified their inner element type — e.g. `Set<int>` and
                // `Set<int>` built independently were "compatible" by
                // shape alone, with the element types never reconciled.
                // Only `List` had ever been wired up. Fixed all of them
                // together since the fix is mechanically identical and
                // this exact spot was already being touched for
                // `InlineList` — leaving five known-identical instances
                // of the same bug sitting right next to the fix would've
                // been an odd thing to knowingly walk past.
                (SemaType::Set(ia),        SemaType::Set(ib))        => Some((*ia, *ib)),
                (SemaType::Queue(ia),      SemaType::Queue(ib))      => Some((*ia, *ib)),
                (SemaType::Stack(ia),      SemaType::Stack(ib))      => Some((*ia, *ib)),
                (SemaType::InlineList(ia), SemaType::InlineList(ib)) => Some((*ia, *ib)),
                (SemaType::Linqerizer(ia), SemaType::Linqerizer(ib)) => Some((*ia, *ib)),
                (SemaType::Pool(ia),       SemaType::Pool(ib))       => Some((*ia, *ib)),
                (SemaType::Handle(ia),     SemaType::Handle(ib))     => Some((*ia, *ib)),
                // Unique/Shared/SyncShared (MEMORY_MODEL.md §9,
                // DATASTRUCTURES.md) — each only matches its own kind.
                // No cross-variant arm (e.g. `(Unique, Shared)`) exists on
                // purpose: that's the actual enforcement of "new
                // orthogonal axis" from the design decision this landed
                // under — a `Unique<Node>` and a `Shared<Node>` must stay
                // structurally incompatible even though `Node == Node`,
                // the same way `Reference`'s mutable/shared split above
                // already refuses to unify `&T` with `&mut T`.
                (SemaType::Unique(ia),     SemaType::Unique(ib))     => Some((*ia, *ib)),
                (SemaType::Shared(ia),     SemaType::Shared(ib))     => Some((*ia, *ib)),
                (SemaType::SyncShared(ia), SemaType::SyncShared(ib)) => Some((*ia, *ib)),
                (SemaType::Optional(ia), SemaType::Optional(ib)) => Some((*ia, *ib)),
                (SemaType::Fallible(ia), SemaType::Fallible(ib)) => Some((*ia, *ib)),
                (SemaType::Task(ia),     SemaType::Task(ib))     => Some((*ia, *ib)),
                (SemaType::Slice(ia),    SemaType::Slice(ib))    => Some((*ia, *ib)),
                (SemaType::GcRef(ia),    SemaType::GcRef(ib))    => Some((*ia, *ib)),
                // A `&mut T` and a `&T` are NOT structurally compatible —
                // mutability is a real capability difference. Lifetime
                // labels are deliberately not compared here: the actual
                // outlives/subset fixed point is the borrow checker's
                // job (unbuilt — MEMORY_MODEL.md §9), not ordinary
                // structural unification's. Same checklist item as
                // Set/Queue/Stack/Pool/Handle/InlineList before it —
                // added proactively this time instead of reactively.
                (SemaType::Reference { mutable: ma, inner: ia, .. },
                 SemaType::Reference { mutable: mb, inner: ib, .. }) => {
                    if ma != mb { return false; }
                    Some((*ia, *ib))
                }
                // GAP 2 — two ArenaRefs are only structurally compatible
                // when they carry the *same* ArenaId (MEMORY_MODEL.md §3:
                // arena membership must always be compared by specific
                // id, never just "is/isn't tagged ArenaRef"). A mismatch
                // here is a real escape, not an ordinary shape mismatch —
                // `unify`'s caller reports it via `scope_mismatch_side`
                // rather than falling through to a generic TypeMismatch.
                (SemaType::ArenaRef { arena: aa, inner: ia, .. },
                 SemaType::ArenaRef { arena: ab, inner: ib, .. }) => {
                    if aa != ab { return false; }
                    Some((*ia, *ib))
                }
                // Same rule as ArenaRef immediately above, for the same
                // reason — MEMORY_MODEL.md §11: pool membership compares
                // by specific PoolId, never just "is/isn't tagged
                // PoolRef." A mismatch is a real escape, reported via
                // `scope_mismatch_side` rather than a generic TypeMismatch.
                (SemaType::PoolRef { pool: pa, inner: ia, .. },
                 SemaType::PoolRef { pool: pb, inner: ib, .. }) => {
                    if pa != pb { return false; }
                    Some((*ia, *ib))
                }
                // `null` also compares against a PoolRef/ArenaRef-wrapped
                // Optional — `AcquireHandle`'s result (MEMORY_MODEL.md
                // §11) needs the escape-boundary wrap applied around the
                // *whole* `Optional<Handle<T>>` (so the handle itself
                // can't escape), which leaves the `Optional` one layer
                // inside the ref wrapper instead of at the top level the
                // way List/Queue/Stack/Dictionary's bare-`Elem`-shaped
                // methods leave it. Peel the wrapper first so
                // `pool.acquire(x) == null` still type-checks the same
                // documented way `list.pop() == null` does. Must come
                // before the bare-`Optional` arm below for the same
                // "unconditional case, not a recursive unify" reason
                // that arm's own comment already explains.
                (SemaType::Null, SemaType::PoolRef { inner, .. })
                | (SemaType::PoolRef { inner, .. }, SemaType::Null) => {
                    let resolved = self.apply(*inner);
                    return matches!(self.ctx.types.get(resolved), SemaType::Optional(_));
                }
                (SemaType::Null, SemaType::ArenaRef { inner, .. })
                | (SemaType::ArenaRef { inner, .. }, SemaType::Null) => {
                    let resolved = self.apply(*inner);
                    return matches!(self.ctx.types.get(resolved), SemaType::Optional(_));
                }
                // `null` is a valid value of any `Optional<T>` — needed
                // for `x.pop() == null` (§8's Optional(elem) shape) to
                // type-check as the documented way to test for "empty."
                (SemaType::Null, SemaType::Optional(_))
                | (SemaType::Optional(_), SemaType::Null) => return true,
                // `Optional<T>` also compares directly against a bare
                // `T`, not just `Optional<T>`/`Null` — matches how most
                // languages treat nullable equality (`maybeInt == 5`
                // doesn't require wrapping the `5`). Must come after the
                // `Null` arm above so `x.pop() == null` hits that
                // specific, unconditional case rather than recursing
                // into `unify(elem, Null)`, which nothing makes true.
                (SemaType::Optional(ia), _) => Some((*ia, b)),
                (_, SemaType::Optional(ib)) => Some((a, *ib)),
                _ => None,
            }
        }; // immutable borrow released here
        if let Some((ia, ib)) = inner {
            self.unify(ia, ib, span);
            true
        } else {
            false
        }
    }

    // ── Display helper ────────────────────────────────────────────

    fn display_type(&self, id: TypeId) -> String {
        if id == TypeId::ERROR { return "<error>".into(); }
        if self.int_lit_var_of(self.apply(id)).is_some() { return "{integer}".into(); }
        self.ctx.types.get(id).display(&self.ctx.types, &self.ctx.symbols)
    }
    }
