# Traits: Design Options

> **Status: decisions made 2026-10-03; slice S1a built (section 0).**
> Sections 1 to 5 are the options as presented, kept as the record of what
> was weighed. Written for the dedicated traits design session that `docs/PARKED_IDEAS.md`
> ("Traits / interface system") called for. That section holds the
> reference-language survey and the evaluation of an outside synthesis; this
> document does not repeat them. It records what the compiler does with a
> trait today (read from source and confirmed by running programs), the
> constraints that shape the answer, one decision per section with options
> and a recommendation, and a delivery order. Once the decisions are made
> they move to "Decided, not yet built" in `PARKED_IDEAS.md`, one delivery
> at a time, each with its own fixtures.

---

## 0. Decisions and progress

### Decisions (2026-10-03)

| Decision | Chosen |
|---|---|
| **D1** kind of trait | **A**, nominal traits with explicit `impl Trait for Type`. |
| **D2** dispatch | **Both** static and dynamic. Static first (S1), `dyn Trait` in the last slice (S6). Whether `dyn` is `HIGH` only (B) or every tier (C) is settled when S6 starts. |
| **D3** coherence | The recommended v1 answers: one impl per trait and type, overlap is an error, an inherent method beats a trait method, two traits supplying one name is an error at an unqualified call and is resolved with `Trait.method(value)`. The orphan rule, blanket impls and C#-style explicit implementation are **deferred** until there is more context. |
| **D4** trait contents | **All four levels**: methods and defaults, generic traits and supertraits, associated types, required fields and associated constants. Built in stages (S1, S3, and a later slice for the last level, which needs its field-layout interaction with ECS and arenas checked first). |
| **D5** built-in protocols | The recommendation: lift the six derives into prelude traits (S2); `Display`/`Debug`, `Iterable`, operators one at a time, each its own decision (S5). |
| **D6** bounds | The recommendation: enforce at call sites and through generic bodies, and make a method call on an unbounded type parameter an error (S1b); `where` clauses and bounds with arguments later. |
| **D7** tiers | A **hybrid** of options a and b: a trait can set a default tier for all its methods, each method can carry its own tier, an implementer must match the tier of the method it implements, and a specific method can override to change the tier. Flagged as complex and to be handled flawlessly, so it gets its own specification before any code (S4, below). |
| **D8** keywords | The recommendation: `extend` inherent only, `impl Trait for Type` the trait form, plain `impl Type { }` still accepted. |

### Slice S1 is split in two

| Slice | Status | Contents |
|---|---|---|
| **S1a** | **Built** | Trait impls registered in sema and interpreter dispatch; conformance checks (missing method, method not in the trait, signature mismatch with `Self`); default methods inherited or overridden; `Self` in signatures and default bodies; overlap; inherent-first; ambiguity and the qualified call `Trait.method(value)`; calls made through a trait run the trait's method; every trait feature not built yet reported as `TYPE-129` instead of ignored. |
| **S1b** | **Built** | Bounds: declared bounds validated, bound obligations checked wherever a bounded parameter is instantiated, method calls on a type parameter resolved through its bounds, a method call on an unbounded type parameter an error (`TYPE-130`). |
| **S2a, part 1** | **Built** | The prelude traits `PartialEq`, `Eq`, `PartialOrd`, `Ord` and `Clone` with real signatures, the `Ordering` enum, what built-in and derived types satisfy, supertrait bounds, the methods callable through a bound and directly on a value, operator checks on type parameters (`TYPE-131`), hand-written impls reported (`TYPE-129`). See "What S2a part 1 settled" below. |
| **S2a, part 2** | **Built** | `Hash` and the `Hasher` struct, `Hash` satisfaction, and `Hash` (which implies `Eq`) required of `Dictionary` keys. See "What S2a part 2 settled" below. |
| **S2b** | **Built** | Hand-written impls of the six prelude traits: checked like any trait impl, needing their supertraits (`TYPE-132`), and called by `==`, `!=`, the ordering operators, `contains` on every collection, dictionary lookup, assignment and indexing, `order_by`, `group_by`, and by derived comparison, `Hash` and `Clone` inside other values. See "What S2b settled" below. |
| **S3a** | **Built** | Supertraits: `trait B: A + C`. An impl needs the impls beneath it (`TYPE-132`, now for every trait), a bound implies them, a default body sees them, a cycle is an error (`TYPE-133`), and the prelude declares its own. See "What S3a settled" below. |
| **S3b** | **Built** | Generic traits (`trait Convert<T>`, `impl Convert<int> for X`), bounds with arguments (`T: Convert<int>`, `T: Convert<U>`) and generic supertraits (`trait Wide<T>: Convert<T>`), with one impl of a trait per type. See "What S3b settled" below. |
| S3c to S6 | Planned | As in section 4. |

### What S1a settled that the options did not

- **A call made through a trait runs the trait's method.** Inside a default
  method `self.area()` is resolved through the trait (inherent methods are not
  visible through a bound), so it must run the trait's `area` even when the
  concrete type also has an inherent `area`. Sema records each such call
  (`SemaContext::trait_call_sites`) and the interpreter dispatches those
  through its per-trait table, the same way it already takes
  `int_literal_types`. S1b reuses this for every call through a declared bound.
- **`Self`** is the implementing type inside an `impl`, `extend` or struct,
  and an abstract parameter inside a trait. The abstract `Self` is the
  reserved `Param` index equal to the trait's generic arity, so one
  `substitute` call replaces the trait's own arguments and `Self` together
  once generic traits exist.
- **Not yet checkable:** an impl for a built-in type, a generic trait and an
  associated type are each reported as `TYPE-129` (`UnsupportedTraitFeature`),
  so none is silently ignored. Impls for built-in types arrive with S2, generic
  traits with S3.

### What S1b settled that the options did not

- **Bound names.** A bound must name a trait declared in the program
  (`TYPE-122` otherwise, once per declaration, at the parameter). The six
  derive names (`PartialEq`, `Eq`, `Hash`, `Ord`, `PartialOrd`, `Clone`) are
  not declared traits until S2, so a bound written with one is `TYPE-129`
  rather than being accepted and ignored. A user trait that happens to use
  one of those names is a real bound. (Since S2a all six are prelude traits
  and ordinary bounds.) A bound on a type alias parameter or on
  a method's own generic parameter is `TYPE-129` too, because neither scope
  exists in sema yet.
- **Where a bound is enforced.** Each place a bounded parameter is
  instantiated records an obligation that the argument type implements the
  trait: a call to a generic function (including a call through a variable
  that holds it), a struct literal, an enum variant construction, an
  associated function called on a generic struct, and a type annotation that
  names a bounded struct or enum with arguments. A call is reported at the
  first argument whose declared type is the bounded parameter, the others at
  the expression or annotation.
- **When it is decided.** Obligations are settled at the end of the body,
  after integer literal types are settled (so `total(5)` reports `int`, not
  `{integer}`), and reported in source order. An argument that is still an
  unresolved inference variable is not an error. Obligations raised by
  signatures wait until every impl is registered.
- **Method calls on a type parameter.** The receiver's type parameter is
  looked up in the bounds in force for the body: a generic function, a method
  of a generic struct, and an `extend` or `impl` block on one all see the
  declaration's bounds. With bounds, the method must come from one of them
  (`TYPE-104` when none supplies it, `TYPE-127` when two do). With none, the
  call is `TYPE-130`. Calls resolved through a bound are recorded in
  `trait_call_sites`, so the trait's method runs even when the concrete type
  has an inherent method of the same name.
- **Reference and ownership wrappers are ignored.** A value reached through
  `ArenaRef`, `GcRef`, `OwnedRef`, `PoolRef`, `Unique`, `Shared`, `SyncShared`
  or a borrow satisfies the same bounds as the bare value. This can only miss
  a violation, never reject a program that is fine.
- **Still open:** `where` clauses and bounds with arguments (later); bounds
  naming `Hash` and impls for built-in types need S2.

### What S2 settled (decided 2026-10-07)

Decisions made for S2, in addition to D5 B (lift the six derives into prelude
traits):

- **Real methods, with dispatch to hand-written impls.** The six traits carry
  methods, and `==`, `<`, hashing and `clone` call a hand-written impl when one
  exists. This is the larger runtime change, chosen over marker traits.
- **Floats.** `float` and `double` implement `PartialEq`, `PartialOrd` and
  `Clone` only, not `Eq`, `Hash` or `Ord`, because of NaN.
- **Enforcement on existing code.** `Dictionary` keys must implement `Hash` and
  `Eq`, and `==`, `!=` and the ordering operators on a value of type-parameter
  type require `PartialEq` or `PartialOrd` in its bounds.
- **Method surface.**

| Trait | Methods | Notes |
|---|---|---|
| `PartialEq` | `eq(self, other: Self) bool` | Default `ne`. |
| `Eq` | none | Supertrait `PartialEq`. |
| `PartialOrd` | `partial_cmp(self, other: Self) Ordering?` | Defaults `lt`, `le`, `gt`, `ge`. Supertrait `PartialEq`. |
| `Ord` | `cmp(self, other: Self) Ordering` | Supertraits `PartialOrd` and `Eq`. |
| `Hash` | `hash(self, state: Hasher)` | Rust style: the hasher is a parameter. |
| `Clone` | `clone(self) Self` | |

  `Ordering` is a prelude enum `{ Less, Equal, Greater }`. `Hasher` is a
  built-in type. Its surface is `Hasher.new()` and `state.finish() u64`, with
  each value's `hash` writing into the state (confirmed 2026-10-08, built in
  S2a part 2).
- **Two deliveries.** S2a was the static side and S2b the runtime dispatch.
  Between them a hand-written `impl PartialEq for X` (and the other five) was
  `TYPE-129`, so an impl that `==` would ignore was never accepted silently;
  S2b lifted that restriction when the dispatch landed.
- **Defaults taken without objection.** `@derive(X)` registers the impl and the
  derive prerequisite chain becomes the supertraits; lists, tuples and
  optionals satisfy a trait when their elements do, by a built-in rule rather
  than impl blocks; enums keep automatic `PartialEq`, `Eq` and `Hash` and gain
  no `Ord` or `Clone` in S2; a user trait named like a prelude trait shadows it;
  `==` on a concrete struct without `PartialEq` stays reference identity.

What reading the code established before this was decided:

- `Value::equals` and `Value::partial_cmp` take no interpreter and are called
  from more than a dozen places (the binary operators, list, queue, stack and
  inline-list `contains`, the dictionary methods, indexing, the Linqerizer
  grouping and ordering). S2b gave each of them a route back into the
  interpreter (`interpreter/eval/user_ops.rs`).
- `Dict` is `Vec<(Value, Value)>` searched by `equals`; hashing has no consumer
  yet. A struct key without `PartialEq` is found by reference identity, so a
  lookup with an equal but distinct key returns `null`.
- Sema's maps are keyed by `Span` (four `usize` fields, `Hash` and `Eq`), so
  prelude declarations cannot be parsed from a separate text at ordinary spans.
  The two ways to bring the prelude traits in are a prelude written in Ubel whose
  token spans are shifted into a reserved range, and programmatic registration
  with natively implemented methods; diagnostics are rendered by indexing the
  source's lines, so a label that points into the prelude would need handling in
  the renderer. The mechanism was chosen in S2a part 1, see below.

### What S2a part 1 settled

- **The prelude is Ubel source, injected by `parse()`.**
  `crates/rd_parser/src/prelude.rs` holds the declarations (`Ordering`,
  `PartialEq`, `Eq`, `PartialOrd`, `Ord`, `Clone`). They are lexed once with
  every token span shifted into the range `Span::is_prelude` reserves (it
  starts at 2^31 so that it fits the 32-bit `usize` of `wasm32`, and no user
  node can collide with one in sema's `Span`-keyed tables), parsed with each
  program and placed in front of the program's own items. This was chosen over programmatic registration because the prelude
  traits then use the machinery a user trait does: signatures, default
  methods (`ne`, `lt`, `le`, `gt` and `ge` are written in Ubel), bounds and
  `Self`.
- **Shadowing.** A program that declares one of these names keeps its own, and
  the prelude items that depend on it are dropped with it: `Eq` and
  `PartialOrd` depend on `PartialEq`, `PartialOrd` and `Ord` on `Ordering`,
  `Ord` on `PartialOrd` and `Eq`.
- **Supertraits.** A bound `T: Ord` also puts `PartialOrd`, `Eq` and
  `PartialEq` in force inside the body. Declared bounds stay as written, so a
  call site raises one obligation per declared bound. Until S3a this was a table
  in sema, because `trait B: A` was not parsed; the prelude now declares them
  like any trait (see "What S3a settled").
- **What satisfies a prelude trait** follows what the runtime does with the
  value:

| Type | `PartialEq` | `Eq` | `PartialOrd` | `Ord` | `Clone` | `Hash` |
|---|---|---|---|---|---|---|
| integers (every width), `string` | yes | yes | yes | yes | yes | yes |
| `float`, `double`, `f32`, `f64` | yes | no | yes | no | yes | no |
| `bool`, `char` | yes | yes | no | no | yes | yes |
| tuple, optional | when elements are | when elements are | no | no | when elements are | when elements are |
| struct | if derived | if derived | if derived | if derived | if derived | if derived |
| enum | yes | yes | no | no | no | yes |
| every other built-in type | no | no | no | no | no | no |

  Ordering is limited to what `<` accepts (it is not defined on `bool` or
  `char`). `==` on a collection is reference identity, so a collection is not
  `PartialEq`. A value reached through an ownership or reference wrapper has
  the traits of the value.
- **Methods.** `eq`, `ne`, `partial_cmp`, `lt`, `le`, `gt`, `ge`, `cmp` and
  `clone` can be called through a bound and directly on a value whose type has
  the trait, and `Ord.cmp(a, b)` works in the qualified form. A method on the
  type itself wins over the prelude method. The call is recorded in
  `trait_call_sites`; the interpreter runs a built-in or derived type's
  prelude method natively (`native_prelude_method`), through the same `==` and
  `<` the operators use, so every numeric width, string and derived struct
  behaves as it does with the operators.
- **Operators on a type parameter.** `==` and `!=` need `PartialEq`, and the
  ordering operators need `PartialOrd`, in the parameter's bounds (`Eq` and
  `Ord` imply them). Without it the operator is `TYPE-131`
  (`OperatorNeedsBound`), at the expression. Operators on a concrete type are
  unchanged: `==` on a struct without `PartialEq` stays reference identity.
- **Hand-written impls** of the five traits were `TYPE-129` in this part; S2b
  accepts them.
- **Not in part 1:** `Hash`, `Hasher`, the `Dictionary` key requirement
  (part 2, below); dispatch to hand-written impls (S2b).
- **Limits recorded:** an enum is `PartialEq` and `Eq` whatever its payload
  types are (its comparison is structural at run time); a struct is the
  traits it derives, nothing else.

### What S2a part 2 settled

- **`Hasher` is an ordinary struct in the prelude**, with one field
  (`state: u64`), an associated `new()` and a `finish()`:
  `let h = Hasher.new()`, `x.hash(h)`, `h.finish()`. `Hash` is a prelude trait
  with `hash(self, state: Hasher) void`. It depends on `Hasher`, `Eq` and
  `PartialEq` for shadowing (a program that declares `Hasher` loses `Hash`).
- **`hash` is native.** It folds `Value::compute_hash` of the receiver into
  `state`, rotating the old state first, so hashing `a` then `b` differs from
  `b` then `a`, and the same values in the same order always give the same
  `finish()`. Raw hash values are not part of the language contract: they come
  from the standard library's `DefaultHasher` and can change with the
  toolchain, so tests and fixtures compare hashes and never print them.
- **What is `Hash`:** integers of every width, `string`, `bool` and `char`; a
  tuple or optional when its elements are; a struct that derives `Hash`; an
  enum. Not `float`, `double`, `f32` or `f64` (NaN), and no other built-in
  type. `Hash` implies `Eq` and `PartialEq` inside a body, matching the derive
  prerequisite rule (`@derive(Hash)` needs `Eq`, `TYPE-117`).
- **`Dictionary` keys must be `Hash`** (which implies `Eq`). One obligation,
  `Hash`, because every `Hash` type is also `Eq`; the diagnostic is the usual
  `TYPE-126`. It is raised where a dictionary type is written or created:
  a `Dictionary<K, V>` annotation (in a signature, a field, a `let` or nested
  in another type), `Dictionary.new()`, and the first key handed to
  `set`, `get` or `contains_key` of a dictionary whose key type is not written
  anywhere. A key type that is written is checked where it is written, not
  again at each call. An unannotated dictionary that never receives a key is
  not an error.
- **One mistake, one diagnostic.** `let d: Dictionary<float, int> =
  Dictionary.new()` names the key twice on one line; a key mistake is reported
  once per line and key type. The same mistake on two lines is two diagnostics.
- **Aliases.** `type Pairs<K, V> = Dictionary<K, V>` cannot declare `K: Hash`
  (bounds on alias parameters are not built), so nothing is checked where an
  alias is declared; every use is checked after expansion, so `Pairs<float, int>`
  is `TYPE-126` at the use.
- **Generic keys.** `fn f<K>(d: Dictionary<K, int>)` is `TYPE-126` for the
  unbounded `K`; `K: Hash` is accepted.
- **Hand-written `impl Hash`** was `TYPE-129` in this part, with the other five;
  S2b accepts it.
- **Not covered:** the runtime `Dict` is still a `Vec` of pairs searched by
  `equals`, so hashing has no consumer yet and the requirement is a static
  contract; `Set<T>` elements and `Linqerizer.group_by` keys are not checked.

### What S2b settled

- **Hand-written impls of the six prelude traits are accepted** and checked like
  any trait impl: `TYPE-122` to `TYPE-125` cover the trait name, a missing
  method, an unknown method and a signature mismatch. The methods with defaults
  (`ne`, `lt`, `le`, `gt`, `ge`) are inherited unless the impl overrides them.
- **`@derive(X)` together with `impl X for T` is `TYPE-128`**, reported at the
  impl: the derive and the impl are two sources of the same impl.
- **An impl needs its supertraits (`TYPE-132`, `MissingSupertraitImpl`).**
  `impl Ord` needs `PartialOrd` and `Eq` (so `PartialEq`), `impl PartialOrd`
  and `impl Eq` need `PartialEq`, `impl Hash` needs `Eq`. A derive or a
  hand-written impl satisfies a supertrait. One diagnostic per impl, at the
  impl, naming the first missing supertrait in that chain, because the rest
  follow from it.
- **Impls for built-in types stay `TYPE-129`** ("a type that is not a struct or
  enum"), as do impls for generic types and generic traits, until S3.
- **What a type satisfies now counts hand-written impls.** A struct or enum
  satisfies a prelude trait by a derive, by the automatic rule (an enum is
  `PartialEq`, `Eq` and `Hash`) or by an impl. An enum may replace its automatic
  `PartialEq`, `Eq` or `Hash` with a hand-written one and may order itself with
  `impl PartialOrd`. The ordering operators accept a type with `impl PartialOrd`
  or `impl Ord`. Before impls are registered a named type's status is undecided
  rather than false, so a signature that names a type whose impl comes later in
  the file waits for registration instead of failing.
- **Runtime dispatch.** `==` calls the impl's `eq`. `!=` calls the impl's `ne`
  (its override, or the prelude default). `<`, `<=`, `>` and `>=` call the
  impl's `lt`, `le`, `gt` and `ge`, so an override is honored. The same rule is
  used by `contains` on a list, queue, stack and inline list, by the dictionary
  methods `get`, `set` and `contains_key` and by indexing a dictionary (read and
  assign), by the Linqerizer's `order_by` and `group_by`, and by `x.eq(y)`,
  `x.cmp(y)` and the other prelude methods called on a derived struct.
- **The rule applies inside values.** A derived struct compares field by field,
  a tuple element by element, an enum payload by payload and a `Unique` through
  its content, each part through its own impl when it has one. `hash` and
  `clone` follow the same rule: a derived `Hash` folds a field in through the
  field's `hash`, so values that are equal hash alike, and a derived `Clone`
  calls the `clone` of a field, element or payload, in lists, dictionaries,
  queues, stacks, tuples, enums and `Unique`. `Shared` still aliases.
- **One module.** `interpreter/eval/user_ops.rs` holds `values_equal`,
  `values_cmp`, `user_comparison`, `contains_value`, `dict_position`,
  `dict_op_user`, `values_clone` and `hash_value`. `Value::equals`,
  `Value::partial_cmp`, `Value::deep_clone` and `Value::compute_hash` remain the
  structural fallbacks and take no interpreter. Only a struct, enum, tuple or
  `Unique` operand takes the slow path.
- **Unordered results.** `a.lt(b)` is `false` when `partial_cmp` gives `null`.
  The operator form `a < b` on a derived struct whose field has no order panics
  with "comparison between incomparable values", as the operators already did
  for incomparable values before the traits existed. The two forms disagree; see
  `docs/PARKED_IDEAS.md`.

### What S3a settled

- **Syntax.** `trait B: A + C { .. }`. The supertraits follow the name and any
  generic parameters and are written like a bound on a type parameter
  (`T: A + C`). Each was a plain name in S3a, so a supertrait with arguments
  (`trait B: A<int>`) was a parse error until S3b. The parser records each name
  with its own span, so a diagnostic about a supertrait points at the name.
- **An impl needs the impls beneath it (`TYPE-132`).** The rule built for the
  prelude in S2b now covers every trait: `impl B for T` needs an impl of each
  trait `B` builds on, directly or through others. One diagnostic per impl, at
  the impl, naming the first missing trait in the chain. The chain is the trait's
  supertraits in the order written, then theirs level by level, so an `impl Ord`
  with nothing beneath it names `PartialOrd`. A link missing further up is
  reported at each impl that depends on it. The suggestion is `@derive(X)` or an
  impl when the missing trait is one that can be derived, and an impl otherwise.
- **A bound implies its supertraits, one way.** `T: B` puts `A` in force inside
  the body, so `x.a_method()` resolves, and `T: B` satisfies a `T: A`
  requirement at a call. The reverse does not hold: a `T: A` does not satisfy
  `T: B` (`TYPE-126`). Declared bounds stay as written. A diamond is one trait to
  the body: `Base` reached through `Left` and `Right` is one entry, so a method
  of `Base` is not ambiguous.
- **A default body sees its supertraits.** Inside a default method of `B`, `self`
  is bounded by `B` and by everything `B` builds on. `self.a_method()` resolves,
  and for a prelude supertrait the operators work (`trait Scored: PartialOrd`
  allows `self > other` in a default).
- **Names.** A supertrait that is unknown, or names something that is not a
  trait, is `TYPE-122`, reported at the name. A repeated name is ignored.
  Declaration order does not matter: a trait may build on one declared later.
- **A trait cannot build on itself (`TYPE-133`, `SupertraitCycle`)**, directly or
  through others. One diagnostic per cycle, at the supertrait name that closes
  it, with the cycle as written (`A -> B -> A`). A trait that only leads into a
  cycle is not reported, and a diamond is not a cycle.
- **The prelude declares its own supertraits** in its source: `trait Eq:
  PartialEq`, `trait PartialOrd: PartialEq`, `trait Ord: PartialOrd + Eq`,
  `trait Hash: Eq`. Sema's table of prelude supertraits is gone; only the list of
  prelude names remains. Shadowing reads the declarations: a prelude item depends
  on its supertraits plus the types its signatures mention (`Ordering` for
  `PartialOrd` and `Ord`, `Hasher` for `Hash`), and a program that declares a
  name loses everything that depends on it, as before.
- **Not changed.** The `@derive` prerequisite check (`DeriveRequiresOther`) still
  works from the derive list, not from the declared supertraits; the two agree
  for the six prelude traits. Generic traits, associated types, impls for
  generic types and for built-in types, and the two bound limits are still
  `TYPE-129`.
- **Runtime.** No change. A call through a bound resolves to the supertrait's
  method and runs the implementing type's impl, and a default of `B` that calls
  `self.a()` runs whatever the type provides for `A`.

### What S3b settled

- **Syntax.** `trait Convert<T> { .. }`, `impl Convert<int> for Celsius { .. }`,
  bounds with arguments (`T: Convert<int>`, `T: Convert<U>`) and supertraits with
  arguments (`trait Wide<T>: Convert<T>`, `trait Narrow: Convert<int>`). One shape,
  `TraitBound { name, args, span }`, serves a parameter's bound, a supertrait and
  the impl header (`ImplBlock.trait_args`). A bound's arguments that end a
  parameter list close with one `>>` token (`T: Convert<int>>`), which the
  parameter-list parser now reads as two closes.
- **A type has one impl of a trait.** The arguments are a property of the pair
  (trait, type). A second impl of the same trait for a type is `TYPE-128` whatever
  its arguments. This was chosen over several impls because generics are erased
  at run time: the interpreter dispatches on the value's type name and a trait
  name, so inside generic code a bound such as `T: Convert<U>` could not pick
  between two impls of one type. Allowing several is a relaxation for later (it
  needs the arguments at run time, or a restriction of bounds to concrete
  arguments, and inference that picks the impl from the expected type). Nothing
  built here prevents it. The interpreter needed no change.
- **What the arguments mean for an impl.** The impl's method signatures are
  compared with the trait's with the trait's parameters replaced by the impl's
  arguments (`fn convert(self) int` for `Convert<int>`). The argument count is
  checked (`TYPE-108`), a bound on the trait's own parameter (`trait Holder<T:
  Eq>`) is checked at the impl (`TYPE-126`), and a default method of a generic
  trait is checked once in the trait's scope, where `Self` implements the trait
  applied to its own parameters.
- **What a bound's arguments mean.** Inside a body, `T: Convert<int>` makes
  `x.convert()` return `int`, and a method that takes the trait's parameter takes
  `int`. At a call, the bound is met when the argument's type has an impl of the
  trait and the impl's arguments are the bound's. An argument that is still an
  inference variable (`fn widen<T: Convert<U>, U>`) is decided by the impl as soon
  as the type is known, so `U` is `int` for a `Celsius`, and using the result as a
  `string` is an ordinary type mismatch. A type parameter meets a bound only when
  declared with the same arguments. The message names the arguments (the trait
  `Convert<string>` is not implemented for `Celsius`).
- **Generic supertraits carry their arguments.** A supertrait's arguments are
  written in the sub-trait's scope (its parameters, and `Self`), and a bound on the
  sub-trait gives the supertrait with the arguments worked out: `T: Wide<int>` also
  gives `Convert<int>`. `impl Wide<int> for X` needs `impl Convert<int> for X`; an
  impl with other arguments does not count, and `TYPE-132` names the supertrait
  with its arguments. A cycle is `TYPE-133` whatever the arguments.
- **Conflicting bounds (`TYPE-134`).** Two bounds on one parameter that apply the
  same trait to different arguments cannot both hold, since a type has one impl,
  so the second is reported and the first stays in force. The same trait with the
  same arguments twice is one bound.
- **Arguments wait for the aliases.** A bound's or supertrait's arguments are
  types, so they are converted after the type aliases are expanded
  (`fill_generic_bound_args`); the names are validated earlier. Scopes built before
  that pass convert them again silently, so an error is reported once, at the
  declaration.
- **Not changed.** The prelude traits take no arguments (`Eq<int>` is `TYPE-108`).
  Associated types, impls for generic types and for built-in types, and the two
  bound limits are still `TYPE-129`.

### D7: what has to be specified before S4

Two facts found while building S1a bear on the tier design.

1. **A method call on a receiver is not tier-checked at all today.** The
   cross-tier call rule runs only for calls whose callee resolves to a
   definition (a plain function name). `recv.method()` has no such
   resolution, so a `MID` function can call a `HIGH` method on a value with
   no error. Putting a tier on trait methods is meaningless until method
   calls are checked, so S4 starts there.
2. **What "override to change the tier" lets an implementer do needs an exact
   rule.** Under the existing rule a callee must be at the caller's tier or
   lower. A call through a bound is checked against the tier the TRAIT
   declares, because the impl is not known. An impl method at a tier **at or
   below** the declared one can never make such a call unsound. An impl
   method **above** the declared tier can, unless every instantiation is
   checked separately. The S4 specification chooses between: exact match only;
   match or lower (sound with the existing rule); or arbitrary override with
   per-instantiation checking. It is written and agreed before S4 is built.

---

## 1. Where things stand (at the start of the design session)

Verified by reading the source and by running small programs, not taken from
the older notes.

| Stage | What happens to a trait today |
|---|---|
| Parser | Parses `trait` (method signatures, default methods, associated type *names*), `impl Trait for Type`, and `T: A + B` bounds. Does **not** parse supertraits (`trait B: A`), `where` clauses, bounds with arguments (`T: Into<U>`), a tier on a signature, or associated type bindings in an impl. The generic arguments of a trait path in an impl (`impl From<int> for X`) are parsed and then discarded (`let _ = self.try_parse_generic_args()`). |
| Name resolution | Declares the trait (`DefKind::Trait`) and resolves default-method bodies. `AssociatedType` is a `TODO`. |
| Sema | Collects trait method signatures and infers default-method bodies. Trait `impl`s are **excluded from dispatch** (`register_extend_impl_methods` skips any impl with a `trait_path`), so `impl Shape for Sq { fn area .. }` followed by `q.area()` is `NoSuchMethod`: **a trait impl cannot be used at all.** Bounds are stored and never checked. A method call on an unbounded type parameter is accepted as `Unknown`. |
| Interpreter | Dynamically typed, generics erased. Dispatch is `method_table[type_name][method]`; trait impls are skipped there too. |
| Derive | The one trait-like feature that works: six hard-coded names (`PartialEq`, `Eq`, `Hash`, `Ord`, `PartialOrd`, `Clone`), structs only, with prerequisite chains (`Eq` needs `PartialEq`, `Ord` needs `PartialOrd` and `Eq`, `Hash` needs `Eq`). They set flags on `Value::Struct` that change `==`, ordering, hashing and cloning at runtime. |

### Probes

| Program | Result |
|---|---|
| `impl Shape for Sq { fn area(self) .. }` then `q.area()` | sema `NoSuchMethod` |
| `fn total<T>(x: T) int { return x.area() }`, called with a struct that has `area` and with `5` | sema accepts both; the `5` call panics at runtime (`no method 'area' on int`) |
| `for x in b` where `b` is a user struct | sema accepts; runtime panic (`cannot iterate over value of type 'struct'`) |
| `a + b` on two user structs | sema accepts; runtime panic (`arithmetic not supported on struct`) |
| `a == b` on two equal structs with no derive | `false` (identity, not structure) |
| `println($"{p}")` on a struct declared `x, y` | prints `P {x: 1, y: 2}` in some runs and `P {y: 2, x: 1}` in others (6 of 8 runs vs 2 of 8): field order comes from a `HashMap`, not from the declaration |
| `trait B: A { .. }` | parse error |

Three of these are the same hole the project has closed several times: sema
accepts, the interpreter panics. A trait system is the natural home for the
protocols behind them (iteration, operators, formatting, equality).

---

## 2. Constraints

- **C1. Monomorphization is the stated direction.** `MEMORY_MODEL.md` assumes
  monomorphized types and an eventual LLVM backend; the tree-walking
  interpreter is a stand-in. Whatever is chosen must lower to static dispatch
  by default.
- **C2. The interpreter erases generics.** There are no runtime type
  parameters. Every option below must be implementable as sema checks plus a
  method table.
- **C3. Tiers.** The cross-tier call rule is: a callee must be at the caller's
  tier or lower. `HIGH` may call `HIGH`, `MID` and `LOW`; `MID` may call `MID`
  and `LOW`; `LOW` may call only `LOW`. `MethodSig` has no tier today, and the
  tier lives in the reference wrapper (`GcRef`, `ArenaRef`, `OwnedRef`), not in
  the type name.
- **C4. No module system.** `summon` is unscheduled, so an orphan rule cannot
  be written or tested yet.
- **C5. Taste.** The project avoids heavy machinery until a concrete need
  proves it worth the weight (LALRPOP, SMT solvers). "Should this be a
  pattern instead of a feature" is a legitimate first question.

---

## 3. Decisions

Each decision lists its options, what each costs, and a recommendation. The
recommendations are consistent with each other; changing one may change
another, noted where it does.

### D1. Is there a `trait`, and what kind?

| Option | Meaning | Cost |
|---|---|---|
| **A. Nominal traits** | A type implements a trait only by declaring `impl Trait for Type` (Rust, C#). | Matches the grammar, the AST and `T: Bound` that already exist. Needs the dispatch and bound checking that do not. |
| **B. Structural interfaces** | A type satisfies an interface by having the right methods; no `impl .. for` (Go). | Makes the parsed `impl .. for` dead syntax. A method name carries no tier and no intent, which sits badly with tier rules and with the derive prerequisite chains. |
| **C. No keyword** | Duck typing plus a hand-rolled vtable: a struct of function-typed fields (Zig, Odin). | Cheapest. It is what the interpreter already does, minus any checking, and the cost shows: the unbounded-`T` probe above compiles and then panics at runtime. Function-typed fields are callable now, so the vtable pattern works today. |

**Recommended: A.** The six derives already behave like named capability sets
with supertraits, and the parser already commits to nominal syntax. Option C
stays available as the *pattern* for dynamic dispatch (D2) even with A chosen.

### D2. Static dispatch, dynamic, or both?

| Option | Meaning |
|---|---|
| **A. Static only** | Bounds are checked at declaration; calls resolve per instantiation. No `dyn Trait`. |
| **B. Static plus `dyn` in `HIGH` only** | `dyn Trait` as a type behind a GC reference, giving heterogeneous collections such as `List<dyn Shape>`. |
| **C. Static plus `dyn` in every tier** | `dyn` behind the tier wrappers (`GcRef<dyn T>`, `ArenaRef<dyn T>`, `OwnedRef<dyn T>`). |

Facts that bear on it: a vtable needs a pointer wrapper; the architecture of
`FfiSpan` is still listed as open in `DATASTRUCTURES.md`; and `dyn` adds a
type form, an object-safety question (methods returning `Self`, generic
methods) and a per-tier representation. None of that is needed for checked
bounds. The interpreter would run all three identically, so the choice is
about what sema checks and what the future backend must generate.

**Recommended: A first, B as a later slice, C deferred.** Heterogeneous
collections have two workable answers in the meantime: an `enum` of the
variants, or the function-field vtable pattern (D1 option C).

### D3. Coherence: which impl applies, and what is allowed?

Questions and the proposed v1 answer to each:

| Question | Recommended v1 answer |
|---|---|
| Two impls of one trait for one type | Error (`OverlappingImpl`). No specialization. |
| Impl for a built-in type (`impl Shape for int`) | Allowed. Needed so that `T: Ord` can be satisfied by `int` and `string` at all (D5). |
| Orphan rule | Deferred until modules exist. The intended rule, to avoid painting into a corner: an impl is allowed only in the package that declares the trait or the type. |
| Blanket impls (`impl<T: A> B for T`) | Not in v1. Revisit once bounds and supertraits are solid. |
| Inherent method and trait method with the same name | The inherent method wins. |
| Two traits supplying the same method name to one type | Error at an unqualified call (`AmbiguousTraitMethod`); resolved with a qualified call, `Shape.area(q)`. C#-style explicit implementation (`fn Renderable.draw(self)`) is a proven mechanic and is deferred, not rejected. |

### D4. What can a trait contain?

The AST already has method signatures, default methods and associated type
names. Options, cumulative:

| Level | Adds |
|---|---|
| **i** | Methods and default methods, with `Self` (already parses in signatures; nothing resolves it). |
| **ii** | Generic traits (`trait Convert<T>`) and supertraits (`trait Ord: Eq`). Needs the impl's trait path to keep its arguments, and the parser to read `: Bound` after a trait name. |
| **iii** | Associated types (`type Item`). Needs bounds on the declaration and bindings in the impl. |
| **iv** | Required fields (Scala style) and associated constants. |

**Recommended: i in the first slice, ii next, and prefer generic traits over
associated types for iteration (`Iterable<T>`)**, since the language already
has generics with inference and it avoids a second mechanism. Associated types
are justified only if one-impl-per-type semantics turn out to matter. Required
fields are not recommended now: they interact with field layout (ECS `@core`
and `@tag`, arena layout), and that interaction is unverified.

### D5. How do the built-in protocols relate to traits?

| Option | Meaning |
|---|---|
| **A. Leave them magic** | Traits are for user abstractions only; derives, formatting, `for` and operators stay compiler features. |
| **B. Lift the six derives into prelude traits** | `PartialEq`, `Eq`, `Hash`, `Ord`, `PartialOrd`, `Clone` become real traits with the supertrait chains they already have; `@derive` becomes "generate this impl". Primitives and the built-in collections get built-in impls. Bounds such as `K: Hash + Eq` and `T: Ord` become enforceable. |
| **C. B plus language-item traits** | Adds `Display`/`Debug` (formatting), `Iterable<T>` (`for x in value`) and operator traits (`Add`, `Sub`, `Index`, ..). Each closes one of the sema-accepts, runtime-panics probes above, and `Display`/`Debug` would define field order by declaration, fixing the print nondeterminism. |

**Recommended: B in the second slice; the items of C one at a time, each its
own decision.** Operator overloading in particular is a language-taste choice
(vector math for a game language argues for it) and deserves its own
yes or no, not a ride-along.

### D6. Bounds: syntax and enforcement

| Option | Meaning |
|---|---|
| **a. Call sites only** | Inferred type arguments must satisfy the bounds. |
| **b. (a) plus bodies** | Inside a generic body, a method call on `T` resolves only through `T`'s bounds, and a method call on an unbounded `T` is an error. |
| **c. (b) plus richer syntax** | `where` clauses and bounds with arguments (`T: Into<U>`). Needs `GenericParam.bounds` to become structured instead of `&[&str]`. |

**Recommended: b in the first slice, c later.** Option b is a deliberate
strictness change: the unbounded-`T` probe compiles today and panics at
runtime for `total(5)`. Whether any existing fixture relies on calling a
method on an unbounded parameter has not been checked; the fixture sweep
decides it, and any that does is a real bug the change would surface.

### D7. Tiers and traits

| Option | Meaning |
|---|---|
| **a. Tier on the signature** | A trait method signature carries an optional tier (default `high`, like every function). An impl method's tier must be at most the declared tier. A call through a bound is checked against the declared tier with the existing cross-tier rule. |
| **b. Tier-polymorphic traits** | Each impl declares its own tier and callers adapt. Sound only if call checks cannot be fooled; considerably more machinery. |
| **c. `HIGH` only** | Trait methods and bounded generic code usable only from `HIGH`; `MID` and `LOW` use concrete types. |

**Recommended: a, staged.** With no tier on signatures every trait method is
`high` by default, which is exactly option c for free through the existing
rule, so the first slice needs no new tier code. Adding `@tier(mid) fn
tick(self)` to a signature later only relaxes it. This is the most
concretely buildable piece of the outside synthesis noted in
`PARKED_IDEAS.md`, because `check_callee_tier` already exists.

### D8. Keywords: `impl` and `extend`

For inherent methods the two are equivalent today. `ImplBlock` carries a
block tier and an optional trait path; `ExtendDecl` carries neither.
**Recommended:** `extend` stays inherent only, `impl Trait for Type` is the
trait form, and a plain `impl Type { }` stays accepted so nothing breaks.

---

## 4. Proposed delivery order

Each slice is one delivery with an isolated and a combined fixture per phase,
exact-count tests, and the docs updated in the same bundle.

| Slice | Contents | Decisions it needs |
|---|---|---|
| **S1** | Nominal traits with static checking: register trait impl methods in sema and interpreter dispatch; conformance checks (missing method, method not in the trait, signature mismatch with `Self`); default methods inherited; bounds enforced at call sites and through bodies; inherent-first resolution and the qualified call. | D1 A, D2 A, D3, D4 i, D6 b, D7 a, D8 |
| **S2** | Prelude traits for the six derives; built-in impls for primitives; bounds on built-in collections; `@derive` becomes an impl generator. | D5 B |
| **S3a** | Supertraits (built). | D4 ii |
| **S3b** | Generic traits, bounds with arguments and generic supertraits (built). | D4 ii |
| S3c onward | Associated types, impls for generic types and for built-in types, and the two bound limits (a bound on an alias parameter, on a method's own parameter). The order is chosen with the project owner. | D4 ii |
| **S4** | Tier on trait method signatures. | D7 a |
| **S5** | Language-item traits, one decision and one delivery each: `Display`/`Debug`, `Iterable<T>`, operators. | D5 C |
| **S6** | `dyn Trait` in `HIGH`. | D2 B |

Indicative new diagnostics for S1, codes assigned when built:
`TraitMethodMissing`, `UnknownTraitMethod`, `TraitMethodSignatureMismatch`,
`UnsatisfiedBound`, `AmbiguousTraitMethod`, `OverlappingImpl`,
`MethodOnUnboundedParam`.

Explicitly deferred: blanket impls, the orphan rule, explicit-implementation
syntax, associated types, required fields, `FfiSpan<dyn Trait>`,
specialization.

---

## 5. Found along the way

Recorded here because they surfaced while reading and probing. None is part
of the trait work, and none has been changed.

- **Struct printing is nondeterministic.** The default struct display walks a
  `HashMap`, so field order varies between runs. `Value::Struct` already
  carries `field_order` (used for ordering and hashing); formatting does not
  use it. A small, separate fix.
- **`for` over a user type and arithmetic on user types are accepted by sema
  and panic at runtime.** Two more sema-accepts, runtime-panics holes, folded
  into D5 option C as the protocols that would give them a type error.
- **Method calls on an unbounded type parameter are accepted.** Folded into
  D6.
- **Supertrait syntax does not parse.** Folded into D4 level ii.
