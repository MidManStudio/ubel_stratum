// ============================================================================
// NOTICE: Full documentation, design decisions, and fix history for this file
// live in docs/ubel_stratum.md, section "error_management/errors/types/mod.rs"
// ============================================================================
// src/error_management/errors/types/mod.rs
//! Errors produced during ordinary type inference and type checking.
//!
//! Tier and arena enforcement errors used to live in this same enum
//! (as the TYPE-2xx range) but were physically split out into
//! `TierError` (see `../tier/mod.rs`) — see docs/DIAGNOSTICS_RULES.md
//! §9. This file now only carries TYPE-1xx.

use crate::lexer::Span;
use std::fmt;

/// What a `for` loop was given when it could not be iterated, which decides
/// the suggestion that goes with `NotIterable`.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NotIterableKind {
    /// A type parameter with no `Iterator` bound.
    Param,
    /// A struct or enum with no `Iterator` impl.
    UserType,
    /// Anything else: a scalar, a function, a `Handle`, and so on.
    Other,
}

/// Every error that can be raised during ordinary type checking
/// (not tier/arena enforcement — see `TierError` for that).
#[derive(Debug, Clone)]
pub enum TypeError {
    // ── Type mismatch ─────────────────────────────────────────────
    /// The types of two expressions that must agree do not.
    TypeMismatch {
        expected:     String,   // human-readable type name
        found:        String,
        span:         Span,
        /// Where the expected type was established, if known.
        because_of:   Option<Span>,
    },

    /// A function was called with the wrong number of arguments.
    ArgumentCountMismatch {
        expected: usize,
        found:    usize,
        span:     Span,
    },

    /// Tried to access a field that does not exist on a type.
    NoSuchField {
        field:   String,
        on_type: String,
        span:    Span,
    },

    /// Tried to call a method that does not exist on a type.
    NoSuchMethod {
        method:  String,
        on_type: String,
        span:    Span,
    },

    /// `?` operator used on a non-fallible type (not `T!`).
    TryOnNonFallible {
        found: String,
        span:  Span,
    },

    /// `await` used on a non-`Task<T>` type.
    AwaitOnNonTask {
        found: String,
        span:  Span,
    },

    /// `await` outside an async function or an async block.
    AwaitOutsideAsync {
        span: Span,
    },

    /// An async function whose declared result is not `Task<T>`. Written
    /// `async fn f() Task<int>` (or bare, for `Task<void>`), never `async fn f() int`.
    AsyncReturnNotTask {
        found: String,
        span:  Span,
    },

    /// `*`/`deref` used on a non-reference type.
    DerefOnNonReference {
        found: String,
        span:  Span,
    },

    /// A `{value:spec}` format spec used a part that doesn't apply to
    /// `value`'s type — currently only `.precision` is type-restricted
    /// (Float/Double/Str); width/align/`?` apply to anything.
    InvalidFormatSpec {
        spec_part: String,
        on_type:   String,
        span:      Span,
    },

    /// `#` (the alternate form) with no trailing numeric base (`x`/`X`/
    /// `o`/`b`) in the same format spec. Distinct from
    /// `InvalidFormatSpec`: this isn't about `value`'s type at all (a
    /// `#` on an `Int` with no base is just as invalid as one on a
    /// `Str`), it's about a spec-internal combination that's missing its
    /// other half, the same shape `DeriveRequiresOther` covers for
    /// `@derive(...)`.
    AlternateFormatWithoutBase {
        span: Span,
    },

    /// `@derive(X)` named something that isn't a recognized, supported
    /// derive trait *in this context*. Covers three distinct real cases
    /// with one variant: a genuinely unknown name; `Debug`/`Display`
    /// anywhere (both automatic for every struct/enum already, no
    /// opt-in needed — docs/PRINT_FORMAT_RULES.md §6); and `PartialEq`
    /// specifically on an `enum` (an enum's `==` is already structural,
    /// see `Value::equals`'s Enum arm — only a `struct`'s default needs
    /// flipping). `trait_name` holds a readable description of the bad
    /// argument, not necessarily a real identifier — a non-`Ident` arg
    /// (`@derive("PartialEq")`, `@derive(x = 1)`) reaches here too, not
    /// just misspelled/inapplicable names.
    UnknownDeriveTrait {
        trait_name: String,
        span:       Span,
    },

    /// `@derive(X)` named a real, recognized trait, but without a
    /// companion trait it depends on also being present in the same
    /// `@derive(...)` list. `Eq` needs `PartialEq`, `PartialOrd` needs
    /// `PartialEq`, `Ord` needs `PartialOrd` (which transitively covers
    /// `PartialEq` too, but both are checked directly rather than
    /// relying on transitivity, so the message always names the
    /// *immediate* gap), `Hash` needs `Eq` (not a real Rust supertrait
    /// bound for `Hash` specifically, but the bound every actual
    /// hash-map API uses in practice, `K: Eq + Hash`), and the entire
    /// reason this project wants `Hash` at all (a future `Dict` key).
    /// `Clone` has no prerequisite. Distinct from `UnknownDeriveTrait`
    /// on purpose: this isn't an invalid or unrecognized name, it's a
    /// valid one requested incompletely.
    DeriveRequiresOther {
        trait_name: String,
        requires:   String,
        span:       Span,
    },

    /// `<`/`<=`/`>`/`>=` used on a type with no ordering: anything other
    /// than `Int`/`Float`/`Double`/`Str`/`Bool`, or a `struct` that
    /// hasn't `@derive`d `PartialOrd`/`Ord`. Previously a silent gap:
    /// these operators only ever worked for numeric operands
    /// (`eval_binop`'s `promote_numeric`), and anything else reached a
    /// runtime panic (`"arithmetic not supported on {type}"`) with no
    /// sema-time check at all. `on_type` is the resolved type as
    /// displayed to the person, not necessarily a struct. This also
    /// catches e.g. two `List`s compared with `<`, which never had an
    /// ordering to begin with and isn't expected to gain one here.
    TypeNotOrderable {
        on_type: String,
        span:    Span,
    },

    /// A suffixed integer literal's value doesn't fit the suffix's
    /// declared width (`300u8`), or an unsuffixed literal auto-promoted
    /// to `u64` still overflowed even that (unreachable today -- the
    /// lexer's own `u64::MAX` ceiling already catches that case as a
    /// lex error first -- kept here anyway so this check is complete on
    /// its own terms, not dependent on the lexer's ceiling matching it).
    /// Caught at sema time rather than silently wrapping, matching
    /// Rust's own `error: literal out of range for` on the same source.
    ///
    /// Also raised for an *unsuffixed* literal whose inferred type turned
    /// out to be too narrow for it (`let x: u8 = 300`, `f(-1)` where the
    /// parameter is `u32`). Then `inferred` is `true`, `suffix` holds the
    /// name of the type the context picked, and `negative` says whether
    /// the literal sat directly under a unary `-` (`raw` is always the
    /// magnitude).
    IntLiteralOutOfRange {
        suffix:   &'static str,
        raw:      u64,
        negative: bool,
        inferred: bool,
        span:     Span,
    },

    /// A name written where a trait is required (`impl Name for T`, or a
    /// bound `T: Name`) that is not a trait: either nothing is declared by
    /// that name (`found: None`) or it names something else (`found:
    /// Some("struct")`).
    NotATrait {
        name:  String,
        found: Option<&'static str>,
        span:  Span,
    },

    /// An `impl Trait for Type` that lacks a method the trait requires and
    /// gives no default for.
    TraitMethodMissing {
        trait_name: String,
        method:     String,
        type_name:  String,
        span:       Span,
    },

    /// An `impl Trait for Type` with a method the trait does not declare.
    UnknownTraitMethod {
        trait_name: String,
        method:     String,
        span:       Span,
    },

    /// An impl method whose signature differs from the trait's, after
    /// `Self` is replaced by the implementing type. `expected` and `found`
    /// are rendered signatures (`fn(int) int`).
    TraitMethodSignatureMismatch {
        trait_name: String,
        method:     String,
        expected:   String,
        found:      String,
        span:       Span,
    },

    /// A type that does not implement a trait it is required to: a
    /// qualified call `Trait.method(value)` on a value whose type has no
    /// `impl Trait`, or (with bounds enforcement) a generic argument that
    /// fails its bound.
    UnsatisfiedBound {
        type_name:  String,
        trait_name: String,
        /// The type is a type parameter, which gets the trait from a bound
        /// written where it is declared, not from an `impl`.
        is_param:   bool,
        span:       Span,
    },

    /// An unqualified method call that two traits implemented by one type
    /// both supply, with no inherent method of that name to win. Written
    /// with the trait instead: `Trait.method(value)`.
    AmbiguousTraitMethod {
        method:    String,
        traits:    Vec<String>,
        type_name: String,
        span:      Span,
    },

    /// Two `impl`s of one trait for one type.
    OverlappingImpl {
        trait_name: String,
        type_name:  String,
        /// Why two impls collide when it is not plain from the types: a
        /// built-in type that has the trait natively, or two types that are
        /// one kind of value at run time.
        note:       Option<String>,
        span:       Span,
    },

    /// A trait-system construct that parses but is not built yet (an
    /// impl for a built-in type, a generic trait, an associated type).
    /// Reported explicitly so it is never silently ignored.
    UnsupportedTraitFeature {
        feature: &'static str,
        span:    Span,
    },

    /// A method called on a value whose type is a type parameter with no
    /// trait bound. Nothing says what the parameter can do, so the call
    /// cannot be resolved (and would panic at runtime for an argument
    /// type that lacks the method). A parameter that HAS bounds, none of
    /// which declares the method, is `NoSuchMethod` instead.
    MethodOnUnboundedParam {
        method: String,
        param:  String,
        span:   Span,
    },

    /// `==`, `!=`, `<`, `<=`, `>` or `>=` on a value whose type is a type
    /// parameter that does not declare the trait the operator needs
    /// (`PartialEq` for the first two, `PartialOrd` for the others).
    OperatorNeedsBound {
        op:         &'static str,
        param:      String,
        trait_name: &'static str,
        span:       Span,
    },

    /// An impl of a trait for a type that does not implement the traits
    /// that trait builds on (`impl Ord for P` needs `PartialOrd` and `Eq`,
    /// and through them `PartialEq`; `impl B for P` with `trait B: A` needs
    /// `A`). `derivable` is true when the missing trait is one `@derive`
    /// can supply, which decides the suggestion.
    MissingSupertraitImpl {
        trait_name: String,
        supertrait: String,
        derivable:  bool,
        type_name:  String,
        span:       Span,
    },

    /// Two bounds on one type parameter that apply the same trait to
    /// different arguments (`T: Convert<int> + Convert<string>`). A type has
    /// one impl of a trait, so no type can satisfy both. `first` and `second`
    /// are the two applications as written.
    ConflictingBounds {
        param:      String,
        trait_name: String,
        first:      String,
        second:     String,
        span:       Span,
    },

    /// A `for` loop over a value with nothing to iterate: a type that is not a
    /// collection, a string, a tuple or a range, and has no `Iterator<T>` impl
    /// (or, for a type parameter, no `Iterator<T>` bound). The run time has no
    /// way to walk such a value and would panic.
    NotIterable {
        type_name: String,
        kind:      NotIterableKind,
        span:      Span,
    },

    /// An operator applied to operands with no operator-trait impl behind
    /// it: a struct or enum with no `impl Mul<R, Out> for T` for this right
    /// operand, or a built-in left operand with no `impl Mul<UserType, Out>
    /// for double`. `rhs` is `None` for a unary operator; `available` lists
    /// the right operands the left type does have an impl for, so the
    /// suggestion can name them.
    /// An index (`a[i]`) or an assignment through one (`a[i] = v`) on a value
    /// that cannot be indexed that way: a number, a `Queue`, a `Stack`, a
    /// `Set`, a function, or a string or tuple being assigned to. `write` is
    /// true for an assignment.
    NotIndexable {
        type_name: String,
        write:     bool,
        span:      Span,
    },

    /// A built-in operator applied to a built-in type it is not defined for:
    /// `[1] + [2]`, `true & false`, `1.5 & 2.5`, `-x` for an unsigned `x`.
    /// `op` is the operator as written, `+=` and `~` included. A user type goes
    /// through `OperatorNotImplemented` instead, which asks for an impl.
    OperatorNotSupported {
        op:      &'static str,
        on_type: String,
        span:    Span,
    },

    /// A call whose callee has a type that is never a function: `n()` for an
    /// `int`, a string, a collection, a tuple or a struct value. Before this
    /// variant it was a `NoSuchMethod` for a method called `<call>`.
    NotCallable {
        on_type: String,
        span:    Span,
    },

    /// A literal tuple index past the end: `t[5]` for a tuple of two. `index`
    /// is the index as written (`5`, `-1`).
    TupleIndexOutOfRange {
        index: String,
        len:   usize,
        tuple: String,
        span:  Span,
    },

    /// A struct literal written with the name of an alias whose target is not a
    /// struct or an enum: `type Score = int`, then `Score { x = 1 }`.
    NotAStruct {
        name:   String,
        target: String,
        span:   Span,
    },

    /// `dyn Trait` written for a trait that cannot be used that way: a method
    /// with no `self` receiver, with generic parameters of its own, or that
    /// mentions `Self` outside the receiver, in the trait or in one it builds
    /// on. `reasons` has one entry per offending method.
    NotObjectSafe {
        trait_name: String,
        reasons:    Vec<String>,
        span:       Span,
    },

    OperatorNotImplemented {
        op:         &'static str,
        trait_name: &'static str,
        lhs:        String,
        rhs:        Option<String>,
        available:  Vec<String>,
        span:       Span,
    },

    /// A trait that is its own supertrait, directly (`trait A: A`) or
    /// through others (`trait A: B  trait B: A`). `path` is the cycle as
    /// written, `A -> B -> A`, starting and ending at `trait_name`.
    SupertraitCycle {
        trait_name: String,
        path:       String,
        span:       Span,
    },

    /// A `type` alias that refers to itself, directly (`type A = A`) or
    /// through other aliases (`type A = B  type B = A`), so it has no
    /// finite expansion. Also reported for an alias that depends on one
    /// that does, since it cannot be expanded either.
    TypeAliasCycle {
        name: String,
        span: Span,
    },

    /// A type could not be inferred — too ambiguous.
    CannotInferType {
        span:       Span,
        suggestion: Option<String>,
    },

    /// A generic was instantiated with the wrong number of type arguments.
    GenericArgCountMismatch {
        type_name: String,
        expected:  usize,
        found:     usize,
        span:      Span,
    },

    // ── Enum sema (ENUM_RULES.md) ────────────────────────────────

    /// `EnumName.variant_name` where `variant_name` isn't a real variant
    /// of `EnumName` — either as an expression (`Direction.Northeast`) or
    /// a pattern (`Direction.Northeast => ...`).
    UnknownVariant {
        enum_name:    String,
        variant_name: String,
        span:         Span,
    },

    /// A tuple-payload variant constructed or matched with the wrong
    /// number of elements — `Result.Ok(1, 2)` when `Ok` holds exactly one.
    VariantArityMismatch {
        enum_name:    String,
        variant_name: String,
        expected:     usize,
        found:        usize,
        span:         Span,
    },

    /// A `match` over an enum scrutinee doesn't cover every variant and
    /// has no wildcard/catch-all arm.
    NonExhaustiveMatch {
        missing_variants: Vec<String>,
        span:             Span,
    },

    /// An enum declares both an explicit `Discriminant` variant and a
    /// payload-carrying (`Tuple`/`Struct`) variant — ENUM_RULES.md §4,
    /// item 2: disallowed, since there's no defined runtime
    /// representation for "this variant has both a chosen ordinal and a
    /// payload shape."
    MixedDiscriminantAndPayload {
        enum_name: String,
        span:      Span,
    },

    // ── InlineList (DATASTRUCTURES.md §5) ────────────────────────

    /// `InlineList.new(capacity)` — `capacity` must be a literal
    /// integer, checked directly against the argument's own AST node
    /// (not a general const-expression evaluator — genuine inline/stack
    /// storage needs its size known at compile time, and a literal is
    /// the narrowest thing that guarantees that without building real
    /// const generics, which the language has nowhere else either).
    InlineListCapacityNotLiteral {
        span: Span,
    },
}

/// The operator traits the prelude declares, as (trait, method, operator,
/// number of type parameters). One table so the diagnostics, sema and the
/// run time agree on the names.
pub const OPERATOR_TRAITS: &[(&str, &str, &str, usize)] = &[
    ("Add",    "add",     "+",  2),
    ("Sub",    "sub",     "-",  2),
    ("Mul",    "mul",     "*",  2),
    ("Div",    "div",     "/",  2),
    ("Rem",    "rem",     "%",  2),
    ("BitAnd", "bit_and", "&",  2),
    ("BitOr",  "bit_or",  "|",  2),
    ("BitXor", "bit_xor", "^",  2),
    ("Shl",    "shl",     "<<", 2),
    ("Shr",    "shr",     ">>", 2),
    ("Neg",    "neg",     "-",  1),
    ("BitNot", "bit_not", "~",  1),
    ("Index",    "index",     "[]",  2),
    ("IndexSet", "index_set", "[]=", 2),
];

/// Number of type parameters of an operator trait, or 0 for any other trait.
pub fn operator_trait_arity(trait_name: &str) -> usize {
    OPERATOR_TRAITS.iter().find(|t| t.0 == trait_name).map_or(0, |t| t.3)
}

/// The method an operator trait declares (`Mul` gives `mul`).
pub fn operator_method_of(trait_name: &str) -> &'static str {
    OPERATOR_TRAITS.iter().find(|t| t.0 == trait_name).map_or("", |t| t.1)
}

/// An operator trait written the way a user would (`Mul<R, Out>`).
fn trait_label(trait_name: &str) -> String {
    match operator_trait_arity(trait_name) {
        _ if trait_name == "Index"    => "Index<Idx, Out>".to_string(),
        _ if trait_name == "IndexSet" => "IndexSet<Idx, Val>".to_string(),
        2 => format!("{}<R, Out>", trait_name),
        1 => format!("{}<Out>", trait_name),
        _ => trait_name.to_string(),
    }
}

impl TypeError {
    pub fn span(&self) -> Span {
        match self {
            TypeError::TypeMismatch               { span, .. } => *span,
            TypeError::ArgumentCountMismatch      { span, .. } => *span,
            TypeError::NoSuchField                { span, .. } => *span,
            TypeError::NoSuchMethod               { span, .. } => *span,
            TypeError::TryOnNonFallible           { span, .. } => *span,
            TypeError::AwaitOnNonTask             { span, .. } => *span,
            TypeError::AwaitOutsideAsync          { span, .. } => *span,
            TypeError::AsyncReturnNotTask         { span, .. } => *span,
            TypeError::DerefOnNonReference        { span, .. } => *span,
            TypeError::InvalidFormatSpec          { span, .. } => *span,
            TypeError::AlternateFormatWithoutBase { span, .. } => *span,
            TypeError::UnknownDeriveTrait          { span, .. } => *span,
            TypeError::DeriveRequiresOther          { span, .. } => *span,
            TypeError::TypeNotOrderable             { span, .. } => *span,
            TypeError::IntLiteralOutOfRange        { span, .. } => *span,
            TypeError::NotATrait                   { span, .. } => *span,
            TypeError::TraitMethodMissing          { span, .. } => *span,
            TypeError::UnknownTraitMethod          { span, .. } => *span,
            TypeError::TraitMethodSignatureMismatch { span, .. } => *span,
            TypeError::UnsatisfiedBound            { span, .. } => *span,
            TypeError::AmbiguousTraitMethod        { span, .. } => *span,
            TypeError::OverlappingImpl             { span, .. } => *span,
            TypeError::UnsupportedTraitFeature     { span, .. } => *span,
            TypeError::MethodOnUnboundedParam      { span, .. } => *span,
            TypeError::OperatorNeedsBound          { span, .. } => *span,
            TypeError::MissingSupertraitImpl       { span, .. } => *span,
            TypeError::SupertraitCycle             { span, .. } => *span,
            TypeError::ConflictingBounds           { span, .. } => *span,
            TypeError::NotIterable                 { span, .. } => *span,
            TypeError::OperatorNotImplemented      { span, .. } => *span,
            TypeError::NotIndexable                { span, .. } => *span,
            TypeError::NotObjectSafe               { span, .. } => *span,
            TypeError::OperatorNotSupported        { span, .. } => *span,
            TypeError::NotCallable                 { span, .. } => *span,
            TypeError::TupleIndexOutOfRange        { span, .. } => *span,
            TypeError::NotAStruct                  { span, .. } => *span,
            TypeError::TypeAliasCycle              { span, .. } => *span,
            TypeError::CannotInferType            { span, .. } => *span,
            TypeError::GenericArgCountMismatch    { span, .. } => *span,
            TypeError::UnknownVariant             { span, .. } => *span,
            TypeError::VariantArityMismatch       { span, .. } => *span,
            TypeError::NonExhaustiveMatch         { span, .. } => *span,
            TypeError::MixedDiscriminantAndPayload{ span, .. } => *span,
            TypeError::InlineListCapacityNotLiteral{ span, .. } => *span,
        }
    }

    pub fn message(&self) -> String {
        match self {
            TypeError::TypeMismatch { expected, found, .. } =>
                format!("type mismatch: expected `{}`, found `{}`", expected, found),

            TypeError::ArgumentCountMismatch { expected, found, .. } =>
                format!("expected {} argument(s), found {}", expected, found),

            TypeError::NoSuchField { field, on_type, .. } =>
                format!("type `{}` has no field `{}`", on_type, field),

            TypeError::NoSuchMethod { method, on_type, .. } =>
                format!("type `{}` has no method `{}`", on_type, method),

            TypeError::TryOnNonFallible { found, .. } =>
                format!("`?` requires a fallible type (`T!`), found `{}`", found),

            TypeError::AwaitOnNonTask { found, .. } =>
                format!("`await` requires `Task<T>`, found `{}`", found),

            TypeError::AwaitOutsideAsync { .. } =>
                "`await` is only valid inside an async function or an async block".to_string(),

            TypeError::AsyncReturnNotTask { found, .. } =>
                format!("an async function returns `Task<T>`, found `{}`", found),

            TypeError::DerefOnNonReference { found, .. } =>
                format!("`*`/`deref` requires a reference type (`&T`/`ref T`), found `{}`", found),

            TypeError::InvalidFormatSpec { spec_part, on_type, .. } =>
                format!("`{}` in a format spec doesn't apply to type `{}`", spec_part, on_type),

            TypeError::AlternateFormatWithoutBase { .. } =>
                "`#` in a format spec needs a numeric base (`x`/`X`/`o`/`b`)".to_string(),

            TypeError::UnknownDeriveTrait { trait_name, .. }
                if trait_name == "Debug" || trait_name == "Display" || trait_name == "PartialEq" =>
                format!("`@derive({})` is unnecessary — this is already automatic", trait_name),

            TypeError::UnknownDeriveTrait { trait_name, .. } =>
                format!("unknown derive trait `{}`", trait_name),

            TypeError::DeriveRequiresOther { trait_name, requires, .. } =>
                format!("`@derive({})` also needs `@derive({})`", trait_name, requires),

            TypeError::TypeNotOrderable { on_type, .. } =>
                format!("type `{}` doesn't support ordering comparisons", on_type),

            TypeError::NotATrait { name, found, .. } => match found {
                None       => format!("unknown trait `{}`", name),
                Some(kind) => format!("`{}` is a {}, not a trait", name, kind),
            },

            TypeError::TraitMethodMissing { trait_name, method, type_name, .. } =>
                format!("`{}` does not implement `{}`, which trait `{}` requires", type_name, method, trait_name),

            TypeError::UnknownTraitMethod { trait_name, method, .. } =>
                format!("`{}` is not a method of trait `{}`", method, trait_name),

            TypeError::TraitMethodSignatureMismatch { trait_name, method, expected, found, .. } =>
                format!("method `{}` does not match trait `{}`: expected `{}`, found `{}`",
                        method, trait_name, expected, found),

            TypeError::UnsatisfiedBound { type_name, trait_name, .. } =>
                format!("the trait `{}` is not implemented for `{}`", trait_name, type_name),

            TypeError::AmbiguousTraitMethod { method, traits, type_name, .. } =>
                format!("method `{}` on `{}` is supplied by more than one trait ({})",
                        method, type_name,
                        traits.iter().map(|t| format!("`{}`", t)).collect::<Vec<_>>().join(", ")),

            TypeError::OverlappingImpl { trait_name, type_name, note, .. } => match note {
                Some(note) => format!(
                    "`{}` is implemented for `{}` more than once ({})", trait_name, type_name, note),
                None => format!("`{}` is implemented for `{}` more than once", trait_name, type_name),
            },

            TypeError::UnsupportedTraitFeature { feature, .. } =>
                format!("{} is not supported yet", feature),

            TypeError::MethodOnUnboundedParam { method, param, .. } =>
                format!("cannot call `{}` on a value of type parameter `{}`: it has no trait bound", method, param),

            TypeError::OperatorNeedsBound { op, param, trait_name, .. } =>
                format!("`{}` on a value of type parameter `{}` needs a `{}` bound", op, param, trait_name),

            TypeError::MissingSupertraitImpl { trait_name, supertrait, type_name, .. } =>
                format!("`impl {} for {}` needs `{}`, which `{}` does not implement", trait_name, type_name, supertrait, type_name),

            TypeError::ConflictingBounds { param, first, second, .. } =>
                format!("`{}` is bounded by both `{}` and `{}`, and no type implements both", param, first, second),

            TypeError::NotIterable { type_name, kind: NotIterableKind::Param, .. } =>
                format!("cannot iterate over a value of type parameter `{}`: it has no `Iterator` bound", type_name),

            TypeError::NotIterable { type_name, .. } =>
                format!("cannot iterate over a value of type `{}`", type_name),

            TypeError::NotIndexable { type_name, write: false, .. } =>
                format!("cannot index a value of type `{}`", type_name),

            TypeError::NotIndexable { type_name, write: true, .. } =>
                format!("cannot assign through an index of a value of type `{}`", type_name),

            TypeError::OperatorNotSupported { op, on_type, .. } =>
                format!("operator `{}` is not defined for `{}`", op, on_type),

            TypeError::NotCallable { on_type, .. } =>
                format!("cannot call a value of type `{}`", on_type),

            TypeError::TupleIndexOutOfRange { index, len, tuple, .. } =>
                format!("tuple index {} is out of range for `{}`, which has {} element(s)", index, tuple, len),

            TypeError::NotAStruct { name, target, .. } =>
                format!("`{}` is an alias for `{}`, which is not a struct or an enum", name, target),

            TypeError::NotObjectSafe { trait_name, reasons, .. } =>
                format!("the trait `{}` cannot be used as `dyn {}`: {}", trait_name, trait_name, reasons.join("; ")),

            TypeError::OperatorNotImplemented { trait_name: "Index", lhs, rhs: Some(rhs), .. } =>
                format!("cannot index `{}` with `{}`: no `Index<Idx, Out>` impl for this index", lhs, rhs),

            TypeError::OperatorNotImplemented { trait_name: "IndexSet", lhs, rhs: Some(rhs), .. } =>
                format!("cannot assign through an index of `{}` with `{}`: no `IndexSet<Idx, Val>` impl for this index", lhs, rhs),

            TypeError::OperatorNotImplemented { op, trait_name, lhs, rhs: Some(rhs), .. } =>
                format!("cannot apply `{}` to `{}` and `{}`: no `{}` impl for this pair", op, lhs, rhs, trait_label(trait_name)),

            TypeError::OperatorNotImplemented { op, trait_name, lhs, rhs: None, .. } =>
                format!("cannot apply `{}` to a value of type `{}`: no `{}` impl", op, lhs, trait_label(trait_name)),

            TypeError::SupertraitCycle { trait_name, path, .. } =>
                format!("trait `{}` is its own supertrait: {}", trait_name, path),

            TypeError::TypeAliasCycle { name, .. } =>
                format!("type alias `{}` refers to itself, directly or through other aliases", name),

            TypeError::IntLiteralOutOfRange { suffix, raw, negative, inferred, .. } => {
                let sign = if *negative { "-" } else { "" };
                if *inferred {
                    format!("literal `{}{}` is out of range for `{}`", sign, raw, suffix)
                } else {
                    format!("literal `{}{}{}` is out of range for `{}`", sign, raw, suffix, suffix)
                }
            }

            TypeError::CannotInferType { .. } =>
                "cannot infer type — add an explicit type annotation".to_string(),

            TypeError::GenericArgCountMismatch { type_name, expected, found, .. } =>
                format!(
                    "`{}` expects {} type argument(s), found {}",
                    type_name, expected, found
                ),

            TypeError::UnknownVariant { enum_name, variant_name, .. } =>
                format!("enum `{}` has no variant `{}`", enum_name, variant_name),

            TypeError::VariantArityMismatch { enum_name, variant_name, expected, found, .. } =>
                format!(
                    "`{}.{}` expects {} value(s), found {}",
                    enum_name, variant_name, expected, found
                ),

            TypeError::NonExhaustiveMatch { missing_variants, .. } =>
                format!(
                    "match is not exhaustive — missing variant(s): {}",
                    missing_variants.join(", ")
                ),

            TypeError::MixedDiscriminantAndPayload { enum_name, .. } =>
                format!(
                    "enum `{}` mixes an explicit discriminant variant with a payload-carrying variant",
                    enum_name
                ),

            TypeError::InlineListCapacityNotLiteral { .. } =>
                "InlineList.new(capacity) requires a literal integer capacity".to_string(),
        }
    }

    pub fn suggestion(&self) -> Option<String> {
        match self {
            TypeError::CannotInferType { suggestion: Some(s), .. } =>
                Some(s.clone()),

            TypeError::NonExhaustiveMatch { .. } =>
                Some("add arms for the missing variant(s), or a wildcard `_ => ...` arm to cover the rest".to_string()),

            TypeError::MixedDiscriminantAndPayload { .. } =>
                Some("use either explicit discriminants on every fieldless variant, or payload variants — not both in the same enum".to_string()),

            TypeError::InlineListCapacityNotLiteral { .. } =>
                Some("write the capacity as a plain integer literal, e.g. InlineList.new(64) — a variable or computed expression can't be used here".to_string()),

            TypeError::InvalidFormatSpec { spec_part, .. } if spec_part == "precision" =>
                Some("`.precision` only applies to float/double (decimal places) or string (max length) — drop it, or format a value of one of those types".to_string()),

            TypeError::InvalidFormatSpec { spec_part, .. } if spec_part == "sign (+)" =>
                Some("`+` only applies to int/float/double, drop it or format a numeric value".to_string()),

            TypeError::InvalidFormatSpec { spec_part, .. } if spec_part == "zero-pad (0)" =>
                Some("zero-padding only applies to int/float/double, drop the leading 0 or format a numeric value".to_string()),

            TypeError::InvalidFormatSpec { spec_part, .. } if spec_part == "numeric base" =>
                Some("`x`/`X`/`o`/`b` only apply to int, drop it or format an int value".to_string()),

            TypeError::AlternateFormatWithoutBase { .. } =>
                Some("add a trailing base, e.g. `{value:#x}`, or drop the `#`".to_string()),

            TypeError::UnknownDeriveTrait { trait_name, .. }
                if trait_name == "Debug" || trait_name == "Display" || trait_name == "PartialEq" =>
                Some(format!("drop `@derive({})` — it has no effect", trait_name)),

            TypeError::UnknownDeriveTrait { .. } =>
                Some("supported derive traits: `PartialEq`, `Eq`, `Hash`, `Ord`, `PartialOrd`, `Clone`".to_string()),

            TypeError::DeriveRequiresOther { trait_name, requires, .. } =>
                Some(format!("add `@derive({}, {})`", requires, trait_name)),

            TypeError::TypeNotOrderable { .. } =>
                Some("add `@derive(PartialOrd)` (or `@derive(Ord)`) to the struct, or compare a different field".to_string()),

            TypeError::NotATrait { found: None, .. } =>
                Some("declare it with `trait Name { .. }`, or check the spelling".to_string()),

            TypeError::TraitMethodMissing { method, .. } =>
                Some(format!("add `fn {}(..)` to the impl, or give the method a default body in the trait", method)),

            TypeError::UnknownTraitMethod { .. } =>
                Some("move it to an inherent `extend` block, or declare it in the trait".to_string()),

            TypeError::UnsatisfiedBound { type_name, trait_name, is_param: true, .. } =>
                Some(format!("declare the bound where `{}` is declared, as in `<{}: {}>`", type_name, type_name, trait_name)),
            TypeError::UnsatisfiedBound { type_name, trait_name, .. } =>
                Some(format!("add `impl {} for {} {{ .. }}`", trait_name, type_name)),

            TypeError::AmbiguousTraitMethod { method, traits, .. } =>
                Some(format!("name the trait: `{}.{}(value)`", traits.first().map(String::as_str).unwrap_or("Trait"), method)),

            TypeError::MethodOnUnboundedParam { method, param, .. } =>
                Some(format!("declare a bound that provides `{}`, as in `<{}: SomeTrait>`", method, param)),

            TypeError::OperatorNeedsBound { param, trait_name: "Index", .. } =>
                Some(format!("declare the bound, as in `<{}: Index<Idx, Out>>`", param)),

            TypeError::OperatorNeedsBound { param, trait_name: "IndexSet", .. } =>
                Some(format!("declare the bound, as in `<{}: IndexSet<Idx, Val>>`", param)),

            TypeError::OperatorNeedsBound { param, trait_name, .. } if operator_trait_arity(trait_name) == 2 =>
                Some(format!("declare the bound, as in `<{}: {}<{}, {}>>`", param, trait_name, param, param)),

            TypeError::OperatorNeedsBound { param, trait_name, .. } if operator_trait_arity(trait_name) == 1 =>
                Some(format!("declare the bound, as in `<{}: {}<{}>>`", param, trait_name, param)),

            TypeError::OperatorNeedsBound { param, trait_name, .. } =>
                Some(format!("declare the bound, as in `<{}: {}>`", param, trait_name)),

            TypeError::MissingSupertraitImpl { supertrait, derivable: true, type_name, .. } =>
                Some(format!("add `@derive({})` or `impl {} for {} {{ .. }}`", supertrait, supertrait, type_name)),

            TypeError::MissingSupertraitImpl { supertrait, type_name, .. } =>
                Some(format!("add `impl {} for {} {{ .. }}`", supertrait, type_name)),

            TypeError::ConflictingBounds { trait_name, .. } if operator_trait_arity(trait_name) > 0 =>
                Some(format!("a type has one impl of `{}` for each right operand, with one result type, so a parameter can be bounded by it once per right operand; keep one of the two", trait_name)),

            TypeError::ConflictingBounds { trait_name, .. } =>
                Some(format!("a type has one impl of `{}`, so a parameter can be bounded by it once; keep one of the two", trait_name)),

            TypeError::NotIterable { type_name, kind: NotIterableKind::Param, .. } =>
                Some(format!("declare a bound, as in `<{}: Iterator<Item>>`, or take a List", type_name)),

            TypeError::NotIterable { type_name, kind: NotIterableKind::UserType, .. } =>
                Some(format!("add `impl Iterator<Item> for {} {{ fn next(self) Item? {{ .. }} }}`, or iterate one of its collection fields", type_name)),

            TypeError::NotIndexable { write: false, .. } =>
                Some("a `List`, an array, a `Dictionary`, a `string`, a tuple, and a struct or enum that implements `Index<Idx, Out>` can be indexed".to_string()),

            TypeError::NotIndexable { write: true, .. } =>
                Some("a `List`, an array, a `Dictionary`, and a struct or enum that implements `IndexSet<Idx, Val>` can be assigned through an index; a `string` and a tuple are read only".to_string()),

            TypeError::OperatorNotSupported { op, on_type, .. } => Some(match op.trim_end_matches('=') {
                "+"                              => "`+` works on numbers, and on a string with a string".to_string(),
                "&" | "|" if on_type == "bool"   => "for booleans use `and` and `or`".to_string(),
                "-" if matches!(on_type.as_str(), "uint" | "ulong" | "usize" | "u8" | "u16" | "u32" | "u64") =>
                    "an unsigned integer has no negative; use a signed type".to_string(),
                "-" | "*" | "/" | "%"            => format!("`{}` works on numbers", op),
                _                                => format!("`{}` works on integers", op),
            }),

            TypeError::NotCallable { .. } =>
                Some("only a function, a closure, a method or an enum variant can be called".to_string()),

            TypeError::TupleIndexOutOfRange { len, .. } => Some(if *len == 0 {
                "an empty tuple has no elements".to_string()
            } else {
                format!("the valid indexes are 0 to {}", len - 1)
            }),

            TypeError::NotAStruct { target, .. } =>
                Some(format!("a struct literal needs the name of a struct; write a value of `{}` directly, or alias a struct", target)),

            TypeError::NotObjectSafe { .. } =>
                Some("a trait can be `dyn` when every method takes `self`, has no generic parameters of its own and does not mention `Self` outside the receiver; move the other methods to a separate trait".to_string()),

            TypeError::OperatorNotImplemented { trait_name: "Index", lhs, rhs: Some(rhs), available, .. } if available.is_empty() =>
                Some(format!("add `impl Index<{}, Out> for {} {{ fn index(self, idx: {}) Out {{ .. }} }}`", rhs, lhs, rhs)),

            TypeError::OperatorNotImplemented { trait_name: "IndexSet", lhs, rhs: Some(rhs), available, .. } if available.is_empty() =>
                Some(format!("add `impl IndexSet<{}, Val> for {} {{ fn index_set(self, idx: {}, value: Val) {{ .. }} }}`", rhs, lhs, rhs)),

            TypeError::OperatorNotImplemented { trait_name: "Index" | "IndexSet", lhs, rhs: Some(rhs), available, .. } =>
                Some(format!("`{}` is indexed with {}; add an impl for `{}`, or use one of those", lhs, available.join(", "), rhs)),

            TypeError::OperatorNotImplemented { trait_name, lhs, rhs: Some(rhs), available, .. } if available.is_empty() =>
                Some(format!("add `impl {}<{}, Out> for {} {{ fn {}(self, rhs: {}) Out {{ .. }} }}`", trait_name, rhs, lhs, operator_method_of(trait_name), rhs)),

            TypeError::OperatorNotImplemented { op, trait_name, lhs, rhs: Some(rhs), available, .. } =>
                Some(format!("`{}` on `{}` is implemented with {}; add `impl {}<{}, Out> for {} {{ .. }}` for `{}`, or use one of those", op, lhs, available.join(", "), trait_name, rhs, lhs, rhs)),

            TypeError::OperatorNotImplemented { trait_name, lhs, rhs: None, .. } =>
                Some(format!("add `impl {}<Out> for {} {{ fn {}(self) Out {{ .. }} }}`", trait_name, lhs, operator_method_of(trait_name))),

            TypeError::NotIterable { .. } =>
                Some("a `for` loop walks a List, an array, a Queue, a Stack, a Dictionary, an InlineList, a Pool, a string, a tuple, a range, or a struct or enum that implements `Iterator<T>`".to_string()),

            TypeError::SupertraitCycle { .. } =>
                Some("a supertrait is required by the trait that builds on it, so the chain of `: ...` links must end; remove one of them".to_string()),

            TypeError::TypeAliasCycle { .. } =>
                Some("an alias is just another name for a type, so it must end in a type that is not itself an alias of the same chain".to_string()),

            TypeError::IntLiteralOutOfRange { suffix, inferred, .. } =>
                Some(if *inferred {
                    format!("use a value that fits `{}`, or give the binding a wider type", suffix)
                } else {
                    format!("use a smaller value, drop the `{}` suffix, or pick a wider type", suffix)
                }),

            _ => None,
        }
    }
}

impl fmt::Display for TypeError {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "{}", self.message())
    }
}

impl std::error::Error for TypeError {}

impl crate::error_management::render::Diagnosable for TypeError {
    // See docs/DIAGNOSTICS_RULES.md, "Error Code Registry" — TYPE-1xx.
    // TYPE-2xx (tier & arena enforcement) is now `TierError`, its own
    // enum in `../tier/mod.rs`, with its own TIER-0xx range.
    fn code(&self) -> &'static str {
        match self {
            TypeError::TypeMismatch { .. }              => "TYPE-101",
            TypeError::ArgumentCountMismatch { .. }     => "TYPE-102",
            TypeError::NoSuchField { .. }                => "TYPE-103",
            TypeError::NoSuchMethod { .. }               => "TYPE-104",
            TypeError::TryOnNonFallible { .. }           => "TYPE-105",
            TypeError::AwaitOnNonTask { .. }             => "TYPE-106",
            TypeError::AwaitOutsideAsync { .. }          => "TYPE-143",
            TypeError::AsyncReturnNotTask { .. }         => "TYPE-144",
            TypeError::CannotInferType { .. }            => "TYPE-107",
            TypeError::GenericArgCountMismatch { .. }    => "TYPE-108",
            TypeError::UnknownVariant { .. }             => "TYPE-109",
            TypeError::VariantArityMismatch { .. }       => "TYPE-110",
            TypeError::NonExhaustiveMatch { .. }         => "TYPE-111",
            TypeError::MixedDiscriminantAndPayload { .. } => "TYPE-112",
            TypeError::InlineListCapacityNotLiteral { .. } => "TYPE-113",
            TypeError::DerefOnNonReference { .. }          => "TYPE-114",
            TypeError::InvalidFormatSpec { .. }            => "TYPE-115",
            TypeError::AlternateFormatWithoutBase { .. }   => "TYPE-119",
            TypeError::UnknownDeriveTrait { .. }            => "TYPE-116",
            TypeError::DeriveRequiresOther { .. }           => "TYPE-117",
            TypeError::TypeNotOrderable { .. }              => "TYPE-118",
            TypeError::IntLiteralOutOfRange { .. }          => "TYPE-120",
            TypeError::TypeAliasCycle { .. }                => "TYPE-121",
            TypeError::NotATrait { .. }                     => "TYPE-122",
            TypeError::TraitMethodMissing { .. }            => "TYPE-123",
            TypeError::UnknownTraitMethod { .. }            => "TYPE-124",
            TypeError::TraitMethodSignatureMismatch { .. } => "TYPE-125",
            TypeError::UnsatisfiedBound { .. }              => "TYPE-126",
            TypeError::AmbiguousTraitMethod { .. }          => "TYPE-127",
            TypeError::OverlappingImpl { .. }               => "TYPE-128",
            TypeError::UnsupportedTraitFeature { .. }       => "TYPE-129",
            TypeError::MethodOnUnboundedParam { .. }        => "TYPE-130",
            TypeError::OperatorNeedsBound { .. }            => "TYPE-131",
            TypeError::MissingSupertraitImpl { .. }         => "TYPE-132",
            TypeError::SupertraitCycle { .. }               => "TYPE-133",
            TypeError::ConflictingBounds { .. }             => "TYPE-134",
            TypeError::NotIterable { .. }                   => "TYPE-135",
            TypeError::OperatorNotImplemented { .. }        => "TYPE-136",
            TypeError::NotIndexable { .. }                  => "TYPE-137",
            TypeError::NotObjectSafe { .. }                 => "TYPE-138",
            TypeError::OperatorNotSupported { .. }          => "TYPE-139",
            TypeError::NotCallable { .. }                   => "TYPE-140",
            TypeError::TupleIndexOutOfRange { .. }          => "TYPE-141",
            TypeError::NotAStruct { .. }                    => "TYPE-142",
        }
    }
    fn span(&self) -> Span { self.span() }
    fn message(&self) -> String { self.message() }
    fn suggestion(&self) -> Option<String> { self.suggestion() }

    fn secondary_spans(&self) -> Vec<(Span, String)> {
        match self {
            TypeError::TypeMismatch { because_of: Some(span), .. } =>
                vec![(*span, "expected type was established here".to_string())],
            _ => Vec::new(),
        }
    }
}
