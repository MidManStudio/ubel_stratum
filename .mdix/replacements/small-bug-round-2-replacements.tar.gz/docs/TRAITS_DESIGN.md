# Traits: Design Options

> **Status: decisions made 2026-10-03; slice S1a built (section 0).**
> Sections 1 to 5 are the options as presented, kept as the record of what
> was weighed. Written for the dedicated traits design session that `docs/PARKED_IDEAS.md`
> ("Traits / interface system") called for. That section holds the
> reference-language survey and the evaluation of an outside synthesis; this
> document does not repeat them. It records what the compiler does with a
> trait today (read from source and confirmed by running programs), the
> constraints that shape the answer, one decision per section with options
> and a recommendation, and a delivery order. Once the decisions are made
> they move to "Decided, not yet built" in `PARKED_IDEAS.md`, one delivery
> at a time, each with its own fixtures.

---

## 0. Decisions and progress

### Decisions (2026-10-03)

| Decision | Chosen |
|---|---|
| **D1** kind of trait | **A**, nominal traits with explicit `impl Trait for Type`. |
| **D2** dispatch | **Both** static and dynamic. Static first (S1), `dyn Trait` in the last slice (S6). Settled at S6: every tier (C). |
| **D3** coherence | The recommended v1 answers: one impl per trait and type, overlap is an error, an inherent method beats a trait method, two traits supplying one name is an error at an unqualified call and is resolved with `Trait.method(value)`. The orphan rule, blanket impls and C#-style explicit implementation are **deferred** until there is more context. |
| **D4** trait contents | **All four levels**: methods and defaults, generic traits and supertraits, associated types, required fields and associated constants. Built in stages (S1, S3, and a later slice for the last level, which needs its field-layout interaction with ECS and arenas checked first). |
| **D5** built-in protocols | The recommendation: lift the six derives into prelude traits (S2); `Display`/`Debug`, `Iterable`, operators one at a time, each its own decision (S5). |
| **D6** bounds | The recommendation: enforce at call sites and through generic bodies, and make a method call on an unbounded type parameter an error (S1b); `where` clauses and bounds with arguments later. |
| **D7** tiers | A **hybrid** of options a and b: a trait can set a default tier for all its methods, each method can carry its own tier, an implementer must match the tier of the method it implements, and a specific method can override to change the tier. Flagged as complex and to be handled flawlessly, so it gets its own specification before any code (S4, below). |
| **D8** keywords | The recommendation: `extend` inherent only, `impl Trait for Type` the trait form, plain `impl Type { }` still accepted. |

### Slice S1 is split in two

| Slice | Status | Contents |
|---|---|---|
| **S1a** | **Built** | Trait impls registered in sema and interpreter dispatch; conformance checks (missing method, method not in the trait, signature mismatch with `Self`); default methods inherited or overridden; `Self` in signatures and default bodies; overlap; inherent-first; ambiguity and the qualified call `Trait.method(value)`; calls made through a trait run the trait's method; every trait feature not built yet reported as `TYPE-129` instead of ignored. |
| **S1b** | **Built** | Bounds: declared bounds validated, bound obligations checked wherever a bounded parameter is instantiated, method calls on a type parameter resolved through its bounds, a method call on an unbounded type parameter an error (`TYPE-130`). |
| **S2a, part 1** | **Built** | The prelude traits `PartialEq`, `Eq`, `PartialOrd`, `Ord` and `Clone` with real signatures, the `Ordering` enum, what built-in and derived types satisfy, supertrait bounds, the methods callable through a bound and directly on a value, operator checks on type parameters (`TYPE-131`), hand-written impls reported (`TYPE-129`). See "What S2a part 1 settled" below. |
| **S2a, part 2** | **Built** | `Hash` and the `Hasher` struct, `Hash` satisfaction, and `Hash` (which implies `Eq`) required of `Dictionary` keys. See "What S2a part 2 settled" below. |
| **S2b** | **Built** | Hand-written impls of the six prelude traits: checked like any trait impl, needing their supertraits (`TYPE-132`), and called by `==`, `!=`, the ordering operators, `contains` on every collection, dictionary lookup, assignment and indexing, `order_by`, `group_by`, and by derived comparison, `Hash` and `Clone` inside other values. See "What S2b settled" below. |
| **S3a** | **Built** | Supertraits: `trait B: A + C`. An impl needs the impls beneath it (`TYPE-132`, now for every trait), a bound implies them, a default body sees them, a cycle is an error (`TYPE-133`), and the prelude declares its own. See "What S3a settled" below. |
| **S3b** | **Built** | Generic traits (`trait Convert<T>`, `impl Convert<int> for X`), bounds with arguments (`T: Convert<int>`, `T: Convert<U>`) and generic supertraits (`trait Wide<T>: Convert<T>`), with one impl of a trait per type. See "What S3b settled" below. |
| **S3c** | **Built** | A method's own generic parameters with bounds (including generic methods in traits) and bounds on a type alias parameter. See "What S3c settled" below. |
| **S3d** | **Built** | Impls and `extend` blocks for primitives, tuples and arrays, and hand-written prelude traits where a built-in type lacks them. See "What S3d settled" below. |
| **S3e** | **Built** | Impls and `extend` blocks for generic types: a generic struct or enum, and `List`, `Dictionary`, `Queue`, `Stack` and `InlineList`. Impl parameters, conditional impls, impls for one instance (`Box<int>`). See "What S3e settled" below. |
| **S4a** | **Built** | The tier of a method is the tier written for it (its own, its `impl`, `extend` or struct, or a tier block), and a call on a receiver (`value.method()`, `Type.assoc()`) is checked against it with the cross-tier rule (`TIER-005`). The prelude's `Hasher` is `@tier(low)`. See `docs/TRAITS_TIERS_SPEC.md`. |
| **S4b** | **Built** | Tiers on traits: a trait, a trait method signature and a default method carry a tier (`@tier` on the method, else on the trait or a block around it, else `HIGH`); an impl method must equal it (`TIER-016`) and one that writes no tier takes it; a call through a bound, a qualified call and a default method call are checked (`TIER-005`); the six prelude traits are `@tier(low)`, so a hand-written impl of one is `LOW`. See `docs/TRAITS_TIERS_SPEC.md`. |
| **S5a** | **Built** | `Display`: a prelude trait (`@tier(low)`, `fn to_string(self) string`) that a struct or enum can implement by hand to decide how `println`, `print`, `log`, `to_string`, `{x}` and the messages of `assert` and `panic` show it, at any depth; a struct prints its fields in declaration order. See \"What S5a settled\" below. |
| **S5b** | **Built** | `Iterator<T>`: a prelude trait (`@tier(low)`, `fn next(self) T?`) that a struct or enum can implement so that `for x in value` calls `next` until it returns `null`. `Queue`, `Stack` and `Dictionary` become iterable, and a `for` over anything that cannot be walked is `TYPE-135`. See "What S5b settled" below. |
| **S5c** | **Built** | Operator traits: `Add`, `Sub`, `Mul`, `Div`, `Rem`, `BitAnd`, `BitOr`, `BitXor`, `Shl`, `Shr` (generic in the right operand and the result, `Mul<Rhs, Out>`) and `Neg<Out>`, `BitNot<Out>`, prelude traits (`@tier(low)`) that a struct or enum implements so that `a + b`, `a *= b`, `-a` and `~a` call it. A type has one impl of an operator trait per kind of right operand, and a number or a string on the left can take a struct or an enum on the right (`2.0 * v`). A bound such as `T: Add<T, T>` is satisfied by numbers, strings and impls; an operator with no impl is `TYPE-136` and one on an unbounded type parameter is `TYPE-131`. See "What S5c settled" below. |
| **S5d** | **Built** | `Index<Idx, Out>` and `IndexSet<Idx, Val>`, two `@tier(low)` prelude traits: a struct or enum that implements them is what `a[i]` and `a[i] = v` call (`a[i] += v` needs both), a type has one impl per kind of index, and `List`, arrays, `Dictionary` and strings satisfy them natively. The built-in indexables are typed as well (a `Dictionary` by its key, a string gives a `char`, an index has to be an `int`), what the run time cannot index is `TYPE-137`, a negative index on a write counts from the end, and tuple types now unify. See "What S5d settled" below. |
| **S6** | **Built** | `dyn Trait` and `dyn Trait<A>`: a type for a value of any type that implements the trait, written in every tier (`dyn Shape`, `&dyn Shape`, `Unique<dyn Shape>`; the tier wrapper comes from where the value is built, not from the type). The trait has to be object safe by Rust's rule (`TYPE-138`). A value becomes a `dyn` value by coercion at a typed site: a `let` with a written type, an argument, a return, an assignment, a struct or enum field, an element handed to a collection, an array literal on the right of a `let`, and `x as dyn Trait` (`TYPE-126` when the type does not implement the trait). A call, an operator, an index and a `for` on a `dyn` value go through the trait as through a bound, at the tier the trait declares. The run time needed no change. See "What S6 settled". |

### What S1a settled that the options did not

- **A call made through a trait runs the trait's method.** Inside a default
  method `self.area()` is resolved through the trait (inherent methods are not
  visible through a bound), so it must run the trait's `area` even when the
  concrete type also has an inherent `area`. Sema records each such call
  (`SemaContext::trait_call_sites`) and the interpreter dispatches those
  through its per-trait table, the same way it already takes
  `int_literal_types`. S1b reuses this for every call through a declared bound.
- **`Self`** is the implementing type inside an `impl`, `extend` or struct,
  and an abstract parameter inside a trait. The abstract `Self` is the
  reserved `Param` index equal to the trait's generic arity, so one
  `substitute` call replaces the trait's own arguments and `Self` together
  once generic traits exist.
- **Not yet checkable:** an impl for a built-in type, a generic trait and an
  associated type are each reported as `TYPE-129` (`UnsupportedTraitFeature`),
  so none is silently ignored. Impls for built-in types arrive with S2, generic
  traits with S3.

### What S1b settled that the options did not

- **Bound names.** A bound must name a trait declared in the program
  (`TYPE-122` otherwise, once per declaration, at the parameter). The six
  derive names (`PartialEq`, `Eq`, `Hash`, `Ord`, `PartialOrd`, `Clone`) are
  not declared traits until S2, so a bound written with one is `TYPE-129`
  rather than being accepted and ignored. A user trait that happens to use
  one of those names is a real bound. (Since S2a all six are prelude traits
  and ordinary bounds.) A bound on a type alias parameter or on
  a method's own generic parameter was `TYPE-129` too until S3c, because
  neither scope existed in sema.
- **Where a bound is enforced.** Each place a bounded parameter is
  instantiated records an obligation that the argument type implements the
  trait: a call to a generic function (including a call through a variable
  that holds it), a struct literal, an enum variant construction, an
  associated function called on a generic struct, and a type annotation that
  names a bounded struct or enum with arguments. A call is reported at the
  first argument whose declared type is the bounded parameter, the others at
  the expression or annotation.
- **When it is decided.** Obligations are settled at the end of the body,
  after integer literal types are settled (so `total(5)` reports `int`, not
  `{integer}`), and reported in source order. An argument that is still an
  unresolved inference variable is not an error. Obligations raised by
  signatures wait until every impl is registered.
- **Method calls on a type parameter.** The receiver's type parameter is
  looked up in the bounds in force for the body: a generic function, a method
  of a generic struct, and an `extend` or `impl` block on one all see the
  declaration's bounds. With bounds, the method must come from one of them
  (`TYPE-104` when none supplies it, `TYPE-127` when two do). With none, the
  call is `TYPE-130`. Calls resolved through a bound are recorded in
  `trait_call_sites`, so the trait's method runs even when the concrete type
  has an inherent method of the same name.
- **Reference and ownership wrappers are ignored.** A value reached through
  `ArenaRef`, `GcRef`, `OwnedRef`, `PoolRef`, `Unique`, `Shared`, `SyncShared`
  or a borrow satisfies the same bounds as the bare value. This can only miss
  a violation, never reject a program that is fine.
- **Still open:** `where` clauses and bounds with arguments (later); bounds
  naming `Hash` and impls for built-in types need S2.

### What S2 settled (decided 2026-10-07)

Decisions made for S2, in addition to D5 B (lift the six derives into prelude
traits):

- **Real methods, with dispatch to hand-written impls.** The six traits carry
  methods, and `==`, `<`, hashing and `clone` call a hand-written impl when one
  exists. This is the larger runtime change, chosen over marker traits.
- **Floats.** `float` and `double` implement `PartialEq`, `PartialOrd` and
  `Clone` only, not `Eq`, `Hash` or `Ord`, because of NaN.
- **Enforcement on existing code.** `Dictionary` keys must implement `Hash` and
  `Eq`, and `==`, `!=` and the ordering operators on a value of type-parameter
  type require `PartialEq` or `PartialOrd` in its bounds.
- **Method surface.**

| Trait | Methods | Notes |
|---|---|---|
| `PartialEq` | `eq(self, other: Self) bool` | Default `ne`. |
| `Eq` | none | Supertrait `PartialEq`. |
| `PartialOrd` | `partial_cmp(self, other: Self) Ordering?` | Defaults `lt`, `le`, `gt`, `ge`. Supertrait `PartialEq`. |
| `Ord` | `cmp(self, other: Self) Ordering` | Supertraits `PartialOrd` and `Eq`. |
| `Hash` | `hash(self, state: Hasher)` | Rust style: the hasher is a parameter. |
| `Clone` | `clone(self) Self` | |

  `Ordering` is a prelude enum `{ Less, Equal, Greater }`. `Hasher` is a
  built-in type. Its surface is `Hasher.new()` and `state.finish() u64`, with
  each value's `hash` writing into the state (confirmed 2026-10-08, built in
  S2a part 2).
- **Two deliveries.** S2a was the static side and S2b the runtime dispatch.
  Between them a hand-written `impl PartialEq for X` (and the other five) was
  `TYPE-129`, so an impl that `==` would ignore was never accepted silently;
  S2b lifted that restriction when the dispatch landed.
- **Defaults taken without objection.** `@derive(X)` registers the impl and the
  derive prerequisite chain becomes the supertraits; lists, tuples and
  optionals satisfy a trait when their elements do, by a built-in rule rather
  than impl blocks; enums keep automatic `PartialEq`, `Eq` and `Hash` and gain
  no `Ord` or `Clone` in S2; a user trait named like a prelude trait shadows it;
  `==` on a concrete struct without `PartialEq` stays reference identity.

What reading the code established before this was decided:

- `Value::equals` and `Value::partial_cmp` take no interpreter and are called
  from more than a dozen places (the binary operators, list, queue, stack and
  inline-list `contains`, the dictionary methods, indexing, the Linqerizer
  grouping and ordering). S2b gave each of them a route back into the
  interpreter (`interpreter/eval/user_ops.rs`).
- `Dict` is `Vec<(Value, Value)>` searched by `equals`; hashing has no consumer
  yet. A struct key without `PartialEq` is found by reference identity, so a
  lookup with an equal but distinct key returns `null`.
- Sema's maps are keyed by `Span` (four `usize` fields, `Hash` and `Eq`), so
  prelude declarations cannot be parsed from a separate text at ordinary spans.
  The two ways to bring the prelude traits in are a prelude written in Ubel whose
  token spans are shifted into a reserved range, and programmatic registration
  with natively implemented methods; diagnostics are rendered by indexing the
  source's lines, so a label that points into the prelude would need handling in
  the renderer. The mechanism was chosen in S2a part 1, see below.

### What S2a part 1 settled

- **The prelude is Ubel source, injected by `parse()`.**
  `crates/rd_parser/src/prelude.rs` holds the declarations (`Ordering`,
  `PartialEq`, `Eq`, `PartialOrd`, `Ord`, `Clone`). They are lexed once with
  every token span shifted into the range `Span::is_prelude` reserves (it
  starts at 2^31 so that it fits the 32-bit `usize` of `wasm32`, and no user
  node can collide with one in sema's `Span`-keyed tables), parsed with each
  program and placed in front of the program's own items. This was chosen over programmatic registration because the prelude
  traits then use the machinery a user trait does: signatures, default
  methods (`ne`, `lt`, `le`, `gt` and `ge` are written in Ubel), bounds and
  `Self`.
- **Shadowing.** A program that declares one of these names keeps its own, and
  the prelude items that depend on it are dropped with it: `Eq` and
  `PartialOrd` depend on `PartialEq`, `PartialOrd` and `Ord` on `Ordering`,
  `Ord` on `PartialOrd` and `Eq`.
- **Supertraits.** A bound `T: Ord` also puts `PartialOrd`, `Eq` and
  `PartialEq` in force inside the body. Declared bounds stay as written, so a
  call site raises one obligation per declared bound. Until S3a this was a table
  in sema, because `trait B: A` was not parsed; the prelude now declares them
  like any trait (see "What S3a settled").
- **What satisfies a prelude trait** follows what the runtime does with the
  value:

| Type | `PartialEq` | `Eq` | `PartialOrd` | `Ord` | `Clone` | `Hash` |
|---|---|---|---|---|---|---|
| integers (every width), `string` | yes | yes | yes | yes | yes | yes |
| `float`, `double`, `f32`, `f64` | yes | no | yes | no | yes | no |
| `bool`, `char` | yes | yes | no | no | yes | yes |
| tuple, optional | when elements are | when elements are | no | no | when elements are | when elements are |
| struct | if derived | if derived | if derived | if derived | if derived | if derived |
| enum | yes | yes | no | no | no | yes |
| every other built-in type | no | no | no | no | no | no |

  Ordering is limited to what `<` accepts (it is not defined on `bool` or
  `char`). `==` on a collection is reference identity, so a collection is not
  `PartialEq`. A value reached through an ownership or reference wrapper has
  the traits of the value.
- **Methods.** `eq`, `ne`, `partial_cmp`, `lt`, `le`, `gt`, `ge`, `cmp` and
  `clone` can be called through a bound and directly on a value whose type has
  the trait, and `Ord.cmp(a, b)` works in the qualified form. A method on the
  type itself wins over the prelude method. The call is recorded in
  `trait_call_sites`; the interpreter runs a built-in or derived type's
  prelude method natively (`native_prelude_method`), through the same `==` and
  `<` the operators use, so every numeric width, string and derived struct
  behaves as it does with the operators.
- **Operators on a type parameter.** `==` and `!=` need `PartialEq`, and the
  ordering operators need `PartialOrd`, in the parameter's bounds (`Eq` and
  `Ord` imply them). Without it the operator is `TYPE-131`
  (`OperatorNeedsBound`), at the expression. Operators on a concrete type are
  unchanged: `==` on a struct without `PartialEq` stays reference identity.
- **Hand-written impls** of the five traits were `TYPE-129` in this part; S2b
  accepts them.
- **Not in part 1:** `Hash`, `Hasher`, the `Dictionary` key requirement
  (part 2, below); dispatch to hand-written impls (S2b).
- **Limits recorded:** an enum is `PartialEq` and `Eq` whatever its payload
  types are (its comparison is structural at run time); a struct is the
  traits it derives, nothing else.

### What S2a part 2 settled

- **`Hasher` is an ordinary struct in the prelude**, with one field
  (`state: u64`), an associated `new()` and a `finish()`:
  `let h = Hasher.new()`, `x.hash(h)`, `h.finish()`. `Hash` is a prelude trait
  with `hash(self, state: Hasher) void`. It depends on `Hasher`, `Eq` and
  `PartialEq` for shadowing (a program that declares `Hasher` loses `Hash`).
- **`hash` is native.** It folds `Value::compute_hash` of the receiver into
  `state`, rotating the old state first, so hashing `a` then `b` differs from
  `b` then `a`, and the same values in the same order always give the same
  `finish()`. Raw hash values are not part of the language contract: they come
  from the standard library's `DefaultHasher` and can change with the
  toolchain, so tests and fixtures compare hashes and never print them.
- **What is `Hash`:** integers of every width, `string`, `bool` and `char`; a
  tuple or optional when its elements are; a struct that derives `Hash`; an
  enum. Not `float`, `double`, `f32` or `f64` (NaN), and no other built-in
  type. `Hash` implies `Eq` and `PartialEq` inside a body, matching the derive
  prerequisite rule (`@derive(Hash)` needs `Eq`, `TYPE-117`).
- **`Dictionary` keys must be `Hash`** (which implies `Eq`). One obligation,
  `Hash`, because every `Hash` type is also `Eq`; the diagnostic is the usual
  `TYPE-126`. It is raised where a dictionary type is written or created:
  a `Dictionary<K, V>` annotation (in a signature, a field, a `let` or nested
  in another type), `Dictionary.new()`, and the first key handed to
  `set`, `get` or `contains_key` of a dictionary whose key type is not written
  anywhere. A key type that is written is checked where it is written, not
  again at each call. An unannotated dictionary that never receives a key is
  not an error.
- **One mistake, one diagnostic.** `let d: Dictionary<float, int> =
  Dictionary.new()` names the key twice on one line; a key mistake is reported
  once per line and key type. The same mistake on two lines is two diagnostics.
- **Aliases.** `type Pairs<K, V> = Dictionary<K, V>` cannot declare `K: Hash`
  (bounds on alias parameters are not built), so nothing is checked where an
  alias is declared; every use is checked after expansion, so `Pairs<float, int>`
  is `TYPE-126` at the use.
- **Generic keys.** `fn f<K>(d: Dictionary<K, int>)` is `TYPE-126` for the
  unbounded `K`; `K: Hash` is accepted.
- **Hand-written `impl Hash`** was `TYPE-129` in this part, with the other five;
  S2b accepts it.
- **Not covered:** the runtime `Dict` is still a `Vec` of pairs searched by
  `equals`, so hashing has no consumer yet and the requirement is a static
  contract; `Set<T>` elements and `Linqerizer.group_by` keys are not checked.

### What S2b settled

- **Hand-written impls of the six prelude traits are accepted** and checked like
  any trait impl: `TYPE-122` to `TYPE-125` cover the trait name, a missing
  method, an unknown method and a signature mismatch. The methods with defaults
  (`ne`, `lt`, `le`, `gt`, `ge`) are inherited unless the impl overrides them.
- **`@derive(X)` together with `impl X for T` is `TYPE-128`**, reported at the
  impl: the derive and the impl are two sources of the same impl.
- **An impl needs its supertraits (`TYPE-132`, `MissingSupertraitImpl`).**
  `impl Ord` needs `PartialOrd` and `Eq` (so `PartialEq`), `impl PartialOrd`
  and `impl Eq` need `PartialEq`, `impl Hash` needs `Eq`. A derive or a
  hand-written impl satisfies a supertrait. One diagnostic per impl, at the
  impl, naming the first missing supertrait in that chain, because the rest
  follow from it.
- **Impls for built-in types stay `TYPE-129`** ("a type that is not a struct or
  enum"), as do impls for generic types and generic traits, until S3.
- **What a type satisfies now counts hand-written impls.** A struct or enum
  satisfies a prelude trait by a derive, by the automatic rule (an enum is
  `PartialEq`, `Eq` and `Hash`) or by an impl. An enum may replace its automatic
  `PartialEq`, `Eq` or `Hash` with a hand-written one and may order itself with
  `impl PartialOrd`. The ordering operators accept a type with `impl PartialOrd`
  or `impl Ord`. Before impls are registered a named type's status is undecided
  rather than false, so a signature that names a type whose impl comes later in
  the file waits for registration instead of failing.
- **Runtime dispatch.** `==` calls the impl's `eq`. `!=` calls the impl's `ne`
  (its override, or the prelude default). `<`, `<=`, `>` and `>=` call the
  impl's `lt`, `le`, `gt` and `ge`, so an override is honored. The same rule is
  used by `contains` on a list, queue, stack and inline list, by the dictionary
  methods `get`, `set` and `contains_key` and by indexing a dictionary (read and
  assign), by the Linqerizer's `order_by` and `group_by`, and by `x.eq(y)`,
  `x.cmp(y)` and the other prelude methods called on a derived struct.
- **The rule applies inside values.** A derived struct compares field by field,
  a tuple element by element, an enum payload by payload and a `Unique` through
  its content, each part through its own impl when it has one. `hash` and
  `clone` follow the same rule: a derived `Hash` folds a field in through the
  field's `hash`, so values that are equal hash alike, and a derived `Clone`
  calls the `clone` of a field, element or payload, in lists, dictionaries,
  queues, stacks, tuples, enums and `Unique`. `Shared` still aliases.
- **One module.** `interpreter/eval/user_ops.rs` holds `values_equal`,
  `values_cmp`, `user_comparison`, `contains_value`, `dict_position`,
  `dict_op_user`, `values_clone` and `hash_value`. `Value::equals`,
  `Value::partial_cmp`, `Value::deep_clone` and `Value::compute_hash` remain the
  structural fallbacks and take no interpreter. Only a struct, enum, tuple or
  `Unique` operand takes the slow path.
- **Unordered results.** `a.lt(b)` is `false` when `partial_cmp` gives `null`.
  The operator form `a < b` on a derived struct whose field has no order panics
  with "comparison between incomparable values", as the operators already did
  for incomparable values before the traits existed. The two forms disagree; see
  `docs/PARKED_IDEAS.md`.

### What S3a settled

- **Syntax.** `trait B: A + C { .. }`. The supertraits follow the name and any
  generic parameters and are written like a bound on a type parameter
  (`T: A + C`). Each was a plain name in S3a, so a supertrait with arguments
  (`trait B: A<int>`) was a parse error until S3b. The parser records each name
  with its own span, so a diagnostic about a supertrait points at the name.
- **An impl needs the impls beneath it (`TYPE-132`).** The rule built for the
  prelude in S2b now covers every trait: `impl B for T` needs an impl of each
  trait `B` builds on, directly or through others. One diagnostic per impl, at
  the impl, naming the first missing trait in the chain. The chain is the trait's
  supertraits in the order written, then theirs level by level, so an `impl Ord`
  with nothing beneath it names `PartialOrd`. A link missing further up is
  reported at each impl that depends on it. The suggestion is `@derive(X)` or an
  impl when the missing trait is one that can be derived, and an impl otherwise.
- **A bound implies its supertraits, one way.** `T: B` puts `A` in force inside
  the body, so `x.a_method()` resolves, and `T: B` satisfies a `T: A`
  requirement at a call. The reverse does not hold: a `T: A` does not satisfy
  `T: B` (`TYPE-126`). Declared bounds stay as written. A diamond is one trait to
  the body: `Base` reached through `Left` and `Right` is one entry, so a method
  of `Base` is not ambiguous.
- **A default body sees its supertraits.** Inside a default method of `B`, `self`
  is bounded by `B` and by everything `B` builds on. `self.a_method()` resolves,
  and for a prelude supertrait the operators work (`trait Scored: PartialOrd`
  allows `self > other` in a default).
- **Names.** A supertrait that is unknown, or names something that is not a
  trait, is `TYPE-122`, reported at the name. A repeated name is ignored.
  Declaration order does not matter: a trait may build on one declared later.
- **A trait cannot build on itself (`TYPE-133`, `SupertraitCycle`)**, directly or
  through others. One diagnostic per cycle, at the supertrait name that closes
  it, with the cycle as written (`A -> B -> A`). A trait that only leads into a
  cycle is not reported, and a diamond is not a cycle.
- **The prelude declares its own supertraits** in its source: `trait Eq:
  PartialEq`, `trait PartialOrd: PartialEq`, `trait Ord: PartialOrd + Eq`,
  `trait Hash: Eq`. Sema's table of prelude supertraits is gone; only the list of
  prelude names remains. Shadowing reads the declarations: a prelude item depends
  on its supertraits plus the types its signatures mention (`Ordering` for
  `PartialOrd` and `Ord`, `Hasher` for `Hash`), and a program that declares a
  name loses everything that depends on it, as before.
- **Not changed.** The `@derive` prerequisite check (`DeriveRequiresOther`) still
  works from the derive list, not from the declared supertraits; the two agree
  for the six prelude traits. Generic traits, associated types, impls for
  generic types and for built-in types, and the two bound limits are still
  `TYPE-129`.
- **Runtime.** No change. A call through a bound resolves to the supertrait's
  method and runs the implementing type's impl, and a default of `B` that calls
  `self.a()` runs whatever the type provides for `A`.

### What S3b settled

- **Syntax.** `trait Convert<T> { .. }`, `impl Convert<int> for Celsius { .. }`,
  bounds with arguments (`T: Convert<int>`, `T: Convert<U>`) and supertraits with
  arguments (`trait Wide<T>: Convert<T>`, `trait Narrow: Convert<int>`). One shape,
  `TraitBound { name, args, span }`, serves a parameter's bound, a supertrait and
  the impl header (`ImplBlock.trait_args`). A bound's arguments that end a
  parameter list close with one `>>` token (`T: Convert<int>>`), which the
  parameter-list parser now reads as two closes.
- **A type has one impl of a trait.** The arguments are a property of the pair
  (trait, type). A second impl of the same trait for a type is `TYPE-128` whatever
  its arguments. This was chosen over several impls because generics are erased
  at run time: the interpreter dispatches on the value's type name and a trait
  name, so inside generic code a bound such as `T: Convert<U>` could not pick
  between two impls of one type. Allowing several is a relaxation for later (it
  needs the arguments at run time, or a restriction of bounds to concrete
  arguments, and inference that picks the impl from the expected type). Nothing
  built here prevents it. The interpreter needed no change.
- **What the arguments mean for an impl.** The impl's method signatures are
  compared with the trait's with the trait's parameters replaced by the impl's
  arguments (`fn convert(self) int` for `Convert<int>`). The argument count is
  checked (`TYPE-108`), a bound on the trait's own parameter (`trait Holder<T:
  Eq>`) is checked at the impl (`TYPE-126`), and a default method of a generic
  trait is checked once in the trait's scope, where `Self` implements the trait
  applied to its own parameters.
- **What a bound's arguments mean.** Inside a body, `T: Convert<int>` makes
  `x.convert()` return `int`, and a method that takes the trait's parameter takes
  `int`. At a call, the bound is met when the argument's type has an impl of the
  trait and the impl's arguments are the bound's. An argument that is still an
  inference variable (`fn widen<T: Convert<U>, U>`) is decided by the impl as soon
  as the type is known, so `U` is `int` for a `Celsius`, and using the result as a
  `string` is an ordinary type mismatch. A type parameter meets a bound only when
  declared with the same arguments. The message names the arguments (the trait
  `Convert<string>` is not implemented for `Celsius`).
- **Generic supertraits carry their arguments.** A supertrait's arguments are
  written in the sub-trait's scope (its parameters, and `Self`), and a bound on the
  sub-trait gives the supertrait with the arguments worked out: `T: Wide<int>` also
  gives `Convert<int>`. `impl Wide<int> for X` needs `impl Convert<int> for X`; an
  impl with other arguments does not count, and `TYPE-132` names the supertrait
  with its arguments. A cycle is `TYPE-133` whatever the arguments.
- **Conflicting bounds (`TYPE-134`).** Two bounds on one parameter that apply the
  same trait to different arguments cannot both hold, since a type has one impl,
  so the second is reported and the first stays in force. The same trait with the
  same arguments twice is one bound.
- **Arguments wait for the aliases.** A bound's or supertrait's arguments are
  types, so they are converted after the type aliases are expanded
  (`fill_generic_bound_args`); the names are validated earlier. Scopes built before
  that pass convert them again silently, so an error is reported once, at the
  declaration.
- **Not changed.** The prelude traits take no arguments (`Eq<int>` is `TYPE-108`).
  Associated types, and impls for generic types and for built-in types, are still
  `TYPE-129`. The two bound limits that stayed `TYPE-129` after S3b were built in
  S3c.

### What S3c settled

- **Method generics are a feature, not a bound limit.** Before S3c a method's own
  generic parameters were not scoped in sema: their types were unknown, so
  `fn pick<U>(self, x: U) U` accepted `let r: string = b.pick(5)` with no bound
  involved, and a bound on one was `TYPE-129`. S3c scopes them, instantiates them
  per call, enforces their bounds and checks generic methods in traits. The
  interpreter needed no change, since generics are erased at run time.
- **Numbering.** A method's own parameters follow the parameters of the
  declaration around the method. In `struct Pair<T>` the struct's `T` is `Param(0)`
  and the method's first own parameter is `Param(1)`. In a trait the trait's
  parameters come first, then the abstract `Self`, then the method's own. An
  `extend` or `impl` block starts after the target's arity (its own names are not
  bound), and an impl of a trait starts at zero. `MethodShape` carries
  `MethodGenerics { base, own }`, one entry per own parameter with its name and its
  bounds as written.
- **Every call chooses its own types.** A call gets a fresh inference variable for
  each own parameter after the receiver's arguments are substituted. This covers an
  instance call, an associated call (`Box.make(x)`), a call through a bounded type
  parameter and the qualified form `Trait.m(value, ..)`. Each bound is an
  obligation settled after the arguments are unified, so a bound argument the impl
  decides (`fn conv<U: Convert<V>, V>`) is learned from the call. It is reported at
  the first argument whose declared type is that parameter, and at the call when
  there is none, as for a generic function.
- **Inside the body.** The own parameters are in scope with their bounds and the
  traits those build on, so `x.show()` works under `U: Show` and under `U: Loud`
  when `trait Loud: Show`. A method called on an unbounded own parameter is
  `TYPE-130`, an operator on one is `TYPE-131`, and a result of the wrong type
  names the parameter (found `U`). The bound names, the argument counts and
  conflicting bounds are checked once at the declaration (`TYPE-122`, `TYPE-108`,
  `TYPE-134`), the same checks a generic function's bounds get.
- **Generic methods in traits.** A required method or a default method may declare
  generic parameters. An impl repeats the method exactly: the same number of own
  parameters and the same bounds on each, as a set in any order and with the same
  trait arguments. The names may differ. Anything else is `TYPE-125`, and its
  signature text now writes the generics (`fn<U: Show>(self, U) U`). When the
  trait's parameters and `Self` are replaced for an implementing type, the method's
  own parameters are renumbered from zero, which is where the impl's method has
  them, so one comparison and one call path serve both.
- **Bounds on a type alias parameter.** Every use of the alias raises its bounds on
  the arguments: with `type Shown<T: Show> = W<T>`, `Shown<int>` is `TYPE-126` at
  the use, though `W` itself asks nothing of `T`. This holds through another alias
  and for a parameter of an enclosing generic function, which needs the same bound.
  The bound's trait arguments are converted after the aliases are expanded, as in
  S3b, so a use inside another alias's own definition checks the trait and not yet
  its arguments.
- **Wording.** A type parameter is written by its name while its scope is in force,
  and the abstract `Self` as `Self`. After the scope ends (an obligation settled
  once the signatures are collected) it still prints as `<generic param #N>`; this
  is parked.
- **For S6.** A trait with generic methods has no single vtable entry per method, so
  it is not usable as `dyn Trait` under the rule Rust applies. S6 took that rule (see
  "What S6 settled").

### What S3d settled

- **Scope.** The 21 primitive types under every spelling (`int`, `long`, `i64`,
  `isize`, `short`, `byte`, `float`, `f32`, `double`, `f64`, `bool`, `char`,
  `string`, and so on), tuples and arrays, for `impl Trait for T` and for `extend
  T` (and an inherent `impl T`). A struct or an enum is unchanged. A collection, an
  optional, a slice or a function type stays `TYPE-129`, for `impl` and now also for
  `extend`, which used to pass sema and panic at run time.
- **One definition per built-in type.** A built-in type that an `impl` or `extend`
  names gets a `DefKind::BuiltinType` definition, one per type as a diagnostic
  writes it (`int`, `(int, string)`, `[3]int`). Every table keyed by a definition
  (methods, `trait_impls`, `trait_impl_args`, the ambiguity tables) then serves
  built-in types as it serves structs, so bounds, qualified calls, supertraits,
  default methods, generic traits and generic methods needed no second
  implementation. An alias of a built-in (`type Score = int`) is that built-in.
- **Sema keeps the types apart, the run time cannot.** `int`, `long`, `i64` and
  `isize` are four types to sema, and an impl for `int` does not make `long`
  implement the trait. At run time they are one kind of value (`Value::Int`), so a
  call can only find an impl by the kind. The key is `Value::impl_key`: `int`
  (for `int`, `long`, `i64`, `isize`, `short`), `u32` (`uint`, `u32`, `ushort`),
  `u64` (`ulong`, `u64`, `usize`), `i8` (`i8`, `byte`), `u8` (`u8`, `ubyte`),
  `i16`, `i32`, `u16`, `float` (`float`, `f32`), `double` (`double`, `f64`),
  `bool`, `char`, `string`; a tuple is `tuple<arity>` and an array is `List`, the
  kind it shares with `List<T>`. A trait has one impl per key. The second is
  `TYPE-128` and its message says why (two types of one kind, tuples with the same
  number of elements, arrays of every length and element type).
  `ast::types::builtin_impl_key` writes the same strings from the type as written,
  and a unit test pins that the two agree.
- **Prelude traits.** A prelude trait may be written by hand only where the
  built-in type does not have it natively (`prelude_status_native`): `Eq`, `Ord`
  and `Hash` for `float` and `double`; `PartialOrd` and `Ord` for `bool` and
  `char`; the ordering traits for a tuple and every trait for an array. Where the
  type has it natively the impl is `TYPE-128` ("the built-in type already
  implements it"). A hand-written impl needs the traits it builds on
  (`Hash` for `double` needs `Eq`, `TYPE-132`). Once one exists, an ordering
  operator accepts the type (`false < true` is `TYPE-118` without `PartialOrd`
  for `bool`), and comparison, hashing and cloning of built-in values look for the
  impl (`builtin_prelude_impls`, so a program without one keeps the fast path).
- **Calls.** A native method wins (strings, tuples and lists have them), then a
  method an `extend` or `impl` block gave the type (an inherent method beats a trait
  method, two traits with one name are `TYPE-127`, the qualified form reaches a
  trait's), then a prelude method. A primitive has no native methods, so a method
  that is none of those is `TYPE-104`, which used to pass sema and panic at run
  time, and a function without `self` is not a method. In the body of an impl or
  an `extend` block `self` and `Self` are the built-in type.
- **Integer literals inside a tuple** that are still undecided count as `int` when
  the impl is looked up, so `let p = (1, "a")` finds the impl for `(int, string)`.
- **Not built.** No expression produces a `[N]T` value (an array literal is a
  `List<T>` and does not unify with `[3]int`), so an array impl is checked and its
  methods can be called on a parameter of that type but never run; whether a
  literal should check against `[N]T` is a language question. A function without
  `self` in an `extend` block for a primitive can be declared but not called
  (there is no path syntax for `int`). The generic built-ins wait for impls of
  generic types.

### What S3e settled

- **Scope.** `impl<T: Show> Show for Box<T>`, `impl Show for Box<int>`,
  `impl<K: Hash, V> Size for Dictionary<K, V>`, an inherent `impl<T> Box<T> { .. }`
  and `extend<T> Box<T> { .. }`. The targets are a generic struct or enum and the
  generic built-ins `List`, `Dictionary`, `Queue`, `Stack` and `InlineList`; an alias
  of one of them is that head. The parser reads the parameters after `impl` and
  `extend` (`ImplBlock.generic_params`, `ExtendDecl.generic_params`, empty when
  absent).
- **A pattern per block.** A block with parameters, or for a generic head with
  arguments written, is analysed once in `collect_signatures`
  (`sema/type_infer/impl_patterns.rs`, `ImplPattern`, stored by the block's span).
  Blocks for anything else (a primitive, a tuple, an array, a struct or enum
  without parameters, `extend Box { .. }` on a generic struct) keep the older paths
  untouched.
- **Numbering by place.** Each impl parameter must occupy exactly one top-level
  argument of the head and is numbered by that position: in `impl<X, Y> Tr for
  Pair<Y, X>` the parameter `X` is the second parameter of `Pair`. Every method
  shape then stays in the head's own numbering, so a call substitutes the
  receiver's arguments exactly as for a method written inside the struct, and the
  tables keyed by a definition (`struct_methods`, `trait_impls`, `trait_impl_args`,
  the ambiguity tables) serve generic types without a second implementation. A
  built-in head gets one synthetic definition per head (`DefKind::BuiltinType`,
  keyed by the head's name).
- **What the impl says about the arguments is a guard.** `ImplGuard` holds the
  concrete argument written at a position (`Box<int>`) and the bounds written on a
  parameter. It is attached to every method the block supplies and to the
  `(trait, head)` pair, and only when there is something to check. A call of a
  method whose concrete position disagrees with the receiver is `TYPE-104` (the
  receiver has no such method), a bound the receiver's argument lacks is
  `TYPE-126` at the call, and `bound_status`, `bound_args_status`, `trait_args_of`,
  `type_implements` and the prelude status all consult the guard, so a conditional
  impl is also a conditional answer to a bound (`Box<Plain>: Show` fails when
  `Plain` has no `Show`). An argument that is still an inference variable is bound
  by a concrete position: the only impl decides it.
- **Bounds on impl parameters.** `impl<T: Show> Show for Box<T>` makes the impl
  conditional and puts `T: Show` in force in the bodies. A bound the head itself
  declares (`struct Need<T: Show>`) must be restated on the parameter (`TYPE-126`
  naming the parameter, suggesting a bound), is checked on a concrete argument, and
  holds inside the block. A `Dictionary` key position needs `Hash`.
- **What is not accepted (`TYPE-129`).** A parameter repeated (`Pair<T, T>`) or
  nested (`Box<List<T>>`), a parameter the target does not use, a blanket impl
  (`impl<T> Tr for T`), an optional, a fallible or a task (a method call on `T?`
  resolves on the payload and the value is the inner value at run time, so these
  are transparent wrappers), a `Set`, a slice, a function type, and `Pool` and
  `Handle`. A generic head written without arguments in a trait impl is `TYPE-108`;
  in `extend` and an inherent `impl` it keeps its earlier meaning (every instance,
  the head's own parameters, not named).
- **Pool and Handle are not targets yet.** A written `Pool<T>` or `Handle<T>`
  is not a type sema understands (it converts to the unknown type; a `Pool` value
  is only made by `with pool<T>`), so there is nothing for an impl to be checked
  against. They were agreed as targets while the design was open; this fact was
  found while building and they are reported until written Pool and Handle types
  exist.
- **Generics are erased at run time.** A trait has one impl per head whatever the
  arguments, so `impl Show for Box<int>` together with `impl Show for Box<string>`
  is `TYPE-128` with a note, as are a generic and a concrete impl of one trait. A
  method name has one inherent definition per head (`TYPE-129`), because a call
  cannot tell `Box<int>` from `Box<string>`; the same rule now covers built-in
  types that are one kind of value at run time (`extend int` and `extend long` both
  defining `tag` used to pass sema and call whichever block registered last).
- **Run time.** An impl for a user struct or enum needed no change: it is
  registered under the type's name. The five built-in heads are keyed by their
  names (`List` shared with arrays and slices, `Dictionary`, `Queue`, `Stack`,
  `InlineList`) in `ast::types::builtin_impl_key` and `Value::impl_key`, and the
  unit test that pins the two covers them. An array impl and a `List<T>` impl of one
  trait overlap (`TYPE-128`). A native method still wins over a block's method of
  the same name.
- **Prelude traits on collections.** A hand-written `PartialEq`, `Eq`,
  `PartialOrd`, `Ord`, `Hash` or `Clone` for a `List`, `Dictionary`, `Queue`,
  `Stack` or `InlineList` is `TYPE-129`: the run time compares, hashes and clones a
  collection by identity, and the operators do not consult user impls for one, so
  an impl would say something `==` does not do. A prelude impl for a user generic
  struct is accepted and drives the operators.
- **Diagnostics.** A type in a message is written as the block writes it
  (`Box<T>`, `List<int>`), and an unsatisfied bound on a type parameter now
  suggests declaring the bound instead of adding an impl (`UnsatisfiedBound`
  carries `is_param`). An inference variable inside a reported type is replaced by
  what it was solved to (`Box<Plain>`, not `Box<?T9>`).
- **Not built.** Associated types and blanket impls (deferred as decided), nested
  impl patterns, impls for the transparent wrappers, for `Set`, slices, function
  types, `Pool` and `Handle`, and prelude traits for collections.

### What S5a settled

Decided 2026-10-27, one delivery per language-item trait, in this order: `Display`,
then `Iterator<T>`, then operator traits. All three follow the S4 rule for prelude
traits: `@tier(low)`, exact-match impls, so the feature works at any tier.

- **`Display` is a prelude trait with one method, `fn to_string(self) string`.** The
  scalar types (`int` and the sized integers, `float` and `double`, `bool`, `char`,
  `string`) satisfy it natively, so `T: Display` accepts them and `5.to_string()`
  works. A struct or enum implements it by hand (`TYPE-126` when a bound is missing
  its impl). `@derive(Display)` is not a derive. A type with no impl still prints
  structurally; `Display` only overrides that.
- **Only a struct or an enum can have a hand-written `Display`.** An impl for a scalar
  is the usual duplicate (`TYPE-128`), and an impl for a collection, an array or any
  other built-in type is `TYPE-129`: the runtime prints those element by element and
  would never call it. (An array impl was accepted by an early build, and then fired for
  every list printed; the rule exists because of that.)
- **Where it applies.** `println`, `print`, `log`, `to_string`, an interpolation hole
  `{x}` (with width and alignment), and the messages of `assert` and `panic`, for a value
  at any depth inside a struct, an enum payload, a tuple, a list, a dictionary (keys and
  values), a queue, a stack, an inline list, or `Unique`, `Shared` and `SyncShared`.
  `{x:?}` is the structural Debug form and never calls a user's `Display`.
- **How.** `Value`'s formatting takes no interpreter, so it cannot call a user method.
  `interpreter/eval/display.rs` replaces, before the existing formatter runs, every value
  whose type has a hand-written `Display` by the string its `to_string` returns. A string
  prints as its own text, so the shape of the output does not change, and the formatting
  code is not duplicated. It runs only when an `impl Display` was registered
  (`has_user_display`), so a program without one formats exactly as before. The call goes
  through `user_trait_fn`, the route a hand-written `eq` already takes.
- **Field order.** A named struct printed its fields in the order of a hash map, which
  changed from one run to the next. It now prints them in declaration order (the
  `field_order` the value already carried), an anonymous object in the order written, and
  an enum's struct variant sorted by name, because the runtime keeps no declaration order
  for a variant's fields. Debug uses the same order.
- **A program's own trait named `Display`** takes the name and the prelude one is dropped
  (the same rule as the other prelude names); printing stays structural unless its
  `to_string` is the prelude's.
- **Tier.** The trait is `LOW`, so an impl that writes no tier is `LOW`, a written
  `@tier(high)` is `TIER-016`, and the body may call only `LOW` code, read no `static` and
  build no collection, the same cost as the other prelude impls.

### What S5b settled

Decided 2026-11-01.

- **`Iterator<T>` is a generic prelude trait with one method, `fn next(self) T?`**, `@tier(low)`
  like the other language-item traits. Nothing satisfies it natively (a `List` is iterable,
  not an iterator), so to bounds and impls it is an ordinary generic trait (`I: Iterator<int>`,
  `impl Iterator<int> for Counter`, `impl<T> Iterator<T> for Once<T>`) and only a `for` loop
  knows it by name. Type inference finds it as the prelude's `Iterator` (`iterator_trait`), so a
  program's own trait named `Iterator` takes the name and the loop then ignores it.
- **The loop.** `for x in value` over a struct or enum with the impl calls `next` until it
  returns `null`, binding each item. It is lazy, so an endless iterator is stopped by `break`,
  and it advances the value itself: a struct is shared, so after the loop (or after a `break`)
  it stands where `next` left it, and a later loop resumes. No `Clone` is needed. An enum value
  cannot change, so an enum iterator can only end at once or never. The loop calls the trait's
  `next`, not an inherent method of the same name.
- **Only a struct or an enum can have a hand-written `Iterator`.** An impl for any built-in
  type, a scalar included, is `TYPE-129`: a loop walks a built-in value itself and would never
  call the impl. No scalar satisfies `Iterator` natively, so unlike `Display` there is no
  `TYPE-128` case.
- **An optional item type is `TYPE-129`** (chosen over letting `null` end the loop anyway). `null`
  is the end marker and an optional is transparent at run time, so `Iterator<int?>` could not
  tell a `null` item from the end. It is reported at the impl, and at the loop when an item
  becomes optional through a generic argument (`Once<int?>`) or a bound (`I: Iterator<int?>`);
  an impl already reported at its own line is not reported a second time at the loop.
- **`Queue`, `Stack` and `Dictionary` become iterable** (chosen over rejecting them). A queue is
  walked front to back, a stack bottom to top (the order it prints in; C# enumerates a stack
  top first), and a dictionary as `(key, value)` pairs in insertion order, so `for (k, v) in d`
  works. Each loop walks a snapshot, so changing the collection inside the loop does not change
  what it visits. A single loop variable over a dictionary is typed as a pair, `(K, V)`, but the
  names in `(k, v)` are not typed one by one (the gap described on `record_binding`), so sema
  does not check `k` and `v`.
- **A `for` over anything that cannot be walked is `TYPE-135`.** The run time can walk a `List`
  or array, a `Queue`, a `Stack`, a `Dictionary`, an `InlineList`, a `Pool`, a string, a tuple,
  a range and a struct or enum with the impl. Ownership and reference wrappers, `T?` and `T!`
  are looked through, and a type parameter can be looped over when it has an `Iterator` bound.
  Everything else (a scalar, an integer literal, a function, a `Linqerizer`, a struct or enum
  with no impl, an unbounded type parameter) used to pass sema and panic when the loop ran. A
  value whose type is not known yet is not an error, and a loop over an expression that already
  failed adds no diagnostic (it used to panic the type checker).
- **Tier.** `next` is `LOW`, so an impl that writes no tier is `LOW`, a written `@tier(high)` is
  `TIER-016`, and the body may call only `LOW` code, read no `static` and build no collection,
  the cost already noted for the other prelude traits. The implicit `next` call needs no tier
  check: every `next` is `LOW` and a `LOW` method can be called from any tier.
- **Not built.** An `Iterable` trait (a collection that hands out an iterator) needs associated
  types. The items of a string and of a tuple in a `for` stay untyped. A loop over a `null`
  optional collection panics at run time, as a method call on `null` does. `Set` has no
  constructor, so a loop over one never runs.

### What S5c settled

Decided 2026-11-03.

- **The traits.** Ten binary traits, `Add`, `Sub`, `Mul`, `Div`, `Rem`, `BitAnd`, `BitOr`,
  `BitXor`, `Shl` and `Shr`, each written `Trait<Rhs, Out>` with one method (`add`, `sub`, `mul`,
  `div`, `rem`, `bit_and`, `bit_or`, `bit_xor`, `shl`, `shr`), and two unary traits, `Neg<Out>`
  (`neg`) and `BitNot<Out>` (`bit_not`). There are no associated types, so the right operand and
  the result are both type parameters (`impl Mul<double, Vec2> for Vec2`). All are
  `@tier(low)`, like the other language-item traits, so an impl that writes no tier is `LOW`
  and a written `@tier(high)` is `TIER-016`. A `LOW` method can be called from every tier, so
  the implicit call has no tier check to make, the same as the `next` call of S5b. Logical `!`
  and `not`, the comparison operators (S2) and `..` have no operator trait.
- **Several impls per type (chosen over one impl per type).** `Vec2 * double` and `Vec2 * Vec2`
  are both ordinary game math, so a type may implement one operator trait once for each kind of
  right operand. The kind is what the run time can tell apart: a struct or enum by its name, a
  built-in by its run-time kind, which is erased for generics. Two impls whose right operands
  are one kind overlap (`TYPE-128`): `Mul<double, V>` twice, `Box<int>` with `Box<double>`,
  `int` with `long`. A unary trait has one impl. This is the one place a trait has more than
  one impl per type; the rule of S3b stands for every other trait.
- **A number or a string on the left (`2.0 * v`).** `impl Mul<Vec2, Vec2> for double` is
  allowed, and only reached when the right operand is a struct or an enum, so `double * double`
  keeps the run time's own arithmetic. This is a narrow exception to the rule that a built-in
  type that satisfies a prelude trait natively cannot have it implemented by hand (`TYPE-128`),
  and to the rule that only a struct or an enum has a hand-written impl of a language-item
  trait. Any other built-in left operand (`impl Add<int, int> for int`, a collection, a tuple)
  is `TYPE-129`, as is a bare type parameter as the right operand (`impl<T> Mul<T, Box<T>> for
  Box<T>`): impls are told apart by the right operand's run-time kind, which a type parameter
  does not have.
- **Numbers keep the run time's arithmetic and satisfy the traits natively.** Integers of every
  size and the floats satisfy `Add`, `Sub`, `Mul`, `Div` and `Rem`; `string` satisfies `Add`
  only; the integers satisfy the bitwise traits and `BitNot`; the signed integers and the floats
  satisfy `Neg` (an unsigned number does not, the run time rejects it). So `T: Add<T, T>` accepts
  `int`, `double`, `string` and any impl, and `a + b` on two numbers is unchanged. Sema's
  `native_operator` and the run time's `eval_binop` each list what numbers support and have to be
  kept in step by hand.
- **An operator on an unbounded type parameter is `TYPE-131`** (it passed sema and worked only
  for numbers and strings before). The check looks for a bound of the operator's trait; the
  suggestion shows the bound with its arguments (`<T: Add<T, T>>`). With a bound whose right
  operand is another one, the operator is `TYPE-136`. A parameter can be bounded once per right
  operand (`T: Mul<double, T> + Mul<T, T>`); `TYPE-134` now needs one right operand with two
  results.
- **Compound assignment.** `a += b` means `a = a + b` (the C# rule, chosen over `AddAssign`
  traits), so an impl always builds a new value, and the result must have the type of `a`.
  Sema used to read `a += b` as a plain assignment and ignore the operator, so `v *= 2.0` on a
  `Vec2` was a type mismatch and `a += b` on two structs passed and panicked.
- **Run time.** The impls are filed by `(left type, trait, right operand's kind)`
  (`operator_impls`), only for the traits the prelude declares in this program (a program trait
  named `Add` takes the name, and its operator is then unchecked and not dispatched). A binary
  operator, a unary operator and a compound assignment try the table first when a struct, an
  enum or an ownership wrapper around one is an operand, and fall back to the run time's own
  arithmetic otherwise, so a program with no operator impl pays one emptiness check. Inside a
  generic body the impl is found by the kind of the values, which is also how an expression
  whose static type is not known is dispatched. `a.add(b)` through a bound goes by the right
  operand's kind too, and runs natively for a number.
- **Result types.** The result of `a * b` is the impl's `Out`, substituted for a generic
  receiver. A right operand that is not known yet is decided by the only impl, and with several
  impls the answer waits for the run time. An integer literal fits an integer impl only
  (`v * 2` against `Mul<double, V>` is `TYPE-136`) and takes the type of the impl it picks
  (`Mul<u32, V>`).
- **`TYPE-136`** reports an operator with no impl behind it, naming the pair, and the right
  operands the left type does have impls for.
- **Not built.** `Index` (`a[i]`, `a[i] = v`) is slice S5d. There is no `AddAssign` family. The
  explicit form `a.mul(3.0)` on a type with several impls of one trait resolves against the first
  impl, in sema and at run time (the operator form finds the right one). Operators on `List`,
  `Dictionary`, tuples and other built-in left operands cannot be implemented, and `list + list`
  or `bool & bool` is `TYPE-139` (thirty-first delivery) instead of a run-time panic.

### What S5d settled

Decided 2026-11-05.

- **Two traits (chosen over one trait with both methods, and over a write trait that requires
  the read trait).** `Index<Idx, Out>` has `fn index(self, idx: Idx) Out` and
  `IndexSet<Idx, Val>` has `fn index_set(self, idx: Idx, value: Val)`; both are `@tier(low)`
  like the other language-item traits, and the methods are named `index` and `index_set` (chosen
  over `get` and `set`, which user containers usually define as their own methods). A type may
  have only the read side or only the write side. `a[i]` calls `index`, `a[i] = v` calls
  `index_set` and needs no read impl, and `a[i] += v` reads through `Index`, applies the
  operator, and writes through `IndexSet`, so it needs both and the written type has to be the
  one that was read.
- **One impl per kind of index.** The same rule as the operator traits (S5c): `Index<int, T>`,
  `Index<string, T>` and `Index<(int, int), T>` coexist for one type, impls whose index is one
  kind of value at run time overlap (`TYPE-128`), and the impls are filed by `(type, trait,
  kind of the index)` with the operator impls. An impl for a built-in type, any of them, is
  `TYPE-129` (a number on the left with a struct on the right, which S5c allows for the
  operators, makes no sense for an index), as is a bare type parameter as the index.
- **Built-ins satisfy the traits natively.** A `List`, an array, a slice and an `InlineList`
  satisfy `Index<int, T>` and `IndexSet<int, T>`, a `Dictionary<K, V>` satisfies both with
  `(K, V)`, and a string satisfies `Index<int, char>` only. So `C: Index<int, int>` accepts a
  `List<int>` and any struct with the impl, and `c.index(i)` and `c.index_set(i, v)` through a
  bound run natively for the built-ins and by the index's kind for a struct. An index on an
  unbounded type parameter is `TYPE-131` (it was accepted, typed as an unknown, before).
- **The built-ins are typed (chosen with the negative-write fix).** The index of a `List`,
  array, slice, `InlineList`, string or tuple has to be an `int` (`long`, `i64` and `isize` are
  the same kind of value; any other integer type is a mismatch, as the run time reads
  `Value::Int` only), a `Dictionary` is indexed by its key type and gives its value type, a
  string gives a `char`, and a tuple read by an integer literal gives that item (any other
  index gives an unknown type). A string and a tuple cannot be assigned through, and a number, a
  `Queue`, a `Stack`, a `Set`, a `Pool` or a function cannot be indexed at all: `TYPE-137`. The
  transparent `T?` and `T!` and the ownership and reference wrappers are looked through, and a
  value whose type is not known yet is not an error. Each of these used to pass sema.
- **A negative index on a write** counts from the end, as it does on a read (`l[-1] = 9`
  writes the last element; before, it panicked with an index near 2^64), and one past the start
  is a panic naming the index as written.
- **Tuple types unify.** The unifier compared single-parameter wrappers, `Named` and
  `Dictionary` structurally and had no tuple case, so two tuple types built apart were never
  equal unless they were one table entry (`take(p)` with `p: (int, int)` and `fn take(k: (int,
  int))` was a mismatch between two identical types). Same arity now unifies item by item. A
  tuple-indexed impl needed it; it also fixes the tuple annotations that did not unify with
  integer literals.
- **Run time.** `a[i]` and `a[i] = v` try the impl table first when a struct, an enum or an
  ownership wrapper around one is the indexed value, and otherwise index the built-in as before.
  A program that declares its own trait named `Index` or `IndexSet` shadows that one (each on
  its own) and its use is left unchecked, as for the operator traits.
- **Not built.** `a[1 .. 3]` is not a slice: a range evaluates to a `List` at run time and sema
  does not know the type of a range expression, so it passes sema and panics ("cannot index List
  with List"), as before. There is no `a[i, j]` syntax; a pair is written `a[(i, j)]`. A tuple
  literal index out of range is not reported (the type is unknown and the run time panics), and a
  missing `Dictionary` key still panics at run time. Indexing a `Pool` is `TYPE-137`, not a
  handle lookup.

### What S6 settled

Decided 2026-11-06, as three questions with a recommendation each.

- **Every tier (D2 option C), chosen over `HIGH` only.** `dyn Trait` can be written in `HIGH`,
  `MID` and `LOW` code. A tier wrapper is never written in a type (the tier lives in the
  reference, `MEMORY_MODEL.md` section 2), so `dyn Shape` is written the same way everywhere and
  sema gives it the wrapper of the place the value was built. What `LOW` code writes is what it
  already writes for other types: `&dyn Body`, `&mut dyn Body`, `Unique<dyn Body>`,
  `Shared<dyn Body>` and `SyncShared<dyn Body>`. A `dyn` is also a generic argument
  (`List<dyn Shape>`, `Dictionary<string, dyn Shape>`, `Bag<T>` holding `List<dyn Convert<T>>`).
  Cost of choosing every tier over `HIGH` only: a `dyn` value meets the escape, borrow and move
  passes. An arena value cannot be written into a binding or field of a bare `dyn` type (`TIER-004`,
  the same as for a concrete type, because a written type cannot name the arena), so a `MID`
  function borrows such a value as `&dyn Body`; borrow elision applies as for any other type, and a
  function that returns a `dyn` never gets it, because the result could hold the reference.
- **Rust's object-safety rule, chosen over a subset of callable methods.** A trait is usable as
  `dyn` when each of its methods takes `self`, has no generic parameters of its own and does not
  mention `Self` in a parameter or the result (nested too, as in `List<Self>` or
  `dyn Convert<Self>`), and the same holds for every trait it builds on. Anything else is
  `TYPE-138` at the written `dyn` type; one diagnostic lists every offending method as
  `Trait.method`. Cost: a trait with an associated function (`fn kind() string`) cannot be `dyn`
  at all, because Ubel has no `where Self: Sized` to exempt one method, so the trait is split in
  two. Of the prelude, `PartialEq`, `Eq`, `PartialOrd`, `Ord`, `Clone` and `Hash` (through `Eq`)
  are not usable as `dyn`; `Display`, `Iterator<T>`, the twelve operator traits, `Index` and
  `IndexSet` are. The check runs once the methods of the trait are collected, so a trait declared
  below the code that names it is still checked, and a written type is reported once however
  often it is lowered (a function result type is lowered twice).
- **Implicit coercion at typed sites (chosen as recommended).** A value of a type that implements
  the trait is accepted where `dyn Trait` is expected: a `let` with a written type, a call
  argument (functions and methods), a `return`, an assignment, a struct field, an enum payload
  (tuple or struct form), an element handed to a collection, an array literal on the right of a
  `let` whose written type is a list, array or slice with a `dyn` in its element type (each
  element is coerced; the written type may be a `type` alias or `&dyn T`), and the written
  `x as dyn Trait`. A value of an optional type is accepted for an optional `dyn`. An integer
  literal is an `int` and needs `Show for int`, as any other `int`. The collection methods that
  take an element are checked for a `dyn` element: `List.push` and `set`, `Queue.enqueue`,
  `Stack.push`, `InlineList.push` and `Dictionary.set` (the value). Those methods had no argument
  check at all, and the check applies only to a `dyn` element, so the other element types are
  unchanged. The helper is `unify_coerce` in `sema/type_infer/dyn_trait.rs`. It looks through the
  wrappers present on both sides, then asks for the trait as an ordinary bound obligation, so a
  missing impl is `TYPE-126` with the argument agreement and conditional impls the bound check
  already has. It never adds or removes a wrapper (`Circle` does not become `Unique<dyn Shape>`,
  a `Unique<Circle>` or `&Circle` does not become a bare `dyn Shape`), never converts one `dyn`
  type to another (`TYPE-101`, also for the same trait with other arguments) and never turns
  `List<Circle>` into `List<dyn Shape>` (the invariance every generic has).
- **Syntax.** `dyn Trait` and `dyn Trait<A, B>`, the trait named by a single identifier. `dyn`
  is a contextual word: it begins a type only when an identifier follows, so it stays usable as
  a name (`let dyn = 5`, `fn keep(dyn: int)`). `&dyn Shape` needed a guard in the lifetime-label
  heuristic of `parse_type.rs`, which would otherwise have read `dyn` as a label. One trait per
  `dyn`; `dyn A + B` is not parsed.
- **A call through `dyn`** resolves against the trait and every trait it builds on, at the tier
  the trait declares (the rule a bound follows, `TIER-005`), and the call is recorded as a trait
  call so the run time runs the trait method. A `dyn` satisfies a bound of its trait and of its
  supertraits, with the arguments agreeing (`describe<T: Named>(p)` with a `dyn Pet`; a
  `dyn Convert<int>` does not satisfy `T: Convert<string>`). An operator, an index and a `for` on
  a `dyn` of the matching trait work as through a bound (`dyn Add<V, V>`, `dyn Index<int, int>`,
  `dyn Iterator<int>`, with the item typed); a wrong right operand is `TYPE-136` and a `dyn` with
  no `Iterator` in a `for` is `TYPE-135`. `==` on a `dyn` is identity, as on any struct, and `<` is
  `TYPE-118`.
- **Run time.** No change. The interpreter already finds a method from the type name of the value
  (`dispatch_key`), through a bound as well, so a `dyn` value is the value itself and `as dyn`
  passes it through.
- **`impl` and `extend` for a `dyn` type** are `TYPE-129`.
- **Not built.** Conversion from `dyn Sub` to `dyn Super`, `dyn A + B` and a downcast to the
  concrete type. An array literal is coerced to a written `dyn` element type on the right of a
  `let` with a written type, and, since the thirtieth delivery, as an argument of a plain
  function, as a `return` value, as a struct field, as a field of an enum struct variant and as an
  element of an outer literal (`List<List<&dyn Shape>>`). As an argument of a method call, as the
  tail expression of a function body, as a tuple variant payload and as an argument of a generic
  callee it is still typed by its own elements first, so `[Circle { .. }, Square { .. }]` there is
  `TYPE-101` (a binding with a written type first works). A method is resolved only after its
  arguments are inferred, and the parameter types of a generic callee still hold placeholders at
  that point, which is why those sites are open. A `dyn` in an arena stays the borrow form
  described above. The representation a
  compiled backend needs, a pointer paired with a table of the methods of the trait, is not built
  and the interpreter does not need it.
- **Found on the way, not part of S6.** Indexing an `InlineList` passed sema and panicked at run
  time ("cannot index InlineList with int"), on the baseline too and for an `int` element. Fixed
  in the thirtieth delivery: `l[i]`, `l[i] = v` and `l[i] += v` work, a negative index counts from
  the end, and the index is checked against the items present, not the capacity.

### D7: what has to be specified before S4

Two facts found while building S1a bear on the tier design.

1. **A method call on a receiver is not tier-checked at all today.** The
   cross-tier call rule runs only for calls whose callee resolves to a
   definition (a plain function name). `recv.method()` has no such
   resolution, so a `MID` function can call a `HIGH` method on a value with
   no error. Putting a tier on trait methods is meaningless until method
   calls are checked, so S4 starts there.
2. **What "override to change the tier" lets an implementer do needs an exact
   rule.** Under the existing rule a callee must be at the caller's tier or
   lower. A call through a bound is checked against the tier the TRAIT
   declares, because the impl is not known. An impl method at a tier **at or
   below** the declared one can never make such a call unsound. An impl
   method **above** the declared tier can, unless every instantiation is
   checked separately. The S4 specification chooses between: exact match only;
   match or lower (sound with the existing rule); or arbitrary override with
   per-instantiation checking. It is written and agreed before S4 is built.

Both are resolved in `docs/TRAITS_TIERS_SPEC.md`: an impl method must match the
trait's tier exactly (S4b, built), and a call on a receiver is tier-checked (S4a and S4b, built).

---

## 1. Where things stand (at the start of the design session)

Verified by reading the source and by running small programs, not taken from
the older notes.

| Stage | What happens to a trait today |
|---|---|
| Parser | Parses `trait` (method signatures, default methods, associated type *names*), `impl Trait for Type`, and `T: A + B` bounds. Does **not** parse supertraits (`trait B: A`), `where` clauses, bounds with arguments (`T: Into<U>`), a tier on a signature, or associated type bindings in an impl. The generic arguments of a trait path in an impl (`impl From<int> for X`) are parsed and then discarded (`let _ = self.try_parse_generic_args()`). |
| Name resolution | Declares the trait (`DefKind::Trait`) and resolves default-method bodies. `AssociatedType` is a `TODO`. |
| Sema | Collects trait method signatures and infers default-method bodies. Trait `impl`s are **excluded from dispatch** (`register_extend_impl_methods` skips any impl with a `trait_path`), so `impl Shape for Sq { fn area .. }` followed by `q.area()` is `NoSuchMethod`: **a trait impl cannot be used at all.** Bounds are stored and never checked. A method call on an unbounded type parameter is accepted as `Unknown`. |
| Interpreter | Dynamically typed, generics erased. Dispatch is `method_table[type_name][method]`; trait impls are skipped there too. |
| Derive | The one trait-like feature that works: six hard-coded names (`PartialEq`, `Eq`, `Hash`, `Ord`, `PartialOrd`, `Clone`), structs only, with prerequisite chains (`Eq` needs `PartialEq`, `Ord` needs `PartialOrd` and `Eq`, `Hash` needs `Eq`). They set flags on `Value::Struct` that change `==`, ordering, hashing and cloning at runtime. |

### Probes

| Program | Result |
|---|---|
| `impl Shape for Sq { fn area(self) .. }` then `q.area()` | sema `NoSuchMethod` |
| `fn total<T>(x: T) int { return x.area() }`, called with a struct that has `area` and with `5` | sema accepts both; the `5` call panics at runtime (`no method 'area' on int`) |
| `for x in b` where `b` is a user struct | sema accepts; runtime panic (`cannot iterate over value of type 'struct'`) |
| `a + b` on two user structs | sema accepts; runtime panic (`arithmetic not supported on struct`) |
| `a == b` on two equal structs with no derive | `false` (identity, not structure) |
| `println($"{p}")` on a struct declared `x, y` | prints `P {x: 1, y: 2}` in some runs and `P {y: 2, x: 1}` in others (6 of 8 runs vs 2 of 8): field order comes from a `HashMap`, not from the declaration |
| `trait B: A { .. }` | parse error |

Three of these are the same hole the project has closed several times: sema
accepts, the interpreter panics. A trait system is the natural home for the
protocols behind them (iteration, operators, formatting, equality).

---

## 2. Constraints

- **C1. Monomorphization is the stated direction.** `MEMORY_MODEL.md` assumes
  monomorphized types and an eventual LLVM backend; the tree-walking
  interpreter is a stand-in. Whatever is chosen must lower to static dispatch
  by default.
- **C2. The interpreter erases generics.** There are no runtime type
  parameters. Every option below must be implementable as sema checks plus a
  method table.
- **C3. Tiers.** The cross-tier call rule is: a callee must be at the caller's
  tier or lower. `HIGH` may call `HIGH`, `MID` and `LOW`; `MID` may call `MID`
  and `LOW`; `LOW` may call only `LOW`. `MethodSig` has no tier today, and the
  tier lives in the reference wrapper (`GcRef`, `ArenaRef`, `OwnedRef`), not in
  the type name.
- **C4. No module system.** `summon` is unscheduled, so an orphan rule cannot
  be written or tested yet.
- **C5. Taste.** The project avoids heavy machinery until a concrete need
  proves it worth the weight (LALRPOP, SMT solvers). "Should this be a
  pattern instead of a feature" is a legitimate first question.

---

## 3. Decisions

Each decision lists its options, what each costs, and a recommendation. The
recommendations are consistent with each other; changing one may change
another, noted where it does.

### D1. Is there a `trait`, and what kind?

| Option | Meaning | Cost |
|---|---|---|
| **A. Nominal traits** | A type implements a trait only by declaring `impl Trait for Type` (Rust, C#). | Matches the grammar, the AST and `T: Bound` that already exist. Needs the dispatch and bound checking that do not. |
| **B. Structural interfaces** | A type satisfies an interface by having the right methods; no `impl .. for` (Go). | Makes the parsed `impl .. for` dead syntax. A method name carries no tier and no intent, which sits badly with tier rules and with the derive prerequisite chains. |
| **C. No keyword** | Duck typing plus a hand-rolled vtable: a struct of function-typed fields (Zig, Odin). | Cheapest. It is what the interpreter already does, minus any checking, and the cost shows: the unbounded-`T` probe above compiles and then panics at runtime. Function-typed fields are callable now, so the vtable pattern works today. |

**Recommended: A.** The six derives already behave like named capability sets
with supertraits, and the parser already commits to nominal syntax. Option C
stays available as the *pattern* for dynamic dispatch (D2) even with A chosen.

### D2. Static dispatch, dynamic, or both?

| Option | Meaning |
|---|---|
| **A. Static only** | Bounds are checked at declaration; calls resolve per instantiation. No `dyn Trait`. |
| **B. Static plus `dyn` in `HIGH` only** | `dyn Trait` as a type behind a GC reference, giving heterogeneous collections such as `List<dyn Shape>`. |
| **C. Static plus `dyn` in every tier** | `dyn` behind the tier wrappers (`GcRef<dyn T>`, `ArenaRef<dyn T>`, `OwnedRef<dyn T>`). |

Facts that bear on it: a vtable needs a pointer wrapper; the architecture of
`FfiSpan` is still listed as open in `DATASTRUCTURES.md`; and `dyn` adds a
type form, an object-safety question (methods returning `Self`, generic
methods) and a per-tier representation. None of that is needed for checked
bounds. The interpreter would run all three identically, so the choice is
about what sema checks and what the future backend must generate.

**Recommended: A first, B as a later slice, C deferred.** Heterogeneous
collections have two workable answers in the meantime: an `enum` of the
variants, or the function-field vtable pattern (D1 option C).

### D3. Coherence: which impl applies, and what is allowed?

Questions and the proposed v1 answer to each:

| Question | Recommended v1 answer |
|---|---|
| Two impls of one trait for one type | Error (`OverlappingImpl`). No specialization. |
| Impl for a built-in type (`impl Shape for int`) | Allowed. Needed so that `T: Ord` can be satisfied by `int` and `string` at all (D5). |
| Orphan rule | Deferred until modules exist. The intended rule, to avoid painting into a corner: an impl is allowed only in the package that declares the trait or the type. |
| Blanket impls (`impl<T: A> B for T`) | Not in v1. Revisit once bounds and supertraits are solid. |
| Inherent method and trait method with the same name | The inherent method wins. |
| Two traits supplying the same method name to one type | Error at an unqualified call (`AmbiguousTraitMethod`); resolved with a qualified call, `Shape.area(q)`. C#-style explicit implementation (`fn Renderable.draw(self)`) is a proven mechanic and is deferred, not rejected. |

### D4. What can a trait contain?

The AST already has method signatures, default methods and associated type
names. Options, cumulative:

| Level | Adds |
|---|---|
| **i** | Methods and default methods, with `Self` (already parses in signatures; nothing resolves it). |
| **ii** | Generic traits (`trait Convert<T>`) and supertraits (`trait Ord: Eq`). Needs the impl's trait path to keep its arguments, and the parser to read `: Bound` after a trait name. |
| **iii** | Associated types (`type Item`). Needs bounds on the declaration and bindings in the impl. |
| **iv** | Required fields (Scala style) and associated constants. |

**Recommended: i in the first slice, ii next, and prefer generic traits over
associated types for iteration (`Iterable<T>`)**, since the language already
has generics with inference and it avoids a second mechanism. Associated types
are justified only if one-impl-per-type semantics turn out to matter. Required
fields are not recommended now: they interact with field layout (ECS `@core`
and `@tag`, arena layout), and that interaction is unverified.

### D5. How do the built-in protocols relate to traits?

| Option | Meaning |
|---|---|
| **A. Leave them magic** | Traits are for user abstractions only; derives, formatting, `for` and operators stay compiler features. |
| **B. Lift the six derives into prelude traits** | `PartialEq`, `Eq`, `Hash`, `Ord`, `PartialOrd`, `Clone` become real traits with the supertrait chains they already have; `@derive` becomes "generate this impl". Primitives and the built-in collections get built-in impls. Bounds such as `K: Hash + Eq` and `T: Ord` become enforceable. |
| **C. B plus language-item traits** | Adds `Display`/`Debug` (formatting), `Iterable<T>` (`for x in value`) and operator traits (`Add`, `Sub`, `Index`, ..). Each closes one of the sema-accepts, runtime-panics probes above, and `Display`/`Debug` would define field order by declaration, fixing the print nondeterminism. |

**Recommended: B in the second slice; the items of C one at a time, each its
own decision.** Operator overloading in particular is a language-taste choice
(vector math for a game language argues for it) and deserves its own
yes or no, not a ride-along.

### D6. Bounds: syntax and enforcement

| Option | Meaning |
|---|---|
| **a. Call sites only** | Inferred type arguments must satisfy the bounds. |
| **b. (a) plus bodies** | Inside a generic body, a method call on `T` resolves only through `T`'s bounds, and a method call on an unbounded `T` is an error. |
| **c. (b) plus richer syntax** | `where` clauses and bounds with arguments (`T: Into<U>`). Needs `GenericParam.bounds` to become structured instead of `&[&str]`. |

**Recommended: b in the first slice, c later.** Option b is a deliberate
strictness change: the unbounded-`T` probe compiles today and panics at
runtime for `total(5)`. Whether any existing fixture relies on calling a
method on an unbounded parameter has not been checked; the fixture sweep
decides it, and any that does is a real bug the change would surface.

### D7. Tiers and traits

| Option | Meaning |
|---|---|
| **a. Tier on the signature** | A trait method signature carries an optional tier (default `high`, like every function). An impl method's tier must be at most the declared tier. A call through a bound is checked against the declared tier with the existing cross-tier rule. |
| **b. Tier-polymorphic traits** | Each impl declares its own tier and callers adapt. Sound only if call checks cannot be fooled; considerably more machinery. |
| **c. `HIGH` only** | Trait methods and bounded generic code usable only from `HIGH`; `MID` and `LOW` use concrete types. |

**Recommended: a, staged.** With no tier on signatures every trait method is
`high` by default, which is exactly option c for free through the existing
rule, so the first slice needs no new tier code. Adding `@tier(mid) fn
tick(self)` to a signature later only relaxes it. This is the most
concretely buildable piece of the outside synthesis noted in
`PARKED_IDEAS.md`, because `check_callee_tier` already exists.

### D8. Keywords: `impl` and `extend`

For inherent methods the two are equivalent today. `ImplBlock` carries a
block tier and an optional trait path; `ExtendDecl` carries neither.
**Recommended:** `extend` stays inherent only, `impl Trait for Type` is the
trait form, and a plain `impl Type { }` stays accepted so nothing breaks.

---

## 4. Proposed delivery order

Each slice is one delivery with an isolated and a combined fixture per phase,
exact-count tests, and the docs updated in the same bundle.

| Slice | Contents | Decisions it needs |
|---|---|---|
| **S1** | Nominal traits with static checking: register trait impl methods in sema and interpreter dispatch; conformance checks (missing method, method not in the trait, signature mismatch with `Self`); default methods inherited; bounds enforced at call sites and through bodies; inherent-first resolution and the qualified call. | D1 A, D2 A, D3, D4 i, D6 b, D7 a, D8 |
| **S2** | Prelude traits for the six derives; built-in impls for primitives; bounds on built-in collections; `@derive` becomes an impl generator. | D5 B |
| **S3a** | Supertraits (built). | D4 ii |
| **S3b** | Generic traits, bounds with arguments and generic supertraits (built). | D4 ii |
| **S3c** | A method's own generic parameters with bounds, generic methods in traits, and bounds on a type alias parameter (built). | D4 ii |
| **S3d** | Impls and `extend` blocks for primitives, tuples and arrays (built). | D4 ii |
| **S3e** | Impls and `extend` blocks for generic types and the generic built-in collections (built). | D4 ii |
| Later | Associated types, blanket impls, impls for `Option`-like wrappers and for `Pool` and `Handle`. The order is chosen with the project owner. | D4 ii |
| **S4** | Tier on trait method signatures, in two deliveries, both built: S4a carries tiers to methods and checks calls on a concrete receiver; S4b puts the tier on traits. | D7 |
| **S5** | Language-item traits, one decision and one delivery each: `Display`/`Debug`, `Iterable<T>`, operators. | D5 C |
| **S6** | `dyn Trait` in every tier. | D2 C |

Indicative new diagnostics for S1, codes assigned when built:
`TraitMethodMissing`, `UnknownTraitMethod`, `TraitMethodSignatureMismatch`,
`UnsatisfiedBound`, `AmbiguousTraitMethod`, `OverlappingImpl`,
`MethodOnUnboundedParam`.

Explicitly deferred: blanket impls, the orphan rule, explicit-implementation
syntax, associated types, required fields, `FfiSpan<dyn Trait>`,
specialization.

---

## 5. Found along the way

Recorded here because they surfaced while reading and probing. None is part
of the trait work, and none has been changed.

- **Struct printing is nondeterministic.** The default struct display walks a
  `HashMap`, so field order varies between runs. `Value::Struct` already
  carries `field_order` (used for ordering and hashing); formatting does not
  use it. A small, separate fix.
- **`for` over a user type and arithmetic on user types are accepted by sema
  and panic at runtime.** Two more sema-accepts, runtime-panics holes, folded
  into D5 option C as the protocols that would give them a type error.
- **Method calls on an unbounded type parameter are accepted.** Folded into
  D6.
- **Supertrait syntax does not parse.** Folded into D4 level ii.
