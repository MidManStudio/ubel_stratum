# Building and running Ubel native code in Termux (Android)

Provisional, and **not yet run on a real phone**: everything below was reasoned from the code and checked on an
emulator, not in Termux. The first person to try it should expect to fix a detail or two and write it down here.

## The quick way: a prebuilt `ubel` from CI (recommended)

Building the whole workspace on a phone is slow and needs 3 to 4 GB of memory, and on Android 12 and newer it can be killed
halfway: Android limits background child processes, and Termux users report `[Process completed (signal 9)]` in the middle of
a long `cargo build` (the usual remedies are in Termux's own documentation and community guides; none was tried here). So the
better way is to let GitHub build `ubel` for your phone's CPU:

1. On GitHub, in the repository: Actions, **Ubel for Android (Termux, 64-bit and 32-bit ARM)**, Run workflow (the file in the repository is
   `.github/workflows/ubel-andriod.yml`, spelled that way). It takes a few minutes and makes two artifacts.
2. Which one? In Termux run `uname -m`. `aarch64` is a 64-bit userspace: download **ubel-android-aarch64**. `armv8l` or `armv7l`
   is a 32-bit userspace, even on a 64-bit CPU (some budget Samsung phones ship that way, and one Termux troubleshooting guide
   lists the Galaxy A13 5G among them, so check your own phone and do not assume): download **ubel-android-armv7**.
3. Unzip it in Termux (`pkg install unzip`; run `termux-setup-storage` first if the zip is in Downloads), then:

```sh
chmod +x ubel
bash termux_try.sh                 # says what the phone is, tries `ubel run`, and `ubel build` when clang is there
pkg install clang                  # `ubel build` needs it; `ubel run` (the interpreter) needs nothing
./ubel build hello.ubl -o hello && ./hello
```

Paste the whole output of `termux_try.sh` back: it is the first real evidence of how this behaves on a phone. The binaries are
built for Android 7.0 (API 24) and run on every newer Android. The same workflow also builds the supported examples for both
targets with the NDK's clang, linked statically, and runs them under QEMU on the runner (bionic, not glibc), comparing them
with the interpreter. That is not the same as running on a phone. The owner ran the workflow and then the `ubel` it built in Termux on their phone and
reported that everything passed (which artifact it was, what `uname -m` printed and the Android version were not recorded).

## What you need (to build on the phone yourself)

- Termux from F-Droid (the Play Store build is old and no longer updated).
- A C compiler that understands textual LLVM IR: Termux's `clang`. The backend needs clang **15 or newer** and `ubel-llvm
  build` checks that with `clang --version`. Termux tracks a recent LLVM, which is newer than anything the backend has
  been tested with (18 is the one in CI); see "What was tested" below.
- Rust, to build the `ubel` command line and the emitter (`ubel-llvm`): Termux's `rust` package.
- About 2 GB free storage and some patience: the first build is slow on a phone.

## Steps

```sh
pkg update
pkg install git rust clang
# if linking later complains that it cannot find a linker: pkg install lld binutils

uname -m          # aarch64 is a 64-bit userspace; armv7l or armv8l is a 32-bit one (see below)

git clone https://github.com/MidManStudio/ubel_stratum
cd ubel_stratum

# The workspace release profile is LTO with one codegen unit, which is too heavy for a phone: switch both off.
export CARGO_PROFILE_RELEASE_LTO=false CARGO_PROFILE_RELEASE_CODEGEN_UNITS=16 CARGO_BUILD_JOBS=2
cargo build --release -p ubel_stratum_cli      # the `ubel` command, including `ubel build`
```

`CARGO_BUILD_JOBS=2` and the profile switches keep memory use down; use `1` jobs if the build is killed (Android's low-memory killer ends processes
without a message, and the symptom is just `Killed`). The first build compiles the parser and the front end as well, and
takes a long time on a phone; later builds are quick.

The `ubel` command ends up in `target/release/ubel`. Use it:

```sh
UBEL=target/release/ubel
$UBEL build examples/arena_demo/ast_builder.ubl -o ast                   # source to executable, one command
./ast
$UBEL build crates/ubel_llvm/examples/36_assert.ubl -o t --verbose       # shows the compiler found and the exact command
$UBEL run crates/ubel_llvm/examples/36_assert.ubl                        # the interpreter, for comparison
```

`ubel build` checks the file with the front end first, so its diagnostics look like `ubel check`'s. The smaller
`ubel-llvm` binary (`cargo build --release -p ubel_llvm`, in `target/release/ubel-llvm`) has `emit` and `interp` as well.

The temporary files go to `$TMPDIR`, which Termux sets (there is no `/tmp` on Android). `ubel-llvm build` finds `clang`
on the `PATH`; `--cc PATH` or `UBEL_CC` points it at a different one.

## Checking that it really works on your phone

```sh
bash crates/ubel_llvm/scripts/run_equiv.sh
```

builds every example natively and compares it with the interpreter. It takes a while on a phone. Notes:

- It skips the AddressSanitizer variants when the sanitizer runtime is missing (it probes first), which is the usual case
  in Termux. That is expected, not a failure.
- **It will probably rewrite two files** (`runtime/ubel_unicode.h` and `examples/29_string_unicode.ubl`). The committed
  Unicode tables are generated by the Rust toolchain that ran `scripts/gen_unicode.rs` (15.0.0 today); Termux's Rust is
  newer, so the script regenerates them, and the check then passes against the newer tables. If it ends with all examples
  passing, `git diff` shows the regenerated files; committing them is the right thing to do, because the project's real
  toolchain is newer than the one the committed tables came from. Do not commit them if any example fails. (Tried here
  with Rust 1.85, whose tables are Unicode 16.0.0: the script regenerated both files, and all 86 examples then passed.)
  Only this script does that. `ubel build` and `ubel-llvm build` take their Unicode tables from `build.rs`, which
  generates them from Termux's own Rust while the crate is compiled, so there is nothing to regenerate or commit for them.
- Something that fails here and passes elsewhere is the interesting case: keep `OUT_DIR=...` and send the first failing
  example's `.build.log` and `.run.err`.

## 32-bit or 64-bit?

Many phones, including some Galaxy A-series, run a 32-bit userspace even though the CPU is 64-bit. `uname -m` says
`armv7l` or `armv8l` then (and `getconf LONG_BIT`, if your Termux has it, says 32). That is the same situation as the `-m32` runs the test suite
does on x86, with ARM's rules (8-byte alignment for `i64` and `double`, hard-float or soft-float calling convention). The
emitted IR names no target and computes every size and offset with the target-neutral `ptrtoint`-of-`getelementptr` idiom, so
nothing is assumed about pointer width.

## What was tested

On Linux x86-64, with clang 18.1.3: the whole suite at 64-bit and at `-m32`, under AddressSanitizer and UBSan.

On **emulated** ARM (QEMU user mode, glibc, not Android's libc), every example that the emitter compiles, built through
`ubel-llvm build` with `-- --target=... --sysroot=...` and compared with the interpreter:

| Target | Result |
|---|---|
| 32-bit ARM (armv7, EABI5, hard-float), statically linked | 43 programs built and run, all identical to the interpreter |
| aarch64, statically linked | 43 programs built and run, all identical to the interpreter |

The same programs were also built with clang 15.0.7, 18.1.3, 19.1.1 and 20.1.2 on x86-64, and all matched the interpreter
under each, so the IR is not tied to one LLVM version. Termux's clang is probably newer than 20; that is the one gap.

That covers data layout, alignment, the collector's register capture (`__builtin_unwind_init`) and the arena allocator
on ARM, measured before floats existed (M2b added examples 38 to 43; they were not run on ARM). The "Ubel for Android"
workflow is meant to cover Android's libc (bionic) in the same way, with the NDK, but has not run yet. Nothing here covers
Termux's clang version, memory limits, or real hardware.

## Known risks, most likely first

1. **A newer clang than the tested one.** The emitter writes textual IR with opaque pointers and plain attributes. LLVM 15,
   18, 19 and 20 all accept it, but Termux's clang may be newer still.
   Symptom: `the C compiler failed` with an error about the `.ll` file. `ubel-llvm build --keep-temps` keeps the IR; send it.
2. **Memory.** A release build of the front end is large for a phone with 3 to 4 GB. Use `CARGO_BUILD_JOBS=1` if needed.
3. **Bionic differences.** The runtime uses only `stdio`, `stdlib`, `string` and `mmap`. A missing symbol at link time would be
   the sign of something else.
4. **The Rust version.** Termux's `rust` is much newer than the 1.75 the backend was developed with. A newer compiler is
   normally fine, but a new lint or a changed dependency can break a build; send the first error.
